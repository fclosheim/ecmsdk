Rem Copyright (c) 2003, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    SetupContextJobs.sql - Setup DBMS jobs to sync and optimize context index. 
Rem
Rem  History:
Rem    09-apr-03 (vdevadha)
Rem       Created. 

declare
    job binary_integer;
begin
    dbms_job.submit(job=>job, 
      what=>'ctx_ddl.sync_index(''IFS_TEXT'');',
    next_date=>trunc(SYSDATE, 'HH') +(1/24),
    interval=>'SYSDATE +((1/24) * 0.5)');

    dbms_job.submit(job=>job, 
      what=>'ctx_ddl.optimize_index(idx_name=>''IFS_TEXT'', optlevel=>''FULL'', maxtime=>60 );',
    next_date=>trunc(SYSDATE, 'DD')+1,
    interval=>'SYSDATE + 1');
end;
/
exit;



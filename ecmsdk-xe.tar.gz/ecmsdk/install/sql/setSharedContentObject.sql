Rem Copyright (c) 2005, 2008, Oracle. All rights reserved.  
Rem
Rem setSharedContentObject.sql - Use to set up shared content
Rem objects post upgrade. This is to workaround bug 4718944.
Rem
Rem Usage - sqlplus <ocs_content_svcs_schema>/<password>@connectString @setSharedContentObject.sql 
Rem
Rem

set autocommit off;
set serveroutput on;

declare

  /* This cursor selects all docs, cos with shared content */
  CURSOR c1  is
    select doc.id docid, co.id coid, sharedcontent.content content
    from odm_document doc,
         odm_contentobject co,
         (select content, count(*) refs
          from   odm_contentobject
          group by content) sharedcontent
   where co.content =  sharedcontent.content
     and sharedcontent.refs > 1
     and doc.contentobject = co.id
   order by sharedcontent.content, doc.id; 

  /* holds id of the current content row */
  content NUMBER;

  /* holds the id of the shared content for current batch*/
  contentForCurrentBatch NUMBER;

  /* id of the current doc */
  docid NUMBER;

  /* id of the current content object */
  contentobjectid NUMBER;

  /* id of the content object to share in current batch */
  contentObjectForCurrentBatch NUMBER;

  /* number of docs we updated */
  updatedDocs NUMBER;

begin

  /* set number of docs to 0 */
  updatedDocs := 0;

  /* as soon as we start, there is no shared content */
  contentForCurrentBatch := -1;

  /* for each row in the result set, do the processing */
  for cIdx in c1 loop
    begin

      /* get the id of the current content */
      content := cIdx.content;

      /* see if we are starting a new batch */
      if (content != contentForCurrentBatch) then

        /* commit the old batch */
        commit;

        /* reset the content and CO for current batch */
        contentForCurrentBatch := content;
        contentObjectForCurrentBatch := cIdx.coid;

        /* update content object table to mark it as readonly */
        update odm_contentobject
        set readonly = 1
        where id = contentObjectForCurrentBatch; 

      /* process 2...N documents that refer to same content */
      else
                           
        /* get the document id and content object id */
        docid := cIdx.docid;
        contentobjectid := cIdx.coid;

        /* update the document to point to the content object for this batch */
        update odm_document 
        set contentobject = contentObjectForCurrentBatch
        where id = docid;

        /* update the content object to set the content row reference to null */
        update odm_contentobject 
        set content = 0 
        where id = contentobjectid;

        updatedDocs := updatedDocs + 1;

      end if;  
    end;
  end loop;
  commit;

  dbms_output.put_line('Number of rows processed : ' || updatedDocs);

  exception
  when others then
    rollback;
    raise;
end;

/



Rem Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
Rem All rights reserved. 
Rem
Rem  NAME
Rem    CreateCrawlerUser.sql - create crawler user and grant minimal access
Rem
Rem History:
Rem     15-jul-09 (dlong)
Rem         Created.

Rem 2 arguments are passed: Crawler user name, Crawler user password

whenever sqlerror exit sql.sqlcode

Prompt create new database user
CREATE USER &1 IDENTIFIED BY &2;

GRANT CONNECT TO &1;
GRANT RESOURCE TO &1;






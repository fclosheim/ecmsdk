Rem Copyright (c) 2002, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    convert_to_nopartitioning.sql - convert iFS schema to not use partitioning
Rem
Rem History:
Rem  23-apr-02 (dlong)
Rem    Created.

whenever sqlerror exit sql.sqlcode

create table odmz_publicobject_temp as select * from odm_publicobject;
drop table odm_publicobject;
create table odm_publicobject as select * from odmz_publicobject_temp;
drop table odmz_publicobject_temp;
alter table odm_publicobject add primary key(id);

declare
    s varchar2(200);
begin

    select a.id into s from odmv_attribute a, odmv_classobject c where a.class = c.id and c.name = 'PUBLICOBJECT' and a.name = 'OWNER';
    execute immediate 'create index odmi_' || s || '_uni on odm_publicobject (owner)';

    select a.id into s from odmv_attribute a, odmv_classobject c where a.class = c.id and c.name = 'PUBLICOBJECT' and a.name = 'ACL';
    execute immediate 'create index odmi_' || s || '_uni on odm_publicobject (acl)';

    select a.id into s from odmv_attribute a, odmv_classobject c where a.class = c.id and c.name = 'PUBLICOBJECT' and a.name = 'FAMILY';
    execute immediate 'create index odmi_' || s || '_uni on odm_publicobject (family)';
   
    select a.id into s from odmv_attribute a, odmv_classobject c where a.class = c.id and c.name = 'PUBLICOBJECT' and a.name = 'LOCKOBJECT';
    execute immediate 'create index odmi_' || s || '_uni on odm_publicobject (lockobject)';

    
end;
/

commit;

update odm_classobject set partitioned = 0 where uniquename = 'PUBLICOBJECT';
commit;

exit;


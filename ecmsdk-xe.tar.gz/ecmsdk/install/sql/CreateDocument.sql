-- create a type that stores an array of numbers
create or replace type num_array as table of number(20);
/
show errors;

-- create a type that stores an array of strings
create or replace type str_array as table of varchar2(700);
/
show errors;

create or replace procedure CreateDocument(
 originalId num_array,
 documentClassId number,
 name str_array,
 description str_array, 
 owner num_array,
 acl num_array,
 createDate num_array,
 creator num_array,
 lastModifyDate num_array,
 lastModifier num_array,
 parentFolder num_array,
 readByOwner num_array,
 contentQuota num_array,
 format num_array,
 media num_array,
 content num_array,
 contentSize num_array,
 characterSet str_array,
 language str_array,
 contentReadOnly num_array, 
 contentObjectClassId number,
 relationshipClassId number,
 lockHolder num_array,
 lockEntryClassId number,
 lockEntryAclId number,
 lockRestriction number)
is
  documentId num_array;
  contentObjectId num_array;
  relationshipId num_array;
  status num_array;
  errorMessage str_array;
  errors number;
  failedIndex number;
  nameCopy str_array;
  descriptionCopy str_array;
  characterSetCopy str_array;
  languageCopy str_array;
  lockId num_array;
  lockEntries num_Array;

begin
    -- Next four statements are done to workaround a potential JDBC 
    -- bug when passing string [] to pl/sql procedure.
    nameCopy := name;
    descriptionCopy := description;
    characterSetCopy := characterSet;
    languageCopy := language;

    -- initialize the status array; used to load mapping table 
    status := num_array();
    status.extend(originalId.LAST);

    -- initialize the error message array; used to load mapping table 
    errorMessage := str_array();
    errorMessage.extend(originalId.LAST);

    -- initialize the new document Id array 
    documentId := num_array();
    documentId.extend(originalId.LAST);

    -- initialize the new content object Id array
    contentObjectId := num_array();
    contentObjectId.extend(originalId.LAST);

    -- initialize the new content object Id array
    relationshipId := num_array();
    relationshipId.extend(originalId.LAST);

    -- initialize the lockid and lockentries array
    lockId := num_array();
    lockId.extend(originalId.LAST);
    lockEntries := num_array();
    lockEntries.extend(originalId.LAST);

    -- initialize new id arrays using sequence. Initialize status and
    -- error message arrays with empty values. 
    for i in originalId.FIRST..originalId.LAST loop

       select odm_id_seq.nextval into documentId(i) from dual;
       select odm_id_seq.nextval into contentObjectId(i) from dual;
       select odm_id_seq.nextval into relationshipId(i) from dual;

       if (lockHolder(i) > 0) then
         select odm_id_seq.nextval into lockId(i) from dual;
         lockEntries(i) := -lockId(i);
       else
         lockId(i) := 0;
         lockEntries(i) := 0;
       end if;

       status(i) := 0;
       errorMessage(i) := '';

    end loop;

    -- we add a new BLOCK start here to make sure only the exceptions
    -- generated in the forall statement go to the following exception
    -- handling block.

    BEGIN

    forall i in originalId.FIRST..originalId.LAST save exceptions 

       insert all

       when lockHolder(i) > 0 then

       into odm_publicobject(id, classid, NAME, DESCRIPTION, OWNER, ACL, FAMILY, 
         RESOLVEDPUBLICOBJECT, CREATEDATE, CREATOR, LASTMODIFYDATE, 
         LASTMODIFIER, DELETOR, POLICYLISTS, POLICYBUNDLE, PROPERTYBUNDLE,
         SECURINGPUBLICOBJECT, EXPIRATIONDATE, FLAGS, LOCKOBJECT, 
         PRIMARYPARENTFOLDER, LOCKENTRIES) 
       values(lockId(i), lockEntryClassId, null, null, 96, lockEntryAclId, 0,
         lockId(i), lastModifyDate(i), lockHolder(i), lastModifyDate(i), 
         lockHolder(i), 0, 0, 0, 0,
         0, null, null, 0,
         0, 0)
       into odm_lockentry(id, ASSOCIATEDPUBLICOBJECT, TYPE, RESTRICTION, TIMEOUT, 
         EXCEPTEDUSER, EXCEPTEDSESSION, INFO, DAVOWNER, TOKEN, DEPTH) 
       values (lockId(i), documentId(i), 1, lockRestriction, null,
         lockHolder(i), 0, 0, null, null, 0) 

       when 0 = 0 then 

       -- insert rows used to represent ContentObject

       into odm_systemobject(id, classid, POLICYLISTS, POLICYBUNDLE, ACTIVE, 
         PROPERTYBUNDLE) 
       values (contentObjectId(i), contentObjectClassId, 0, 0, 1, 0)

       into odm_contentobject(id, FORMAT, MEDIA, CONTENT, CONTENTSIZE, 
         CONTENTSTORAGETYPE, CHARACTERSET, LANGUAGE, READONLY, LASTMODIFYDATE,
         LASTSCANNEDDEFDATE, QUARANTINEDDATE, REPAIRATTEMPTS) 
       values (contentObjectId(i), format(i), media(i), content(i), 
         contentSize(i), 0, characterSetCopy(i), 
         languageCopy(i), contentReadOnly(i), lastModifyDate(i), null, null, null)

       -- insert rows used to represent Document

       into odm_publicobject(id, classid, NAME, DESCRIPTION, OWNER, ACL, FAMILY, 
         RESOLVEDPUBLICOBJECT, CREATEDATE, CREATOR, LASTMODIFYDATE, 
         LASTMODIFIER, DELETOR, POLICYLISTS, POLICYBUNDLE, PROPERTYBUNDLE,
         SECURINGPUBLICOBJECT, EXPIRATIONDATE, FLAGS, LOCKOBJECT, 
         PRIMARYPARENTFOLDER, LOCKENTRIES) 
       values (documentId(i), documentClassId, nameCopy(i), descriptionCopy(i), 
         owner(i), acl(i), 0, 
         documentId(i), createDate(i), creator(i), lastModifyDate(i), 
         lastModifier(i), 0, 0, 0, 0, 
         parentFolder(i), null, null, 0, 
         parentFolder(i), lockentries(i))

       into odm_document(id, CONTENTOBJECT, READBYOWNER, CONTENTQUOTA) 
       values (documentId(i), contentObjectId(i), readByOwner(i), contentQuota(i))

       -- insert rows used to represent FolderPathRelationship

       into odm_systemobject(id, classid, POLICYLISTS, POLICYBUNDLE, ACTIVE, PROPERTYBUNDLE) 
       values (relationshipId(i), relationshipClassId, 0, 0, 1, 0)

       into odm_relationship(id, NAME, LEFTOBJECT, RIGHTOBJECT, SORTSEQUENCE) 
       values (relationshipId(i), null, parentFolder(i), documentId(i), relationshipId(i)) 

       into odm_folderrelationship(id)
       values (relationshipId(i))

       into odm_folderpathrelationship(id, LEFTOBJECTCOPY, RIGHTOBJECTNAME) 
       values (relationshipId(i), parentFolder(i), nls_upper(nameCopy(i)))

       -- insert row into aclproxy table

       into odmz_aclproxy (securingpo, securedpo, securedpoclassid) 
       values (parentFolder(i), documentid(i), documentClassId)

       select 1 from dual;

    exception

       when others then
       errors := SQL%BULK_EXCEPTIONS.COUNT;

       -- Process any exceptions that may have been saved
       FOR i IN 1..errors LOOP

         -- get the iteration # that failed
         failedIndex := SQL%BULK_EXCEPTIONS(i).ERROR_INDEX;

         -- set the new document id for that number to be 0
         -- this is correct since that document failed to create
         documentId(failedIndex) := 0;

         -- set the status as failed
         status(failedIndex) := 1;

         -- set the error message; 
         -- fixme - try to get a more verbose error message.
         errorMessage(failedIndex) := SQLERRM(-SQL%BULK_EXCEPTIONS(i).ERROR_CODE);

       END LOOP; -- End processing exceptions cursor

    END; -- end processing the block containing the FORALL statement

    -- insert entries into mapping table - these may be success or failure
    -- entries
    FOR i in originalId.first..originalId.last loop
        MappedObjectUtils.insertEntry@source(originalId(i), documentId(i), 
          status(i), errorMessage(i));
    end loop;

end CreateDocument;

/

show errors;

exit;


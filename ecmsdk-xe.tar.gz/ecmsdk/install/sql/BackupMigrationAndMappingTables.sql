Rem Copyright (c) 2004, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    BackupMigrationAndMappingTables.sql - This script is used during
Rem    Phased migration. It renames the odmze_migration table and
Rem    copies the odmze_mappedobject table. 
Rem 
Rem  Usage 
Rem    sqlplus @scriptName <Name of Migration table backup> <Name of MappedObject table copy>
Rem 
Rem    Note - Your SQL-PLUS session should be as ecm schema user.
Rem
Rem  History:
Rem    19-may-04 (vdevadha)
Rem      Created.

whenever sqlerror exit sql.sqlcode

Rem
Rem   Moving the migration table
Rem
alter table odmze_migration rename to &1;

Rem
Rem  Copying the mapped object table 
Rem
create table &2 as select * from odmze_mappedobject;

exit;


Rem Copyright (c) 2015, inxire GmbH and/or its affiliates.
Rem All rights reserved. 
Rem
Rem  NAME
Rem    SystemDropSchema.sql - Drop all objects used by ECMSDK
Rem 
Rem  Usage:
Rem    @SystemDropSchema {IFS_SCHEMA_NAME}
Rem
Rem History:
Rem     21-dec-15 (dscholle)
Rem         Created.

SET VERIFY OFF

-- @{IFS_ADMIN_SQL}/cleanupcontextpreferences.sql &1
Prompt action: cleanupcontextpreferences
drop procedure ctxsys.&1._WP;


Prompt action: DropSchemas
drop user &1 cascade;
drop user &1.$CM cascade;

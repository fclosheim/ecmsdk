Rem Copyright (c) 2005, 2008, Oracle. All rights reserved.  
Rem
Rem NAME
Rem     LockSchema.sql
Rem         Locks the ifss Schema
Rem
Rem PARAMETERS
Rem     &1  ifs schema name, e.g. FILES
Rem     &2  DBA name, e.g. sys
Rem     &3  DBA password, e.g. change_on_install
Rem
Rem History:
Rem     18-apr-05 (aknatara)
Rem         created
Rem

WHENEVER SQLERROR EXIT SQL.SQLCODE 

set serveroutput on size 10000;  
CONNECT &2/&3 as sysdba;  

DECLARE
   sql_stmt  varchar2(2000);
BEGIN
   sql_stmt := 'alter user &1 account lock' ;
   execute immediate  sql_stmt;
      
END;
/
EXIT;  



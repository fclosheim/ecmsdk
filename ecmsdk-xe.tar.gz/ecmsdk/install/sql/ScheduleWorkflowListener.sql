Rem Copyright (c) 2002, 2008, Oracle. All rights reserved.  
Rem
Rem History:
Rem  2002-05-20  spinto    Created.
Rem

declare
  jobno binary_integer;

begin
  dbms_job.submit(job=>jobno,
                  what=>'wf_event.listen(''IFS_OUT'');');


  dbms_job.interval(
    job=>jobno,
    interval=>'Wf_Setup.JobNextRunDate('||to_char(jobno)||','||
              to_char(0)||','||
              to_char(0)||','||
              to_char(0)||','||
              to_char(5)||')');

  commit;
end;

/

show errors;
exit;


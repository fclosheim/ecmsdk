Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    smuralid    01/18/04  - IndexSync: "debugLevel" parameter
Rem    smuralid    11/23/03  - IndexSync: maxSyncTime instead of maxDocs
Rem    smuralid    11/21/03  - sync in small batches
Rem    smuralid    11/18/03  - IndexSync: New parameter "forceSync"
Rem

create or replace package ctx_substr authid current_user is

  FUNCTION IndexCreate (ia sys.odciindexinfo, parms VARCHAR2,
     env sys.ODCIEnv) RETURN NUMBER;
  FUNCTION IndexDrop(ia sys.odciindexinfo, env sys.ODCIEnv)
     RETURN NUMBER;

  FUNCTION IndexAlter(ia SYS.ODCIIndexInfo,
                                  parms IN OUT VARCHAR2,
                                  alter_option NUMBER,
                                  env SYS.ODCIEnv)
     RETURN NUMBER;
  FUNCTION IndexTruncate(ia SYS.ODCIIndexInfo,
                         env SYS.ODCIEnv)
     RETURN NUMBER;

  FUNCTION IndexInsert(ia sys.odciindexinfo, rid VARCHAR2,
    newval varchar2, env sys.ODCIEnv) RETURN NUMBER;

  FUNCTION IndexDelete(ia sys.odciindexinfo, rid VARCHAR2,
    oldval varchar2, env sys.ODCIEnv) RETURN NUMBER;

  FUNCTION IndexUpdate(ia sys.odciindexinfo, rid VARCHAR2,
    oldval varchar2, newval varchar2, env sys.ODCIEnv)
     RETURN NUMBER;

  -- Syncs up the index. 
  -- Inserts data for new rows into the $I table. Deletes 'deleted' rows
  -- from the $I table, and then cleans up the $P table
  -- This procedure syncs up the rows of the $P table in batches.
  -- The batch-size is specifiable by the user. 
  -- For each batch, we attempt to lock all rows (select-for-update
  -- in no-wait mode). If this fails, we sleep
  -- a little, and then try this again - for upto 3 times.
  -- If we still can't get row locks on all rows in our batch in the 
  -- $P table, then we quit.
  -- Otherwise, we simply return without doing anything.
  -- maxTime describes the maximum time (in seconds) that should be spent 
  -- in this routine (subject to completion of a single batch). 
  --   Specifying 0 for this causes Sync to run to completion.
  -- debugLevel - 0 (no logging), 1 (basic logging into $L table)
  --              2 (logging + verification)
  PROCEDURE IndexSync(indexOwner varchar2, indexName varchar2, 
                      batchSize  number default 128,
                      maxTime    number default 120, 
                      debugLevel number default 0);

  FUNCTION IndexStart(sctx IN OUT lyke_idxtype_im,
     ia sys.odciindexinfo,
     op sys.odciPredInfo, qi sys.ODCIQueryInfo,
     regexp varchar2, 
     env sys.ODCIEnv) RETURN NUMBER;

  FUNCTION IndexFetch(sctx IN OUT lyke_idxtype_im,
      nrows NUMBER, rids OUT sys.odciridlist,
      env sys.ODCIEnv) RETURN NUMBER;

  FUNCTION IndexClose(sctx IN OUT lyke_idxtype_im,
                      env sys.ODCIEnv) RETURN NUMBER;

  FUNCTION StatsCollect(col SYS.ODCIColInfo,
                        options SYS.ODCIStatsOptions,
                        statistics OUT RAW, env SYS.ODCIEnv)
    return NUMBER;
  FUNCTION StatsCollect(ia SYS.ODCIIndexInfo,
                        options SYS.ODCIStatsOptions,
                        statistics OUT RAW, env SYS.ODCIEnv)
    return NUMBER;

  FUNCTION StatsDelete(col SYS.ODCIColInfo,
                       statistics OUT RAW, env SYS.ODCIEnv)
    return NUMBER;
  FUNCTION StatsDelete(ia SYS.ODCIIndexInfo,
                       statistics OUT RAW, env SYS.ODCIEnv)
    return NUMBER;

  FUNCTION StatsSelectivity(pred SYS.ODCIPredInfo, sel OUT NUMBER,
                            args SYS.ODCIArgDescList,
                            strt number, stop number,
                            regexp varchar2,
                            env SYS.ODCIEnv)
    return NUMBER;

  FUNCTION StatsFunctionCost(func SYS.ODCIFuncInfo,
                                        cost OUT SYS.ODCICost,
                                        args SYS.ODCIArgDescList,
                                        regexp varchar2,
                                        env SYS.ODCIEnv)
    return NUMBER;

  FUNCTION StatsIndexCost(ia SYS.ODCIIndexInfo, sel NUMBER,
                                     cost OUT SYS.ODCICost, qi SYS.ODCIQueryInfo,
                                     pred SYS.ODCIPredInfo,
                                     args SYS.ODCIArgDescList,
                                     strt number,
                                     stop  number,
                                     regexp varchar2,
                                     env SYS.ODCIEnv)
    return NUMBER;

end ctx_substr;
/
show errors;

grant execute on ctx_substr to public;



Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    smuralid    12/08/03  - add dr0substri.pkb.sql

Rem connect ctxsys/ctxsys
alter session set current_schema=&1;
@@dr0lyke.sql
@@dr0lyke.pkh.sql
@@dr0substr.pkh.sql
@@dr0substri.pkh.sql
@@dr0substri.pkb.sql
@@dr0substr.pkb.sql &1
@@dr0lyke.pkb.sql
@@dr0lyket.sql


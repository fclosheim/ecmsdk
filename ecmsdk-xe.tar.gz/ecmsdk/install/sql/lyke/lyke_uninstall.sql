alter session set current_schema=&1;

create or replace procedure my_exec_sql(stmt in varchar2) authid current_user is
begin
  begin
    execute immediate stmt;
  exception
    when others then null;
  end;
end;
/

Rem
Rem Actual cleanup
Rem
set serveroutput on

declare
  v number := 0;
begin

  -- First verify that there are no existing substring indexes
  execute immediate 'select count(*) from &1..dr$substr_idx'
    into v;
  if (v > 0) then
    dbms_output.put_line('ERROR: All substring indexes must be dropped first!');
    return;
  end if;

  -- Rem drop all tables
  my_exec_sql('drop table dr$numseq');
  my_exec_sql('drop table dr$substr_idx');

  -- Rem drop public synonyms
  my_exec_sql('drop public synonym lyke');
  my_exec_sql('drop public synonym lyke_pf');
  my_exec_sql('drop public synonym ctx_substr');

  -- Rem drop the indextypes
  my_exec_sql('drop indextype ctxsubstr');

  -- Rem drop the operators
  my_exec_sql('drop operator lyke force');
  my_exec_sql('drop operator lyke_pf');

  -- Rem drop the packages
  my_exec_sql('drop package ctx_lyke');
  my_exec_sql('drop package ctx_lyke_postfilter');
  my_exec_sql('drop package ctx_substr');
  my_exec_sql('drop package ctx_substr_int');

  -- Rem drop the types
  my_exec_sql('drop type lyke_idxtype_im force');
  my_exec_sql('drop type lyke_idxtype_stats force');
  my_exec_sql('drop type dr$ptab_set_t force');
  my_exec_sql('drop type dr$ptab_t force');

end;
/

drop procedure my_exec_sql;


Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    smuralid    12/08/03  - Creation (moved from dr0substr.pkb.sql)
Rem

create or replace package body ctx_substr_int as

  function stripQuotes(tok in varchar2) return varchar2 is
  begin
    if (substr(tok, 1, 1) = '"' and
        substr(tok, length(tok), 1) = '"') then
      return substr(tok, 2, length(tok) - 2);
    else
      return tok;
    end if;
  end;

  function getIndexInfo(p_owner varchar2, p_name varchar2) return index_info is
    iinfo index_info;
  begin
    select * into iinfo from dr$substr_idx 
      where index_owner = p_owner and index_name = p_name;
    return iinfo;
  end;

  function getIndexInfoByCol(p_owner varchar2, p_tablename varchar2,
                             p_colname varchar2) return index_info is
    iinfo index_info;
    l_colname varchar2(256);
  begin
    l_colname := stripQuotes(p_colname);
    select * into iinfo from dr$substr_idx 
      where table_owner = p_owner and table_name = p_tablename and
            col_name = l_colname;
    return iinfo;
  end;
  
  procedure updateIndexInfo(p_owner varchar2, p_name varchar2, 
                            iinfo index_info) is
  begin
    update dr$substr_idx set row = iinfo 
      where index_name = p_name and index_owner = p_owner;
  end;

  procedure insertIndexInfo(p_owner varchar2, p_name varchar2, 
                            iinfo index_info) is
  begin
    insert into dr$substr_idx values iinfo;
  end;

  procedure deleteIndexInfo(p_owner varchar2, p_name varchar2) is
  begin
    delete from dr$substr_idx 
      where index_name = p_name and index_owner = p_owner;
  end;
end ctx_substr_int;
/



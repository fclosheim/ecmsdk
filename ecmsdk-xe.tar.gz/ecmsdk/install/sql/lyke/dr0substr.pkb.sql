Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    vdevadha    06/28/05  - Bug fix 4453039; workaround DB bug. 
Rem    smuralid    03/25/04  - IndexSync: don't trim info if its null
Rem    smuralid    01/28/04  - IndexSync_OneBatch: flag verification errors
Rem    smuralid    01/27/04  - IndexSync_Verify: handle 'no-change' updates
Rem    smuralid    01/26/04  - IndexSync_OneBatch: silly bug
Rem                            IndexSync_Verify: tune $I query
Rem    smuralid    01/19/04  - #3385700: byte vs char semantics
Rem    smuralid    01/18/04  - Add sync logging/debugging support
Rem    smuralid    01/18/04  - IndexSync_OneBatch: #(3305460), #(3378719)
Rem    smuralid    01/14/04  - computeCostSel: sample base table for freq terms
Rem    smuralid    01/09/04  - Share (cache) results between cost and sel fns
Rem    smuralid    12/08/03  - move ctx_substr_int into dr0substri.pkb.sql
Rem    smuralid    12/08/03  - IndexSync_OneBatch: more patches 
Rem    smuralid    12/08/03  - Added IndexTruncate
Rem    smuralid    12/03/03  - IndexSync_OneBatch: skip L rows for batch
Rem    smuralid    12/01/03  - StatsDelete: return status of op
Rem    smuralid    12/01/03  - IndexInsert, IndexDelete: ignore NULLs
Rem    smuralid    11/24/03  - IndexSync: reduce locking time
Rem    smuralid    11/24/03  - IndexSync: make 9.2 compliant
Rem    smuralid    11/23/03  - IndexSync: maxDocs->maxSyncTime
Rem    smuralid    11/21/03  - sync in small batches
Rem    smuralid    11/18/03  - sync collides with concurrent inserts/updates
Rem    smuralid    09/30/03  - Stats enhancements: estimate/compute.
Rem                            Only sample (10%) stats during index creation
Rem                            Eliminate sort during stats-collection
Rem    smuralid    09/27/03  - column/value mismatch in insert statements
Rem    smuralid    09/23/03  - create index: force NL joins always
Rem    smuralid    09/22/03  - Handle large strings (> 256)
Rem    smuralid    08/03/03  - IndexCreate: handle parallel index creates
Rem    smuralid    07/30/03  - IndexSync: upper-case index name and schema
Rem    smuralid    07/29/03  - tokenize index column names correctly
Rem                            (handle occasional double-quotes)
Rem

create or replace package body ctx_substr as 

  default_sel   constant  number := 0.1;     -- 0.1 % selectivity     
  default_cost  constant  number := 2;       -- 2 units of I/O

  my_substr_maxlen  constant  number := 256;     -- max substr length
  my_sample_percent constant  number := 10;      -- 10% sample
  -- Number of times we will try to lock the rows of the $P table
  -- during an index-sync
  my_syncLockTries  constant  number := 3;
  -- Time to wait before sync tries to lock rows of the $P table
  -- again
  my_syncLockWait   constant  number := 10;
  -- Max size of a batch to sync
  my_syncMaxBatchSize constant number := 512;
  -- max number of blocks to sample
  my_blocksToSample constant  number := 128;
  -- fudge factor
  my_baseTabRowCountFudge constant number := 2;
  -- sample at least this much from the base table
  my_baseTabSamplePercent constant number := 0.1;

  TYPE indxParams_t is RECORD (
    nopopulate      boolean,
    parallelDegree  binary_integer
  );

  TYPE costRec_t is RECORD (
    tableOwner      varchar2(64),
    tableName       varchar2(64),
    colName         varchar2(64),
    regexp          varchar2(256),
    sel             number,
    cost            sys.odcicost
  );

  costRec           costRec_t;

  procedure put_line(x in varchar2) is 
  begin
    dbms_output.put_line(x);
    null;
  end;

  function getSearchExp(regexp in varchar2, 
                        maxLen in binary_integer default null) 
      return varchar2 is
    regexp_len binary_integer;
    p_regexp   varchar2(4000);
    i          binary_integer := 1;
  begin

    regexp_len := length(regexp);
    while substr(regexp, i, 1) in ('%', '_') loop
      i := i+1;
    end loop;

    -- If the index specifies a max size for the search pattern, truncate
    -- the search pattern
    if (maxlen is null) then
      p_regexp := substr(regexp, i, regexp_len);
    else
      p_regexp := substr(regexp, i, maxLen);
    end if;

    return p_regexp;
  end;

  function getTableName(sch varchar2, ind varchar2, which varchar2) 
    return varchar2 is
  begin
    if (sch is null) then
      return 'DR$' || ind || '$' || which;
    else
      return '"' || sch || '"."DR$' || ind || '$' || which || '"';
    end if;
  end;

  function getIndexName(sch varchar2, ind varchar2, which varchar2) 
    return varchar2 is
  begin
    if (sch is null) then
      return 'DR$' || ind || '$' || which || 'I';
    else
      return '"' || sch || '"."DR$' || ind || '$' || which || 'I"';
    end if;
  end;

  PROCEDURE CreateLogTable(ltab varchar2) is
    stmt  varchar2(4000);
  BEGIN
    stmt := 'create table ' || ltab || '(' ||
            '     oper    varchar2(32), ' ||
            '     tstamp1 timestamp, ' ||
            '     tstamp2 timestamp, ' ||
            '     msg     varchar2(4000), ' ||
            '     info    clob)';
    execute immediate stmt;
  END CreateLogTable;

  FUNCTION IndexCreate (ia sys.odciindexinfo, parms VARCHAR2,
      env sys.ODCIEnv) RETURN NUMBER IS
    itab  varchar2(256);
    ptab  varchar2(256);
    ltab  varchar2(256);
    pidx  varchar2(256); -- index on the $P table
    stmt  varchar2(4000);
    btab  varchar2(256); -- the base table
    colname varchar2(256);
    colinfo sys.ODCIColInfo;
    iinfo  &1..ctx_substr_int.index_info;
    sts    number;
    stats  raw(4000);
    populate boolean; -- should we populate the index
    par_deg  number;  -- parallel degree
    statsOptions sys.ODCIStatsOptions;
  begin
    -- get the name of the indexed column, and the base table
    colinfo := ia.indexcols(1);
    btab := '"' || colinfo.tableSchema || '"."' || colinfo.tableName || '"';
    colname := '"' || colinfo.colname || '"';

    iinfo.index_owner := ia.IndexSchema;
    iinfo.index_name := ia.IndexName;
    iinfo.table_owner := colinfo.tableschema;
    iinfo.table_name := colinfo.tablename;
    iinfo.col_name := ctx_substr_int.stripQuotes(colinfo.colname);

    -- Generate an index metadata entry
    &1..ctx_substr_int.insertIndexInfo(ia.IndexSchema, ia.IndexName,iinfo);
    commit;

    populate := upper(parms) not like '%NOPOPULATE%';
    if (bitand(ia.IndexInfoFlags, ODCIConst.Parallel) = ODCIConst.Parallel) then
      par_deg  := nvl(ia.IndexParaDegree, 0);
    else
      par_deg := 1;
    end if;

    -- Create the $L table first. This allows us to support logging
    -- creation
    ltab := getTableName(ia.IndexSchema, ia.IndexName, 'L');
    CreateLogTable(ltab);

    -- Create the $P table first. This allows us to support online index
    -- creation
    ptab := getTableName(ia.IndexSchema, ia.IndexName, 'P');
    pidx := getIndexName(ia.IndexSchema, ia.IndexName, 'P');
    stmt := 'create table ' || ptab || ' (' ||
              'rid rowid not null, insdel varchar2(1) not null, ' ||
              'str varchar2(4000) not null) ';
    execute immediate stmt;
    stmt := 'create index ' || pidx || ' on ' || ptab || '(rid)';
    execute immediate stmt;


---- DEBUGGING
    -- lock table &1..dr$numseq in exclusive mode;
----

    --
    -- Create the $I table next. While this is going on, other sessions
    -- can perform DML on the base table. Skip any rows that exist in the 
    -- P-table => this is to avoid some weird concurrent interleavings
    --
    itab := getTableName(ia.indexschema, ia.indexname, 'I');
    stmt := 'create table ' || itab || ' (' ||
              'str, rid, primary key(str, rid))' ||
            ' organization index ';

    if (par_deg > 1) then
      stmt := stmt || ' parallel ' || par_deg;
      execute immediate 'alter session enable parallel query';
      execute immediate 'alter session enable parallel ddl';
    end if;

    -- #3385700: use lengthb
    stmt := stmt || 
              ' as select /*+ ordered use_nl(n) */ ' || 
                'substr(substr(b.'|| colinfo.colname || ', n.num, length(b.' || colinfo.colname || ')), 1, ' || my_substr_maxlen || '), b.rowid ' ||
              'from ' || btab || ' b, &1..dr$numseq n ' ||
              'where lengthb(b.' || colinfo.colname || ') <= ' || my_substr_maxlen || ' and ' ||
              '   length(b.' || colinfo.colname || ') >= n.num and ' ||
              '   b.rowid not in (select /*+ use_nl(p) */ rid from ' || ptab  || ' p)';
    if (not populate) then
      stmt := stmt || ' and 1 = 0';
    end if;

    execute immediate stmt;

    -- turn off the parallel degree for this table. We never want this
    -- to go parallel
    execute immediate 'alter table ' || itab || ' noparallel';
---
   put_line('ITAB created');
---

    ---
    --- Now insert all large rows into the P-table
    ---
    stmt := 'insert into ' || ptab || '(rid, insdel, str)' ||
            '  select b.rowid, :largerow, b.' || colinfo.colname || 
            '  from ' || btab || ' b' ||
            '  where lengthb(b.' || colinfo.colname || ') > :my_substr_maxlen and ' ||
            '    b.rowid not in (select rid from ' || ptab || ')';
    execute immediate stmt using 'L', my_substr_maxlen;

    -- Now generate stats
    statsOptions := sys.ODCIStatsOptions(my_sample_percent, ODCIConst.PercentOption, ODCIConst.EstimateStats);
    sts := StatsCollect(colinfo, statsOptions, stats, null);

    return SYS.ODCIConst.Success;
  end;

  FUNCTION IndexDrop(ia sys.odciindexinfo, env sys.ODCIEnv)
     RETURN NUMBER IS
    itab  varchar2(256);
    ptab  varchar2(256);
    ltab  varchar2(256);
    stmt  varchar2(4000);
  begin
    -- Drop the $P table first
    begin
      ptab := getTableName(ia.IndexSchema, ia.IndexName, 'P');
      stmt := 'drop table ' || ptab;
      execute immediate stmt;
    exception
     when others then 
       null;
    end;

    -- Drop the $I table next
    begin
      itab := getTableName(ia.IndexSchema, ia.IndexName, 'I');
      stmt := 'drop table ' || itab;
      execute immediate stmt;
    exception
     when others then 
       null;
    end;

    -- Drop the $L table next
    begin
      ltab := getTableName(ia.IndexSchema, ia.IndexName, 'L');
      stmt := 'drop table ' || ltab;
      execute immediate stmt;
    exception
     when others then 
       null;
    end;

    -- delete the index metadata entry
    &1..ctx_substr_int.deleteIndexInfo(ia.IndexSchema, ia.IndexName);
    commit;

    return SYS.ODCIConst.success;
  end;

  FUNCTION IndexAlter(ia SYS.ODCIIndexInfo,
                                  parms IN OUT VARCHAR2,
                                  alter_option NUMBER,
                                  env SYS.ODCIEnv)
     RETURN NUMBER IS
  begin
    -- todo
    return SYS.ODCIConst.SUCCESS;
  end;

  FUNCTION IndexTruncate(ia sys.ODCIIndexInfo, env sys.ODCIEnv) 
      RETURN NUMBER IS
    ptab  varchar2(256);
    itab  varchar2(256);
    stmt  varchar2(4000);
  begin
    ptab := getTableName(ia.IndexSchema, ia.IndexName, 'P');
    stmt := 'truncate table ' || ptab;
    execute immediate stmt;

    itab := getTableName(ia.IndexSchema, ia.IndexName, 'I');
    stmt := 'truncate table ' || itab;
    execute immediate stmt;
  
    return sys.ODCIConst.Success;
  end;

  FUNCTION IndexInsert(ia sys.odciindexinfo, rid VARCHAR2,
     newval varchar2, env sys.ODCIEnv) RETURN NUMBER IS
    ptab  varchar2(256);
    stmt  varchar2(4000);
  BEGIN
    -- Ignore NULLs or empty strings
    if (newval is null or length(newval) = 0) then
      return SYS.ODCIConst.success;
    end if;

    -- Insert an entry into the $P table
    ptab := getTableName(ia.IndexSchema, ia.IndexName, 'P');
    stmt := 'insert into ' || ptab || 
              '(str, rid, insdel) values(:str, :rid, :insdel)';
    execute immediate stmt 
      using newval, rid, 
            case when lengthb(newval) > my_substr_maxlen then 'L' else 'I' end;

    return SYS.ODCIConst.success;
  end;

  FUNCTION IndexDelete(ia sys.odciindexinfo, rid VARCHAR2,
     oldval varchar2, env sys.ODCIEnv) RETURN NUMBER IS
    
    ptab  varchar2(256);
    stmt  varchar2(4000);
    del_rid rowid := null;
  BEGIN
    -- Ignore NULLs or empty strings
    if (oldval is null or length(oldval) = 0) then
      return SYS.ODCIConst.success;
    end if;

    ptab := getTableName(ia.IndexSchema, ia.IndexName, 'P');

    -- Get rid of any 'I' and 'L' entry for this rowid.
    -- Then add a 'D' entry. 
    -- The invariant that we try to maintain is that there can be 
    -- only one 'I' or 'L' entry for a given rowid, but there can be 
    -- many 'D' entries. A 'I' or 'L' entry overrides all the 'D' entries

    -- First delete any 'I' entries for this row from the $P table
    stmt := 'delete from ' || ptab || 
             ' where insdel in (:del1, :del2) and rid = :rid' || 
             ' returning rid into :del_rid';
    execute immediate stmt using 'I', 'L', rid returning into del_rid;

    -- Now add a new 'delete' entry for this row
    -- Add an entry *only* if the length is less than 256. 
    if (lengthb(oldval) <= my_substr_maxlen) then
      stmt := 'insert into ' || ptab || 
                ' (str, rid, insdel) values(:str, :rid, :insdel)';
      execute immediate stmt using oldval, rid, 'D';
    end if;
    
    return SYS.ODCIConst.success;
  end;

  FUNCTION IndexUpdate(ia sys.odciindexinfo, rid VARCHAR2,
      oldval varchar2, newval varchar2, env sys.ODCIEnv)
     RETURN NUMBER is 
    sts number;
  begin
    sts := IndexDelete(ia, rid, oldval, env);
    sts := IndexInsert(ia, rid, newval, env);

    return sts;
  end;

  PROCEDURE my_lob_append(lob in out nocopy clob, buf in varchar2) IS
  begin
    dbms_lob.writeappend(lob, length(buf), buf);
  end my_lob_append;

  function IndexSync_Verify(ptab varchar2, itab varchar2, 
                            ltab varchar2, 
                            debugLevel number, 
                            debugInfo in out nocopy clob,
                            ptabList       &1..dr$ptab_set_t,
                            uptabList      &1..dr$ptab_set_t,
                            rollbackList   &1..dr$ptab_set_t,
                            urollbackList  &1..dr$ptab_set_t) 
       return boolean is
    sts    boolean := true; -- verification status
    my_count number;
    stmt varchar2(4000);
    type curtyp is ref cursor;
    cur  curtyp;
    my_str varchar2(256);
    my_rid rowid;
    my_insdel varchar2(1);
  begin
    -- don't do much usually
    if (debugLevel <= 1) then
      return true;
    end if;

    -- Get the list of all entries that *must* not be in the $I table
    -- The last 'minus' is to prune out records that have been updated
    -- but with no change. (ie) update T set c = c 
    -- will generate both a 'D' and an 'I' row. The 'D' will get deleted
    -- first, and the 'I' will get inserted later, and we'll still find the 
    -- entry in the $I table
    stmt := 'select str, rid from ' || itab || ' i ' ||
            ' where (str, rid) in ' ||
            '      (select str, rid ' ||
            '       from table(cast(:uptabList as &1..dr$ptab_set_t)) p ' ||
            '       where p.insdel = :insdel1 ' ||
            '       union all ' ||
            '       select str, rid ' ||
            '       from table(cast(:urollbackList as &1..dr$ptab_set_t)) p ' ||
            '       where p.insdel = :insdel2' ||
            '       minus ' ||
            '       select str, rid ' ||
            '       from table(cast(:uptabList as &1..dr$ptab_set_t)) p ' ||
            '       where p.insdel = :insdel3 ' ||
            '      )';
    open cur for stmt using uptabList, 'D', urollbackList, 'I', uptabList, 'I';
    loop
      fetch cur into my_str, my_rid;
      exit when cur%NOTFOUND;
      my_lob_append(debugInfo, '<I_EXTRA><STR>' || my_str || '</STR>' ||
                                     '<RID>' || my_rid || '</RID></I_EXTRA>');
      sts := false;
    end loop;
    close cur;

    -- now check to see if all the rows that should be in $I are
    stmt := 'select p_str, p_rid ' ||
            ' from (select /*+ ordered use_nl(i) */ p.str p_str, ' ||
            '              p.rid p_rid, i.str i_str, i.rid i_rid' ||
            '       from (select str, rid ' || 
            '             from table(cast(:uptabList as &1..dr$ptab_set_t)) p ' ||
            '             where p.insdel = :insdel1 ' ||
            '             minus ' ||
            '             select str, rid ' ||
            '             from table(cast(:urollbackList as &1..dr$ptab_set_t)) p ' ||
            '             where p.insdel = :insdel2 ' ||
            '            ) p, ' || itab || ' i ' ||
            '       where p.str = i.str(+) and p.rid = i.rid(+)) ' ||
            ' where i_str is null and i_rid is null';
    open cur for stmt using uptabList, 'I', urollbackList, 'I';
    loop
      fetch cur into my_str, my_rid;
      exit when cur%NOTFOUND;
      my_lob_append(debugInfo, '<I_MISSING><STR>' || my_str || 
                                             '</STR>' ||
                                 '<RID>' || my_rid || '</RID></I_MISSING>');
      sts := false;
    end loop;
    close cur;

    -- Check to see that all deletes from $P have gone through
    stmt := 'select str,rid,insdel from ' || ptab || 'p ' ||
            ' where (str, rid, insdel) in ' ||
            '      (select str, rid , insdel ' ||
            '       from table(cast(:ptabList as &1..dr$ptab_set_t)) p ' ||
            '       minus ' ||
            '       select str, rid, insdel ' ||
            '       from table(cast(:rollbackList as &1..dr$ptab_set_t)) p ' ||
            '      )';

    open cur for stmt using ptabList, rollbackList;
    loop
      fetch cur into my_str, my_rid, my_insdel;
      exit when cur%NOTFOUND;
      my_lob_append(debugInfo, '<P_EXTRA>' || 
                                        '<STR>' || my_str || '</STR>' ||
                                        '<RID>' || my_rid || '</RID>' ||
                                        '<INSDEL>' ||my_insdel|| '</INSDEL>' ||
                                      '</P_EXTRA>');
      sts := false;
    end loop;
    close cur;

    if (sts = false) then
      my_lob_append(debugInfo, '<PTAB_LIST>');
      for i in 1..ptabList.COUNT loop
        my_lob_append(debugInfo, '<PTAB_ENTRY>' ||
                                      '<STR>' || ptabList(i).str || '</STR>' ||
                                      '<RID>' || ptabList(i).rid || '</RID>' ||
                                      '<INSDEL>' || ptabList(i).insdel || '</INSDEL>' ||
                                      '</PTAB_ENTRY>');
      end loop;
      my_lob_append(debugInfo, '</PTAB_LIST>');

      my_lob_append(debugInfo, '<ROLLBACK_LIST>');
      for i in 1..rollbackList.COUNT loop
        my_lob_append(debugInfo, '<PTAB_ENTRY>' ||
                                      '<STR>' || rollbackList(i).str || '</STR>' ||
                                      '<RID>' || rollbackList(i).rid || '</RID>' ||
                                      '<INSDEL>' || rollbackList(i).insdel || '</INSDEL>' ||
                                      '</PTAB_ENTRY>');
      end loop;
      my_lob_append(debugInfo, '</ROLLBACK_LIST>');
    end if;

    return sts;

  exception
    when others then
      return false;
  end IndexSync_Verify;

  function unnestPtabList(ptabList in &1..dr$ptab_set_t) 
      return &1..dr$ptab_set_t is
    uptabList &1..dr$ptab_set_t := &1..dr$ptab_set_t();
    uptabCard binary_integer := 0;
    str_len   binary_integer;
  begin
    for i in 1..ptabList.COUNT loop
      str_len := length(ptabList(i).str);
      uptabList.extend(str_len);
      for j in 1..str_len loop
        uptabCard := uptabCard + 1;
        uptabList(uptabCard) := ptabList(i);
        uptabList(uptabCard).str := substr(ptabList(i).str, j, str_len);
      end loop;
    end loop;
    return uptabList;
  end unnestPtabList;

  procedure logMessage(logtab varchar2, oper varchar2,
                       tstamp1 timestamp, tstamp2 timestamp,
                       msg    varchar2,
                       info   clob) is
    pragma autonomous_transaction;
    stmt   varchar2(4000);
    ora942 exception;
    pragma exception_init(ora942, -942);
  begin
    if (logtab is not null) then
      stmt := 'insert into ' || logtab || 
                   '(oper, tstamp1, tstamp2, msg, info)' ||
              ' values(:oper, :tstamp1, :tstamp2, :msg, :info)';
      execute immediate stmt using oper, tstamp1, tstamp2, 
                                   substr(msg, 1, 4000), info;
      commit;
    end if;
  exception
    when ora942 then 
      CreateLogTable(logtab);
    when others then
      null;
    commit;
  end;

  function IndexSync_OneBatch(tstamp timestamp, 
                              ptab  varchar2, itab varchar2, ltab varchar2,
                              batchSize number, debugLevel number, 
                              debugInfo in out nocopy clob)  
        return boolean is
    istmt  varchar2(4000);
    pstmt  varchar2(4000);
    pstmt1 varchar2(4000);
    pstmt2 varchar2(4000);
    stmt   varchar2(4000);
    type rid_cur_type is ref cursor;
    rid_cur      rid_cur_type;   -- cursor to lock rows of the $P table
    p_rid        rowid;           -- rid column of the $P table
    ptabEntry    &1..dr$ptab_t := &1..dr$ptab_t(null, null, null, null);
    ptabList     &1..dr$ptab_set_t := &1..dr$ptab_set_t();
    uptabList    &1..dr$ptab_set_t := &1..dr$ptab_set_t();
    rollbackList &1..dr$ptab_set_t := &1..dr$ptab_set_t();
    urollbackList &1..dr$ptab_set_t := &1..dr$ptab_set_t();
    gotLock      boolean;
    my_tstamp    timestamp := systimestamp;
    msg          varchar2(4000);
    sts          boolean := true;
  BEGIN
    logMessage(ltab, 'SYNC-BATCH', tstamp, systimestamp, 
               'Starting Sync Batch...', null);
    put_line('Starting a sync batch');

    -- Lock out any concurrent syncs. We do this by locking the 'I' table
    -- If you can't get this lock immediately, just return. Don't 
    -- wait - this means that another sync is still running
    stmt := 'lock table ' || itab || ' in exclusive mode nowait';
    begin 
      execute immediate stmt;
    exception
      when others then
        sts := false;
        msg := 'Failed to lock $I';
        goto done_IndexSync_OneBatch;
    end;

    --
    -- Get a small set of rows to process first
    --
    stmt := 'select /*+ ordered use_nl(p) index(p) */ ' ||
            '   p.rowid, p.rid, p.insdel, p.str ' ||
            ' from (select rid ' ||
            '       from (select /*+ index(p1) */ distinct rid ' ||
            '             from ' || ptab || ' p1 ' ||
            '             where p1.insdel <> :insdel)' ||
            '       where rownum <= :batchSize) p2, ' ||
                    ptab || ' p ' ||
            ' where p.rid = p2.rid and ' ||
            '       p.insdel <> :insdel';

    -- There shall be no large rows here. 
    open rid_cur for stmt using 'L', batchSize, 'L';
    loop
      fetch rid_cur into ptabEntry.prid,
                         ptabEntry.rid, 
                         ptabEntry.insdel,
                         ptabEntry.str;
      exit when rid_cur%NOTFOUND;
      ptabList.extend;
      ptabList(ptabList.COUNT) := ptabEntry;
    end loop;
    close rid_cur;

    put_line('Processing ' || ptabList.COUNT || ' rows');

    if (debugLevel > 0) then
      my_lob_append(debugInfo, 
                           '<BATCH_COUNT>' || ptabList.COUNT ||
                           '</BATCH_COUNT>');
    end if;

    -- Do we have anything to do ?
    if (ptabList.COUNT <= 0) then
      commit;
      sts := false;
      msg := 'No rows to process';
      goto done_IndexSync_OneBatch;
    end if; 

    -- Unnest the ptabList
    uptabList := unnestPtabList(ptabList);

    -- First get rid of all rows that have been deleted
    istmt := 'delete from ' || itab ||
             ' where (str, rid) in ' || 
             '    (select p.str, p.rid ' ||
             '     from table(cast(:uptabList as &1..dr$ptab_set_t)) p ' ||
             '     where p.insdel = :insdel)';
    execute immediate istmt using uptabList, 'D';

    put_line('Deleted rows from $I');
  
    -- Now insert all new (non-large) rows into the $I table
    istmt := 'insert into ' || itab ||
             ' select p.str, p.rid ' ||
             ' from table(cast(:uptabList as &1..dr$ptab_set_t)) p ' ||
             ' where p.insdel = :insdel';
    execute immediate istmt using uptabList, 'I';

    put_line('Inserted rows to $I');

    -- Delete our batch of entries from the $P table. We try to get
    -- row locks for each entry. If we get a lock for the entry, then
    -- we delete the entry. Otherwise, we add the entry to a rollback list
    -- which is processed below.
    -- This allows us to avoid any deadlocks
    pstmt1 := 'select rid from ' || ptab || 
              ' where rowid = :prid and rid = :rid and str = :str and ' ||
              '       insdel = :insdel for update nowait';
    pstmt2 := 'delete from ' || ptab || 
              ' where rowid = :prid and rid = :rid and str = :str and ' ||
              '       insdel = :insdel';
    for i in 1..ptabList.COUNT loop
      ptabEntry := ptabList(i);
      p_rid := null;
      gotLock := false;
      begin
        -- #(3378719), #(3305460): Need INTO clause to raise ORA-1403
        -- otherwise, we're missing the case, where we saw an 'I' row initially
        -- and we wrote the entry to the $I table, but before we deleted the
        -- entry from the $P table, some other txn has deleted the row and
        -- commited the txn. Without the INTO clause, no error is raised,
        -- and we end up in a state where the $I table now contains a deleted
        -- rowid, and there's no entry in $P to override this
        execute immediate pstmt1 
          into p_rid 
          using ptabEntry.prid, ptabEntry.rid, ptabEntry.str, ptabEntry.insdel;
        gotLock := true;
        -- Do the delete from $P only if we got the row-lock   
        execute immediate pstmt2 
          using ptabEntry.prid, ptabEntry.rid, ptabEntry.str, ptabEntry.insdel;
      exception
        when others then 
          rollbackList.extend;
          rollbackList(rollbackList.COUNT) := ptabEntry;
      end;
    end loop;

    if (debugLevel > 0) then
      my_lob_append(debugInfo, 
                    '<ROLLBACK_COUNT>' || rollbackList.COUNT ||
                    '</ROLLBACK_COUNT>');
    end if;

    -- get the unnested version of the rollback list
    urollbackList := unnestPtabList(rollbackList);

    -- Now perform the rollbacks
    --
    -- rollback any inserts into $I for the entries for which
    -- we didn't get locks.
    -- We don't need to rollback the deletes from $I. This is based
    -- on the assumption that we can only get any contention on 'I' rows
    if (urollbackList.COUNT > 0) then
      istmt := 'delete from ' || itab ||
               ' where (str, rid) in ' || 
               '    (select p.str, p.rid ' ||
               '     from table(cast(:urollbackList as &1..dr$ptab_set_t)) p ' ||
               '     where p.insdel = :insdel)';
      execute immediate istmt using urollbackList, 'I';
      put_line('Rolling back ' || urollbackList.COUNT || ' rows from $I (for ' || rollbackList.COUNT || ' rows in $P)');
    end if;

    -- Run a verification step
    sts := IndexSync_Verify(ptab, itab, ltab, debugLevel, debugInfo,
                            ptabList, uptabList, 
                            rollbackList, urollbackList);

    if (sts = false) then
      rollback;
      msg := 'Sync Verify: Inconsistency detected';
    else
      -- commit the txn. releases the locks as well
      commit;
      msg := 'Sync Batch done';
    end if;
    
<<done_IndexSync_OneBatch>>
    logMessage(ltab, 'SYNC-BATCH', tstamp, systimestamp, 
               msg, debugInfo);
    
    -- Run a post-sync verification step. Lets see if there's any way that
    -- deleted rowids can get into the $I table
--    IndexPostSync_Verify(ptab, itab, ltab, debugLevel, debugInfo,
--                         ptabList, uptabList, 
--                         rollbackList, urollbackList);

    return sts;
  exception 
    when others then
      rollback;
      logMessage(ltab, 'SYNC-BATCH', tstamp, systimestamp, 
                 'Sync Batch failed with error: ' || sqlerrm(sqlcode), 
                 debugInfo);
      return false;
  END IndexSync_OneBatch;
 
  procedure IndexSync(indexOwner  varchar2, indexName varchar2, 
                      batchSize   number default 128,
                      maxTime     number default 120,
                      debugLevel  number default 0) is
    indexOwner_l varchar2(256) := upper(indexOwner);
    indexName_l  varchar2(256) := upper(indexName);
    itab  varchar2(256);    
    ptab  varchar2(256);
    ltab  varchar2(256) := null;    -- log table
    sts          boolean;   -- status of each batch sync
    stime        number;
    etime        number := 0;
    maxDocs      number := 0;
    tstamp       timestamp := systimestamp;
    info         clob;
  BEGIN

    if (debugLevel > 0) then
      ltab := getTableName(indexOwner_l, indexName_l, 'L');
      dbms_lob.createtemporary(info, true);
    end if;

    logMessage(ltab, 'SYNC', tstamp, null, 'Starting Sync...', null);
    
    if (batchSize <= 0) then
      goto done_IndexSync;
    end if;

    ptab := getTableName(indexOwner_l, indexName_l, 'P');
    itab := getTableName(indexOwner_l, indexName_l, 'I');

    if (maxTime = 0) then
      execute immediate 'select count(*) from ' || ptab 
        into maxDocs;
    end if;

    -- Run through the Pending table in batches
    loop
       
      stime := dbms_utility.get_time;
      if (info is not null) then
        dbms_lob.trim(info, 0);
      end if;
      sts := IndexSync_OneBatch(tstamp, ptab, itab, ltab, 
                                batchSize, debugLevel, info);
      if (sts = false) then
        goto done_IndexSync;
      end if;

      etime := etime + (dbms_utility.get_time - stime)/100;

      if (maxTime <> 0) then
        -- max time exceeded
        if (etime >= maxTime) then
          goto done_IndexSync;
        end if;
      else
        -- max docs exceeded
        if (maxDocs <= batchSize) then
          goto done_IndexSync;
        end if;
        maxDocs := maxDocs - batchSize;
      end if;
      
    end loop;

    -- update statistics ??
<<done_IndexSync>>
    logMessage(ltab, 'SYNC', tstamp, systimestamp, 'Sync Done...', null);
    if (info is not null) then
      dbms_lob.freetemporary(info);
    end if;
    return;

  end;

  FUNCTION IndexStart(sctx IN OUT lyke_idxtype_im,
     ia sys.odciindexinfo,
     op sys.odciPredInfo, qi sys.ODCIQueryInfo,
     regexp varchar2, 
     env sys.ODCIEnv) RETURN NUMBER is 

    p_regexp  varchar2(256);
    junk      number;
    itab      varchar2(256);
    ptab      varchar2(256);
    stmt      varchar2(4000);
    firstChar varchar2(1);
  begin

    p_regexp := getSearchExp(regexp);    

    sctx := lyke_idxtype_im(0,0);
    sctx.i_cur := dbms_sql.open_cursor;

    itab := getTableName(ia.IndexSchema, ia.IndexName, 'I');
    ptab := getTableName(ia.IndexSchema, ia.IndexName, 'P');

    stmt := 'select /* Lyke_Query */ distinct rid from ' || itab || 
               'where str like :regexp1 and ' ||
                 'rid not in (select rid from ' || ptab || 
                              ' where insdel = :insdel1)' ||
            'union all ' ||
            'select distinct rid from ' || ptab || 
               'where str like :regexp2 and insdel in (:insdel2, :insdel3)';

    dbms_sql.parse(sctx.i_cur, stmt, dbms_sql.native);
    dbms_sql.bind_variable(sctx.i_cur, ':regexp1', p_regexp);
    dbms_sql.bind_variable(sctx.i_cur, ':insdel1', 'D');
    dbms_sql.bind_variable(sctx.i_cur, ':regexp2', regexp);
    dbms_sql.bind_variable(sctx.i_cur, ':insdel2', 'I');
    dbms_sql.bind_variable(sctx.i_cur, ':insdel3', 'L');
    junk := dbms_sql.execute(sctx.i_cur);

    sctx.i_eof := 0;

    return SYS.ODCIConst.success;

  end;

  FUNCTION fetchFromCur(p_curno number, nrows number, 
                        rids IN OUT nocopy sys.odciridlist) 
      RETURN binary_integer IS
    curno  number := p_curno;
    rowcount binary_integer := 0;
    r rowid;
  BEGIN
    dbms_sql.define_column_rowid(curno, 1, r);
    for i in nvl(rids.last, 0) + 1..nrows loop
      if (dbms_sql.fetch_rows(curno) > 0) then
        dbms_sql.column_value_rowid(curno, 1, r);
        rids.extend;
        rids(i) := r;
        rowcount := rowcount + 1;
      else
        dbms_sql.close_cursor(curno);
        return rowcount;
      end if;
    end loop;
    return rowcount;
  END;

  FUNCTION IndexFetch(sctx IN OUT lyke_idxtype_im, 
                      nrows NUMBER, rids OUT sys.odciridlist,
      env sys.ODCIEnv) RETURN NUMBER is
    r rowid;
    rowcount binary_integer := 0;
  begin
    rids := sys.odciridlist();

    if (sctx.i_eof = 0) then
      rowcount := fetchFromCur(sctx.i_cur, nrows, rids);
      if (rowcount < nrows) then
        sctx.i_eof := 1;
      end if;
    end if;

    return SYS.ODCIConst.success;
  end;

  FUNCTION IndexClose(sctx IN OUT lyke_idxtype_im, env sys.ODCIEnv) 
       RETURN NUMBER IS
  begin
    if (sctx.i_eof = 0) then
      dbms_sql.close_cursor(sctx.i_cur);
      sctx.i_eof := 1;
    end if;

    return SYS.ODCIConst.success;
    
  end;

  FUNCTION StatsCollect(iinfo in out ctx_substr_int.index_info,
                        options SYS.ODCIStatsOptions,
                        statistics OUT RAW, env SYS.ODCIEnv)
    return NUMBER is 
    itab  varchar2(256);
    itab_name  varchar2(256);
    sql_stmt varchar2(4000);
    block_size number;
    avgrowlen     number;
    avgstrlen     number;
    sample_percent   number;
    estimate_stats boolean := false;
    compute_stats  boolean := false;
  begin
    itab := getTableName(iinfo.Index_owner, iinfo.index_name, 'I');
    itab_name := getTableName(null, iinfo.index_name, 'I');

    -- Treat NULL options as equivalent to sample 10%
    if (options is null) then
      estimate_stats := true;
      sample_percent := my_sample_percent;
    else
      if (bitand(options.flags, ODCIConst.EstimateStats) = ODCIConst.EstimateStats) then
        estimate_stats := true;
        sample_percent := options.sample;
      end if;
      if (bitand(options.flags, ODCIConst.ComputeStats) = ODCIConst.ComputeStats) then
        compute_stats := true;
      end if;
    end if;

    --- Ignore calls to VALIDATE the index
    if (not estimate_stats and not compute_stats) then
      return ODCIConst.Success;
    end if;

    -- Ignore the ROWS option
    if estimate_stats then
      if options.options = ODCIConst.RowOption then
        sample_percent := my_sample_percent;
      end if;
      if (sample_percent is null) then
        sample_percent := my_sample_percent;
      end if;
    end if;

    ---
    --- NOTE: We used to get count(distinct rid) as well, but that requires
    ---   a sort, and for large tables, this gets to be really expensive.
    ---   We could instead simply perform a count of the base table.
    ---   What we do instead is to estimate this based on the number of 
    ---   substrings of length 1.
    ---
    sql_stmt := 'select count(rid), ' ||
                '       sum(case when length(str) = 1 then 1 else 0 end),' ||
                '       avg(length(str)), avg(length(str) + 10 + 2) ' ||
                ' from ' || itab;
    if (estimate_stats) then
      sql_stmt := sql_stmt || ' sample (' || sample_percent || ')';
    end if;
    execute immediate sql_stmt 
      into iinfo.row_count, iinfo.row_count_d, avgstrlen, avgrowlen;

---
    put_line('got row count = ' || iinfo.row_count);
---

    --- Scale up the results if we're estimating
    if estimate_stats then
      iinfo.row_count := iinfo.row_count * 100/sample_percent;
      iinfo.row_count_d := iinfo.row_count_d * 100/sample_percent;
    end if;

    if (iinfo.row_count > 0) then
      --  Now calculate the block size for the index
      sql_stmt := 'select t.block_size from user_tablespaces t,all_indexes i ' ||
                ' where i.table_name = :index_name and ' ||
                      ' i.owner = :index_owner and ' ||
                      ' i.tablespace_name = t.tablespace_name';
      execute immediate sql_stmt 
        into block_size
        using itab_name, iinfo.index_owner;

---
    put_line('got block size = ' || block_size);
---

      iinfo.rows_per_block := block_size / avgrowlen;
    end if;

    &1..ctx_substr_int.updateIndexInfo(iinfo.Index_Owner, iinfo.Index_Name,
                                          iinfo);
    commit;
    
    return ODCIConst.SUCCESS;

  end;

  FUNCTION StatsCollect(col SYS.ODCIColInfo,
                        options SYS.ODCIStatsOptions,
                        statistics OUT RAW, env SYS.ODCIEnv)
    return NUMBER is 
    iinfo  &1..ctx_substr_int.index_info;
  begin
---
    put_line('getting info for ');
    put_line(col.TableSchema);
    put_line(col.TableName);
    put_line(col.ColName);
---
    -- Check privileges first
    iinfo := &1..ctx_substr_int.getIndexInfoByCol(col.TableSchema,
                                                     col.TableName,
				                     col.ColName);
---
    put_line('got info');
---
    return StatsCollect(iinfo, options, statistics, env);
  end;

  FUNCTION StatsCollect(ia SYS.ODCIIndexInfo,
                        options SYS.ODCIStatsOptions,
                        statistics OUT RAW, env SYS.ODCIEnv)
    return NUMBER is 
    iinfo  &1..ctx_substr_int.index_info;
  begin
    -- Check privileges first

    iinfo := &1..ctx_substr_int.getIndexInfo(ia.IndexSchema, ia.IndexName);
---
    put_line('got info');
---
    return StatsCollect(iinfo, options, statistics, env);
  end;

  FUNCTION StatsDelete(iinfo in out &1..ctx_substr_int.index_info,
                       statistics OUT RAW, env SYS.ODCIEnv)
    return NUMBER is

  begin
    -- zero out all the stats we've collected so far
    iinfo.row_count := 0;
    iinfo.row_count_d := 0;
    iinfo.rows_per_block := 0;
    iinfo.default_row_count := 0;
    iinfo.default_row_count_d := 0;

    &1..ctx_substr_int.updateIndexInfo(iinfo.Index_Owner, iinfo.Index_Name,
                                          iinfo);
    commit;
    return Sys.ODCIConst.Success;
  end;

  FUNCTION StatsDelete(col SYS.ODCIColInfo,
                       statistics OUT RAW, env SYS.ODCIEnv)
    return NUMBER is
    iinfo  &1..ctx_substr_int.index_info;
  begin
    -- Check privileges first

    iinfo := &1..ctx_substr_int.getIndexInfoByCol(col.TableSchema,
                                                     col.TableName,
				                     col.ColTypeName);

    return StatsDelete(iinfo, statistics, env);
  end;

  FUNCTION StatsDelete(ia SYS.ODCIIndexInfo,
                       statistics OUT RAW, env SYS.ODCIEnv)
    return NUMBER is
    iinfo  &1..ctx_substr_int.index_info;
  begin
    -- Check privileges first

    iinfo := &1..ctx_substr_int.getIndexInfo(ia.IndexSchema,
						ia.IndexName);

    return StatsDelete(iinfo, statistics, env);
  end;

  FUNCTION getCachedCostAndSel(p_owner varchar2, p_tablename varchar2,
                               p_colname varchar2,
                               regexp varchar2,
                               sel OUT number, cost OUT sys.odcicost)
    return boolean is
  begin
    if (costRec.tableOwner = p_owner AND 
        costRec.tableName = p_tablename AND
        costRec.colName = p_colname AND
        costRec.regexp = regexp) then
      sel := costRec.sel;
      cost := costRec.cost;
      return true;
    else
      return false;
    end if;
  end;

  PROCEDURE cacheCostAndSel(p_owner varchar2, p_tablename varchar2,
                            p_colname varchar2,
                            regexp varchar2,
                            sel number, cost sys.odcicost) is
  begin
    costRec.tableOwner := p_owner;
    costRec.tableName  := p_tablename;
    costRec.colName    := p_colname;
    costRec.regexp     := regexp;
    costRec.sel        := sel;
    costRec.cost       := cost;
  end;

  FUNCTION computeCostAndSel(pred SYS.ODCIPredInfo, arg SYS.ODCIArgDesc,
                             regexp varchar2,
                             strt number, stop number,
			     env SYS.ODCIEnv,
                             sel OUT number, cost OUT SYS.ODCICost) 
    return number is
    iinfo    &1..ctx_substr_int.index_info;
    sql_stmt varchar2(4000);
    itab     varchar2(128);
    p_regexp varchar2(4000);         -- the string we're searching for
    nrows    binary_integer;
    nrows_d  binary_integer;
    maxrows  number;
    samp     number;   -- sample size
    btab  varchar2(256); -- the base table
    colinfo sys.ODCIColInfo;
  begin
    if (arg.ColName is not null and
      -- check to see if its already cached
        getCachedCostAndSel(arg.TableSchema, arg.TableName, arg.ColName,
                            regexp, sel, cost)) then
      return odciconst.success;
    end if;

    cost := sys.ODCICost(0, default_cost, 0, null);

    if (arg.ColName is not null) then
      iinfo := &1..ctx_substr_int.getIndexInfoByCol(arg.TableSchema,
                                                       arg.TableName,
						       arg.ColName);
    else
      -- Raise an error here.
      sel := default_sel;
      return SYS.ODCIConst.SUCCESS;
    end if;

----
    put_line('Loaded stats:');
    put_line('Rowcount, Rowcount_d = ' || iinfo.row_count || ',' || iinfo.row_count_d);
    put_line('RowsPerBlock = ' || iinfo.rows_per_block);
----

    -- If no stats have been gathered yet, then simply return the defaults
    if (iinfo.row_count_d is null or iinfo.row_count_d = 0) then
      sel := default_sel;
      return SYS.ODCIConst.SUCCESS;
    end if;

    p_regexp := getSearchExp(regexp);
    itab := getTableName(iinfo.index_owner, iinfo.index_name, 'I');

    -- We will compute the cardinality in multiple phases.
    -- In phase 1, we will try to get an exact match - while not selecting 
    -- more than 128 blocks
    -- In phase 2, we will try to sample the base table, and get a count of the number
    -- of rows that match this predicate
    
    -- Now find the number of rows that match this particular regexp
    maxrows := trunc(my_blocksToSample * iinfo.rows_per_block);
    if (maxrows < 1000) then
      maxrows := 1000;
    end if;
    sql_stmt := 'select /* Lyke_Estimate: Exact  */ count(rid), count(distinct rid) ' ||
                ' from (' || 
                   ' select rid from ' || itab ||
                   ' where str like :p_regexp) where rownum < :maxrows';
    execute immediate sql_stmt 
       into nrows, nrows_d
       using p_regexp, maxrows;

--
    put_line('Nrows, Nrows_d (sample 100) = ' || nrows || ',' || nrows_d); 
--
    if (nrows < maxrows - 1) then
      goto got_count;
    end if;

    -- Start sampling on the base table
    -- Choose the sampling percentage so that we read at least a reasonable number of
    -- blocks; 
    btab := '"' || arg.tableSchema || '"."' || arg.tableName || '"';
    if (iinfo.row_count_d < maxrows) then
      samp := 100;
    else
      samp := (maxrows * 100)/ iinfo.row_count_d;
      if (samp < my_baseTabSamplePercent) then
        samp := my_baseTabSamplePercent;
      end if;
    end if;
---
    put_line('Using sample percent ' || samp);
---
    sql_stmt := 'select /* Lyke_Estimate: BaseTableSample */ ' ||
                '   100 * sum(case when str like :pat then 1 else 0 end)/(count(*) + 1)' ||
                ' from (select ' || arg.colname || ' str ' ||
                '       from ' || btab || ' sample block(' || samp || ') b) ' ||
                ' where rownum < :maxrows';
    execute immediate sql_stmt 
      into sel
      using regexp, maxrows;

    -- Scale up the estimated number of matching
    nrows_d := iinfo.row_count_d * (sel / 100);
    nrows   := nrows_d * my_baseTabRowCountFudge;  -- fudge factor for cost

<<got_count>>
----
    put_line('Sampled stats for ' || p_regexp);
    put_line('Nrows = ' || nrows || ' nrows_d = ' || nrows_d);
----

    -- Now calculate the selectivity, and the cost as well
    sel := (nrows_d * 100)/ iinfo.row_count_d;
    cost.IOCost := nrows / iinfo.rows_per_block; 
    if (sel > 100) then
      sel := 100;
    end if;
----
    put_line('Sel, Cost = ' || sel || ',' || cost.IOCost);
----
    --- There should be at least 1 I/O needed
    if (cost.IOCost = 0) then
      cost.IOCost := 1;
    end if;

    -- cache this for some future use
    cacheCostAndSel(arg.TableSchema, arg.TableName, arg.ColName, regexp,
                    sel, cost);
    return SYS.ODCIConst.SUCCESS;

  end;

  FUNCTION StatsSelectivity(pred SYS.ODCIPredInfo, sel OUT NUMBER,
                            args SYS.ODCIArgDescList,
                            strt number, stop number,
                            regexp varchar2,
                            env SYS.ODCIEnv) 
    return number is
    cost        SYS.ODCICost;
    status      number;
  begin
    status := computeCostAndSel(pred, args(3), regexp, strt, stop, env,
                                sel, cost);
    return status;
  end;

  FUNCTION StatsIndexCost(ia SYS.ODCIIndexInfo, sel NUMBER,
                          cost OUT SYS.ODCICost, qi SYS.ODCIQueryInfo,
                          pred SYS.ODCIPredInfo,
                          args SYS.ODCIArgDescList,
                          strt number,
                          stop  number,
                          regexp varchar2,
                          env SYS.ODCIEnv)
    return NUMBER is
    status      number;
    p_sel       number;
  begin
    status := computeCostAndSel(pred, args(3), regexp, strt, stop, env,
                                p_sel, cost);
    return status;
  end;

  FUNCTION StatsFunctionCost(func SYS.ODCIFuncInfo,
                                        cost OUT SYS.ODCICost,
                                        args SYS.ODCIArgDescList,
                                        regexp varchar2,
                                        env SYS.ODCIEnv)
    return NUMBER is
  begin
    -- Evaluating a pl/sql function is way more expensive than a builtin.
    -- The cost for LIKE is estimated to be 100. I'm going to choose 10000
    -- which makes this about 100 times slower
    -- 
    cost := sys.ODCICost(10000, 0, 0, null);
    return SYS.ODCIConst.SUCCESS;
  end;

  
end ctx_substr;
/
show errors;



create or replace package ctx_lyke authid current_user is
  -- Functional implementation of the LYKE operator
  function LYKE(colval in varchar2, regexp in varchar2)
                return number;
end ctx_lyke;
/
show errors;
grant execute on ctx_lyke to public;

create or replace package ctx_lyke_postfilter authid current_user is
  -- Functional implementation of the LYKE operator
  function LYKE(colval in varchar2, regexp in varchar2)
                return number;
end ctx_lyke_postfilter;
/
show errors;
grant execute on ctx_lyke_postfilter to public;
associate statistics with packages ctx_lyke_postfilter default selectivity 100;

Rem
Rem Create the lyke operator
Rem
create or replace operator lyke binding
  (varchar2, varchar2) return number
    using ctx_lyke.lyke;
grant execute on lyke to public;

create or replace operator lyke_pf binding
  (varchar2, varchar2) return number
    using ctx_lyke_postfilter.lyke;
grant execute on lyke_pf to public;

Rem 
Rem Create the substr index implementation type
Rem
CREATE OR REPLACE TYPE lyke_idxtype_im authid current_user as object
(
  i_cur   number,   -- a cursor number
  i_eof   number,

  static function ODCIGetInterfaces(ifclist OUT sys.ODCIObjectList)
     return NUMBER,

  STATIC FUNCTION ODCIIndexCreate (ia sys.odciindexinfo, parms VARCHAR2,
     env sys.ODCIEnv) RETURN NUMBER,
  STATIC FUNCTION ODCIIndexDrop(ia sys.odciindexinfo, env sys.ODCIEnv)
     RETURN NUMBER,

  STATIC FUNCTION ODCIIndexAlter(ia sys.ODCIIndexInfo,
                                  parms IN OUT VARCHAR2,
                                  alter_option NUMBER,
                                  env sys.ODCIEnv)
     RETURN NUMBER,
  STATIC FUNCTION ODCIIndexTruncate(ia sys.ODCIIndexInfo,
                                     env sys.ODCIEnv)
     RETURN NUMBER,

  STATIC FUNCTION ODCIIndexStart(sctx IN OUT lyke_idxtype_im,
     ia sys.odciindexinfo,
     op sys.odciPredInfo, qi sys.ODCIQueryInfo,
     strt number, stp number,
     regexp varchar2, 
     env sys.ODCIEnv) RETURN NUMBER,

  MEMBER FUNCTION ODCIIndexFetch(self IN OUT lyke_idxtype_im, 
      nrows NUMBER, rids OUT sys.odciridlist,
      env sys.ODCIEnv) RETURN NUMBER,

  MEMBER FUNCTION ODCIIndexClose(self IN OUT lyke_idxtype_im, 
      env sys.ODCIEnv) RETURN NUMBER,


  STATIC FUNCTION ODCIIndexInsert(ia sys.odciindexinfo, rid VARCHAR2,
    newval varchar2, env sys.ODCIEnv) RETURN NUMBER,

  STATIC FUNCTION ODCIIndexDelete(ia sys.odciindexinfo, rid VARCHAR2,
    oldval varchar2, env sys.ODCIEnv) RETURN NUMBER,

  STATIC FUNCTION ODCIIndexUpdate(ia sys.odciindexinfo, rid VARCHAR2,
    oldval varchar2, newval varchar2, env sys.ODCIEnv)
     RETURN NUMBER
);
/
show errors;

CREATE or replace type lyke_idxtype_stats authid current_user AS OBJECT
(
  dummy varchar2(1),
  STATIC FUNCTION ODCIGetInterfaces(ifclist OUT sys.ODCIObjectList)
    RETURN NUMBER,
  STATIC FUNCTION ODCIStatsCollect(col sys.ODCIColInfo,
                                   options sys.ODCIStatsOptions,
                                   statistics OUT RAW, env sys.ODCIEnv)
    return NUMBER,
  STATIC FUNCTION ODCIStatsCollect(ia sys.ODCIIndexInfo,
                                   options sys.ODCIStatsOptions,
                                   statistics OUT RAW, env sys.ODCIEnv)
    return NUMBER,
  STATIC FUNCTION ODCIStatsDelete(col sys.ODCIColInfo,
                                  statistics OUT RAW, env sys.ODCIEnv)
    return NUMBER,
  STATIC FUNCTION ODCIStatsDelete(ia sys.ODCIIndexInfo,
                                  statistics OUT RAW, env sys.ODCIEnv)
    return NUMBER,
  STATIC FUNCTION ODCIStatsSelectivity(pred sys.ODCIPredInfo, sel OUT NUMBER,
                                       args sys.ODCIArgDescList,
                                       strt number, stop number,
                                       colarg varchar2, regexp varchar2,
                                       env sys.ODCIEnv)
    return NUMBER,
  STATIC FUNCTION ODCIStatsIndexCost(ia sys.ODCIIndexInfo, sel NUMBER,
                                     cost OUT sys.ODCICost, 
                                     qi sys.ODCIQueryInfo,
                                     pred sys.ODCIPredInfo,
                                     args sys.ODCIArgDescList,
                                     strt number,
                                     stop  number,
                                     regexp varchar2,
                                     env sys.ODCIEnv)
    return NUMBER,
  STATIC FUNCTION ODCIStatsFunctionCost(func sys.ODCIFuncInfo, 
                                        cost OUT sys.ODCICost,
                                       args sys.ODCIArgDescList,
                                       colarg varchar2, regexp varchar2,
                                       env sys.ODCIEnv)
    return NUMBER
);
/
show errors;

grant execute on lyke_idxtype_stats to public;


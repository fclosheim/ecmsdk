Rem 
Rem Create the ctxsubstr indextype
Rem
create or replace indextype ctxsubstr for
  lyke(varchar2, varchar2)
 using lyke_idxtype_im
 with rebuild online;

grant execute on ctxsubstr to public;

whenever sqlerror continue;

disassociate statistics from indextypes ctxsubstr;
disassociate statistics from packages ctx_lyke;

whenever sqlerror exit sql.sqlcode;

associate statistics with indextypes ctxsubstr using lyke_idxtype_stats;
associate statistics with packages ctx_lyke  using lyke_idxtype_stats;



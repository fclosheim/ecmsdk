Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    smuralid    12/08/03  - Creation (moved from dr0substr.pkb.sql)
Rem

create or replace package ctx_substr_int authid definer as 
  subtype index_info is dr$substr_idx%rowtype;

  function stripQuotes(tok in varchar2) return varchar2;

  function getIndexInfo(p_owner varchar2, p_name varchar2) return index_info;
  function getIndexInfoByCol(p_owner varchar2, p_tablename varchar2,
                             p_colname varchar2) return index_info;
  procedure updateIndexInfo(p_owner varchar2, p_name varchar2, iinfo index_info);
  procedure insertIndexInfo(p_owner varchar2, p_name varchar2, iinfo index_info);
  procedure deleteIndexInfo(p_owner varchar2, p_name varchar2);
end ctx_substr_int;
/
show errors;


create or replace package body ctx_lyke as 

  function LYKE(colval in varchar2, regexp in varchar2) return number is
  begin
    if (colval like regexp) then
      return 1;
    else
      return 0;
    end if;
  end;
end ctx_lyke;
/
show errors;

create or replace package body ctx_lyke_postfilter as 

  function LYKE(colval in varchar2, regexp in varchar2) return number is
  begin
    if (colval like regexp) then
      return 1;
    else
      return 0;
    end if;
  end;
end ctx_lyke_postfilter;
/
show errors;

create or replace type body lyke_idxtype_im as

  static function ODCIGetInterfaces(ifclist OUT sys.ODCIObjectList)
      return number is
  begin
      ifclist := sys.ODCIObjectList(sys.ODCIObject('SYS','ODCIINDEX2'));
      return ODCIConst.Success;
  end ODCIGetInterfaces;

  STATIC FUNCTION ODCIIndexCreate (ia sys.odciindexinfo, parms VARCHAR2,
     env sys.ODCIEnv) RETURN NUMBER IS
  begin
    return ctx_substr.IndexCreate(ia, parms, env);
  end;

  STATIC FUNCTION ODCIIndexDrop(ia sys.odciindexinfo, env sys.ODCIEnv)
    RETURN NUMBER is
  BEGIN
    return ctx_substr.IndexDrop(ia, env);
  END;

  STATIC FUNCTION ODCIIndexAlter(ia SYS.ODCIIndexInfo,
                                  parms IN OUT VARCHAR2,
                                  alter_option NUMBER,
                                  env SYS.ODCIEnv)
     RETURN NUMBER IS
  BEGIN
    return ctx_substr.IndexAlter(ia, parms, alter_option, env);
  END;

  STATIC FUNCTION ODCIIndexTruncate(ia SYS.ODCIIndexInfo,
                                     env SYS.ODCIEnv)
     RETURN NUMBER IS
  BEGIN
    return ctx_substr.IndexTruncate(ia, env);
  END;

  STATIC FUNCTION ODCIIndexInsert(ia sys.odciindexinfo, rid VARCHAR2,
    newval varchar2, env sys.ODCIEnv) RETURN NUMBER IS
  begin
    return ctx_substr.IndexInsert(ia, rid, newval, env);
  end;

  STATIC FUNCTION ODCIIndexDelete(ia sys.odciindexinfo, rid VARCHAR2,
    oldval varchar2, env sys.ODCIEnv) RETURN NUMBER IS
  begin
    return ctx_substr.IndexDelete(ia, rid, oldval, env);
  end;

  STATIC FUNCTION ODCIIndexUpdate(ia sys.odciindexinfo, rid VARCHAR2,
    oldval varchar2, newval varchar2, env sys.ODCIEnv)
     RETURN NUMBER is
  begin
    return ctx_substr.IndexUpdate(ia, rid, oldval, newval, env);
  end;

  STATIC FUNCTION ODCIIndexStart(sctx IN OUT lyke_idxtype_im,
     ia sys.odciindexinfo,
     op sys.odciPredInfo, qi sys.ODCIQueryInfo,
     strt number, stp number,
     regexp varchar2, 
     env sys.ODCIEnv) RETURN NUMBER is
  begin
    return ctx_substr.IndexStart(sctx, ia, op, qi, regexp, env);
  end ;

  MEMBER FUNCTION ODCIIndexFetch(self IN OUT lyke_idxtype_im,
      nrows NUMBER, rids OUT sys.odciridlist,
      env sys.ODCIEnv) RETURN NUMBER IS
  begin
    return ctx_substr.IndexFetch(self, nrows, rids, env);
  end ;

  MEMBER FUNCTION ODCIIndexClose(self IN OUT lyke_idxtype_im,
    env sys.ODCIEnv) RETURN NUMBER is
  begin
    return ctx_substr.IndexClose(self, env);
  end ;

end;
/
show errors;
grant execute on lyke_idxtype_im to public;

CREATE or replace type body lyke_idxtype_stats as

  STATIC FUNCTION ODCIGetInterfaces(ifclist OUT SYS.ODCIObjectList)
      return number is
  begin
      ifclist := sys.ODCIObjectList(sys.ODCIObject('SYS','ODCISTATS2'));
      return SYS.ODCIConst.Success;
  end ODCIGetInterfaces;

  STATIC FUNCTION ODCIStatsCollect(col SYS.ODCIColInfo,
                                   options SYS.ODCIStatsOptions,
                                   statistics OUT RAW, env SYS.ODCIEnv)
    return NUMBER is
  begin
    return ctx_substr.StatsCollect(col, options, statistics, env);
  end;
  STATIC FUNCTION ODCIStatsCollect(ia SYS.ODCIIndexInfo,
                                   options SYS.ODCIStatsOptions,
                                   statistics OUT RAW, env SYS.ODCIEnv)
    return NUMBER is
  begin
    return ctx_substr.StatsCollect(ia, options, statistics, env);
  end;

  STATIC FUNCTION ODCIStatsDelete(col SYS.ODCIColInfo,
                                  statistics OUT RAW, env SYS.ODCIEnv)
    return NUMBER is
  begin
    return ctx_substr.StatsDelete(col, statistics, env);
  end;

  STATIC FUNCTION ODCIStatsDelete(ia SYS.ODCIIndexInfo,
                                  statistics OUT RAW, env SYS.ODCIEnv)
    return NUMBER is
  begin
    return ctx_substr.StatsDelete(ia, statistics, env);
  end;

  STATIC FUNCTION ODCIStatsSelectivity(pred SYS.ODCIPredInfo, sel OUT NUMBER,
                                       args SYS.ODCIArgDescList,
                                        strt number, stop number,
                                        colarg varchar2, regexp varchar2,
                                        env SYS.ODCIEnv)
    return NUMBER is
  begin
    return ctx_substr.StatsSelectivity(pred, sel, args, strt, stop,
                                       regexp, env);
  end;

  STATIC FUNCTION ODCIStatsIndexCost(ia SYS.ODCIIndexInfo, sel NUMBER,
                                     cost OUT SYS.ODCICost, qi SYS.ODCIQueryInfo,
                                     pred SYS.ODCIPredInfo,
                                     args SYS.ODCIArgDescList,
                                     strt number,
                                     stop  number,
                                     regexp varchar2,
                                     env SYS.ODCIEnv)
    return NUMBER is 
  begin
    return ctx_substr.StatsIndexCost(ia, sel, cost, qi, pred, args, strt, 
                                     stop, regexp, env);
  end;

  STATIC FUNCTION ODCIStatsFunctionCost(func sys.ODCIFuncInfo, 
                                        cost OUT sys.ODCICost,
                                       args sys.ODCIArgDescList,
                                       colarg varchar2, regexp varchar2,
                                       env sys.ODCIEnv)
    return NUMBER is
  begin
    return ctx_substr.StatsFunctionCost(func, cost, args, 
                                    regexp, env);
  end;
end;
/
show errors;



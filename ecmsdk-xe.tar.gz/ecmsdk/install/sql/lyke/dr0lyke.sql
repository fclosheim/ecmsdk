Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    vdevadha    07/12/04  - 
Rem    vdevadha    03/29/04  - vdevadha_lyke_db_feature_main 
Rem    smuralid    12/08/03  - dr$ptab_t: added prid attribute
Rem


whenever sqlerror continue;

drop type dr$ptab_set_t force;
drop type dr$ptab_t force;
drop indextype ctxsubstr force;
drop operator lyke force;
drop type lyke_idxtype_im force;
drop table dr$numseq;

whenever sqlerror exit sql.sqlcode;

create or replace type dr$ptab_t as object (
  prid    varchar2(18),
  rid     varchar2(18),
  str     varchar2(256),
  insdel  varchar2(1)
);
/
grant execute on dr$ptab_t to public;

create or replace type dr$ptab_set_t as table of dr$ptab_t;
/
grant execute on dr$ptab_set_t to public;

create table dr$numseq(num number);
begin
  for i in 1..256 loop
    insert into dr$numseq values(i);
  end loop;
  commit;
end;
/
grant select on dr$numseq to public;

create table dr$substr_idx(
  table_owner  varchar2(30),    -- index owner
  table_name   varchar2(30),    -- table name
  col_name     varchar2(30),    -- the column name (if any)
  index_owner  varchar2(30),    -- index owner
  index_name   varchar2(30),    -- the index name
  stats        raw(1),          -- statistics stored away
---
  row_count_d  number,        -- number of rows covered by the index
  row_count    number,        -- number of index entries
  rows_per_block number,      -- avg number of index rows per block
  default_row_count_d number, -- default number of rows matched
  default_row_count   number, -- default number of rows matched
---
  properties number,          -- index properties (compression etc)
  engram_len number,          -- max length of engrams to use
---
  primary key(table_owner, table_name, col_name),
  unique(index_owner, index_name)
) organization index;
grant select on dr$substr_idx to public;


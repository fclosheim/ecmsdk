Rem Copyright (c) 2001, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    contextsetup2.sql - Setup Context Schema for DM
Rem
Rem  History:
Rem    20-jul-98 (hbutani)
Rem      Created
Rem    23-sep-98 (aalavi)
Rem      Create Context themes/summaries results tables
Rem    16-oct-98 (aalavi)
Rem      Increase 'default' and 'max' indexing memory size  
Rem    29-oct-98 (aalavi)
Rem      Add DM_DEF_STOPLIST preference.  
Rem    02-nov-98 (hbutani)
Rem      Removed create tablespace statement from this script
Rem    18-nov-98 (hbutani)
Rem      Added default URL preference
Rem    05-mar-99 (dtom)
Rem      Split into contextsetup.sql into two files
Rem    10-mar-99 (aalavi)
Rem      Use different index tablespaces for DM_DEF_STORAGE; do
Rem      not create empty stoplist (use Context default instead  
Rem    11-mar-99 (aalavi)
Rem      Add odm_documentfilter.
Rem    19-mar-99 (aalavi)
Rem      Add odm_documentmarkup, indexes on odm_document*.
Rem    07-jun-99 (aalavi)
Rem      Create DM_THEME_LEXER preference.
Rem    10-jun-99 (aalavi)
Rem      Create Lexer prefs for all languages.
Rem    06-dec-99 (basubram)
Rem      Added exit on sql error
Rem    22-jun-00 (lmatter)
Rem      Added multi lexer preferences
Rem    09-aug-00 (lmatter)
Rem      fixed bug 1376083
Rem    11-dec-00 (lmatter)
Rem      renamed script and added memsize settings
Rem    13-feb-01 (lmatter)
Rem      turned off theme indexing.  Bug 1642811
Rem    26-feb-01 (lmatter)
Rem      Turned BASE_LETTER on for default lexer, removed seperate
Rem      EUROPEAN lexer.  Also removed unused URL datastore preference.
Rem      also removed URL datastore preference (bug 1507932).
Rem    10-may-01 (lmatter)
Rem      context install now works without unlocking ctxsys user.
Rem    10-may-01 (lmatter)
Rem      changed output type of user_datastore to be BLOB_LOC, only works
Rem      in 9i (and 8.1.7 after patch).
Rem    16-may-01 (lmatter)
Rem      Changed name of wrapper procedure to <schema_name>_WP
Rem    28-jan-03 (vdevadha)
Rem      Changed the R_TABLE_CLAUSE to cache it in SGA.  
Rem    19-mar-04 (sayyagar)
Rem      move creation of filter preferences to createcontextindex.sql
Rem
Rem  Indices are created in the ContextIndex TableSpace. Indexing Memory is set 16MB.
Rem

whenever sqlerror exit sql.sqlcode

Prompt Setting up Default Storage Perference. Context Tables are setup
Prompt in Context Tablespace.
exec ctx_ddl.create_preference('IFS_DEF_STORAGE', 'BASIC_STORAGE');
exec ctx_ddl.set_attribute('IFS_DEF_STORAGE', 'I_TABLE_CLAUSE', 'tablespace &1');
exec ctx_ddl.set_attribute('IFS_DEF_STORAGE', 'K_TABLE_CLAUSE', 'tablespace &2');
exec ctx_ddl.set_attribute('IFS_DEF_STORAGE', 'R_TABLE_CLAUSE', 'tablespace &2 lob(data) store as (cache)');
exec ctx_ddl.set_attribute('IFS_DEF_STORAGE', 'N_TABLE_CLAUSE', 'tablespace &2');
exec ctx_ddl.set_attribute('IFS_DEF_STORAGE', 'I_INDEX_CLAUSE', 'tablespace &3');

Rem
Rem Column can hold all the supported formats.
Rem

Rem
Rem  Stemming & Fuzzy Queries are enabled, Soundex Queries are disabled.
Rem
Prompt Setting up Default WordList Preference.
exec ctx_ddl.create_preference('IFS_DEF_WORDLIST', 'BASIC_WORDLIST');

Rem ---
Rem ---  Create sublexers for the "global" multi-lexer
Rem ---

Rem
Rem Setup Default LEXER with theme & text indexing enabled
Rem but no base letter to get an exact match on the indexing
Rem
Prompt Setting up Default (English) Lexer with text and theme indexing enabled.
exec ctx_ddl.create_preference('IFS_DEFAULT_LEXER', 'BASIC_LEXER');
exec ctx_ddl.set_attribute('IFS_DEFAULT_LEXER', 'INDEX_THEMES', 'NO');
exec ctx_ddl.set_attribute('IFS_DEFAULT_LEXER', 'INDEX_TEXT', 'YES');
exec ctx_ddl.set_attribute('IFS_DEFAULT_LEXER', 'BASE_LETTER', 'YES');

Rem 
Rem Setup German LEXER
Rem 
Prompt Setting up German Lexer
exec ctx_ddl.create_preference('IFS_GERMAN_LEXER', 'BASIC_LEXER');
exec ctx_ddl.set_attribute('IFS_GERMAN_LEXER', 'ALTERNATE_SPELLING', 'GERMAN');
exec ctx_ddl.set_attribute('IFS_GERMAN_LEXER', 'BASE_LETTER', 'YES');
Rem German Composite spelling forces MIXED_CASE=YES
Rem and BASE_LETTER=NO, so it is not used.

Rem Setup Danish LEXER
Prompt Setting up Danish Lexer
exec ctx_ddl.create_preference('IFS_DANISH_LEXER', 'BASIC_LEXER');
exec ctx_ddl.set_attribute('IFS_DANISH_LEXER', 'ALTERNATE_SPELLING', 'DANISH');
exec ctx_ddl.set_attribute('IFS_DANISH_LEXER', 'BASE_LETTER', 'YES');

Rem 
Rem Setup Swedish LEXER
Rem 
Prompt Setting up Swedish Lexer
exec ctx_ddl.create_preference('IFS_SWEDISH_LEXER', 'BASIC_LEXER');
exec ctx_ddl.set_attribute('IFS_SWEDISH_LEXER', 'ALTERNATE_SPELLING', 'SWEDISH');
exec ctx_ddl.set_attribute('IFS_SWEDISH_LEXER', 'BASE_LETTER', 'YES');

Rem
Rem  Now setup the multi byte lexers
Rem 

Rem
Rem Setup Japanese LEXER
Rem
Prompt Setting up Japanese Lexer
exec ctx_ddl.create_preference('IFS_JAPANESE_LEXER', 'JAPANESE_VGRAM_LEXER');

Rem
Rem Setup Chinese LEXER
Rem
Prompt Setting up Chinese Lexer
exec ctx_ddl.create_preference('IFS_CHINESE_LEXER', 'CHINESE_VGRAM_LEXER');

Rem
Rem Setup Korean LEXER
Rem
Prompt Setting up Korean Lexer
exec ctx_ddl.create_preference('IFS_KOREAN_LEXER', 'KOREAN_MORPH_LEXER');

Rem
Rem Now create the Global Lexer
Rem
Prompt Creating Global LEXER 
exec ctx_ddl.create_preference('IFS_GLOBAL_LEXER', 'multi_lexer');
Prompt adding Default sublexer
exec ctx_ddl.add_sub_lexer('IFS_GLOBAL_LEXER','default','IFS_DEFAULT_LEXER');
Prompt adding Japanese sublexer
exec ctx_ddl.add_sub_lexer('IFS_GLOBAL_LEXER','JAPANESE','IFS_JAPANESE_LEXER');
Prompt adding Simplified Chinese sublexer
exec ctx_ddl.add_sub_lexer('IFS_GLOBAL_LEXER','SIMPLIFIED CHINESE','IFS_CHINESE_LEXER');
Prompt adding Traditional Chinese sublexer
exec ctx_ddl.add_sub_lexer('IFS_GLOBAL_LEXER','TRADITIONAL CHINESE','IFS_CHINESE_LEXER');
Prompt adding Korean sublexer
exec ctx_ddl.add_sub_lexer('IFS_GLOBAL_LEXER','KOREAN','IFS_KOREAN_LEXER');
Prompt adding German sublexer
exec ctx_ddl.add_sub_lexer('IFS_GLOBAL_LEXER','GERMAN','IFS_GERMAN_LEXER');
Prompt adding Danish sublexer
exec ctx_ddl.add_sub_lexer('IFS_GLOBAL_LEXER','DANISH','IFS_DANISH_LEXER');
Prompt adding Swedish sublexer
exec ctx_ddl.add_sub_lexer('IFS_GLOBAL_LEXER','SWEDISH','IFS_SWEDISH_LEXER');

Rem
Rem Setup Section_Group of type HTML_Section
Rem
Prompt Setting up Default Section_Group
Prompt Group Type is AUTO
exec ctx_ddl.create_section_group('IFS_SECTION_GROUP', 'AUTO_SECTION_GROUP');

Rem
Rem Setting up USER DATASTORE preferences
Rem
exec ctx_ddl.create_preference('IFS_USER_DATASTORE', 'USER_DATASTORE');
exec ctx_ddl.set_attribute('IFS_USER_DATASTORE', 'PROCEDURE', '&4._WP');
exec ctx_ddl.set_attribute('IFS_USER_DATASTORE', 'OUTPUT_TYPE', 'BLOB_LOC');


Prompt Creating Context Themes, Summaries, and Filter Results Tables

create table odm_documentthemes
  (query_id   number,
   gendate    date,
   theme       varchar2(2000),
   weight      number);
 
CREATE INDEX odm_documentthemes_q_index ON odm_documentthemes (query_id);

create table odm_documentsummaries
  (query_id   number,
   gendate    date,
   pov        varchar2(80),
   gist       clob);

CREATE INDEX odm_documentsummaries_q_index ON odm_documentsummaries (query_id);

create table odm_documentfilter
  (query_id   number,
   gendate    date,
   document       clob);

CREATE INDEX odm_documentfilter_q_index ON odm_documentfilter (query_id);

create table odm_documentmarkup
  (query_id   number,
   gendate    date,
   document       clob);

CREATE INDEX odm_documentmarkup_q_index ON odm_documentmarkup (query_id);

commit;
exit;



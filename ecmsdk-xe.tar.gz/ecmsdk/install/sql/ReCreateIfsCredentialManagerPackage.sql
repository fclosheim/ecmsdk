Rem Copyright (c) 2001, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    ReCreateIfsCredentialManagerPackage.sql - Used for upgrade. 
Rem    Re-creates the IfsCredentialManagerPackage with new signatures. 
Rem
Rem  History:
Rem    08-may-01 (vdevadha)
Rem      Created.
Rem    09-sep-05 (vdevadha)
Rem      Updated signatures. 

whenever sqlerror exit sql.sqlcode

CREATE OR REPLACE PACKAGE IfsCredentialManagerPackage as

	FUNCTION authenticate(distinguishedname VARCHAR2, serializedVector RAW, e OUT RAW) RETURN NUMBER;
	FUNCTION userExists(distinguishedname VARCHAR2, e OUT RAW) RETURN NUMBER;
	FUNCTION createUser(distinguishedname VARCHAR2, password VARCHAR2, subscriber VARCHAR2, e OUT RAW) RETURN NUMBER;
	FUNCTION deleteUser(distinguishedname VARCHAR2, e OUT RAW) RETURN NUMBER;
	FUNCTION setPassword(distinguishedname VARCHAR2, password VARCHAR2, e OUT RAW) RETURN NUMBER;
	FUNCTION listUsers(e OUT RAW) RETURN RAW;
	FUNCTION getVersionString RETURN VARCHAR2;
	FUNCTION listRealms(e OUT RAW) RETURN RAW;

END IfsCredentialManagerPackage;

/

CREATE OR REPLACE PACKAGE BODY IfsCredentialManagerPackage as
	
	FUNCTION authenticate(distinguishedname VARCHAR2, serializedVector RAW, e OUT RAW) RETURN NUMBER 
	AS LANGUAGE JAVA
	NAME 'oracle.ifs.server.IfsCredentialManagerServer.authenticate(java.lang.String, byte [], byte [][]) return int';

	FUNCTION userExists(distinguishedname VARCHAR2, e OUT RAW) RETURN NUMBER 
	AS LANGUAGE JAVA
	NAME 'oracle.ifs.server.IfsCredentialManagerServer.exists(java.lang.String, byte[][]) return int';

	FUNCTION createUser(distinguishedname VARCHAR2, password VARCHAR2, subscriber VARCHAR2, e OUT RAW) RETURN NUMBER 
	AS LANGUAGE JAVA
	NAME 'oracle.ifs.server.IfsCredentialManagerServer.createUser(java.lang.String, java.lang.String, java.lang.String, byte [][]) return int';

	FUNCTION deleteUser(distinguishedname VARCHAR2, e OUT RAW) RETURN NUMBER 
	AS LANGUAGE JAVA
	NAME 'oracle.ifs.server.IfsCredentialManagerServer.deleteUser(java.lang.String, byte [][]) return int';

	FUNCTION setPassword(distinguishedname VARCHAR2, password VARCHAR2, e OUT RAW) RETURN NUMBER 
	AS LANGUAGE JAVA
	NAME 'oracle.ifs.server.IfsCredentialManagerServer.setPassword(java.lang.String, java.lang.String, byte [][]) return int';

	FUNCTION listUsers(e OUT RAW) RETURN RAW 
	AS LANGUAGE JAVA
	NAME 'oracle.ifs.server.IfsCredentialManagerServer.listUsers(byte [][]) return byte[]';

	FUNCTION listRealms(e OUT RAW) RETURN RAW 
	AS LANGUAGE JAVA
	NAME 'oracle.ifs.server.IfsCredentialManagerServer.listRealms(byte [][]) return byte[]';

	FUNCTION getVersionString RETURN VARCHAR2
	AS LANGUAGE JAVA
	NAME 'oracle.ifs.server.IfsCredentialManagerServer.getVersionString() return java.lang.String';

END IfsCredentialManagerPackage;

/

show errors;

grant execute on IfsCredentialManagerPackage to &1;
exit;

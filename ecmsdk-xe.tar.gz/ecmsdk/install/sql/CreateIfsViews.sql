Rem Copyright (c) 2012, Oracle. All rights reserved.
Rem
Rem  NAME
Rem    CreateIfsViews.sql - Creates optional IFS views in the repository.
Rem
Rem  History:
Rem    12-jan-12 (fcloshei)
Rem      Created

whenever sqlerror exit sql.sqlcode

Rem Creating ootional IFS views in the repository.

CREATE OR REPLACE VIEW IFS_ACLS AS
 SELECT D2.NAME Modified_By     ,
  D2.ID Modifier_ID             ,
  ACL2.NAME Controlling_Acl_Name,
  ACL2.ID Controlling_Acl_ID    ,
  D1.NAME Creator                                                                    ,
  D1.ID Creator_ID                                                                   ,
  ACL1.NAME Name                                                                     ,
  ACL1.ID Acl_ID                                                                     ,
  ACL1.DESCRIPTION Description                                                       ,
  ACL1.CREATEDATE Create_Date                                                        ,
  to_date ('01-JAN-1970', 'DD-MON-YYYY') + (ACL1.CREATEDATE/86400000) Create_Date_GMT,
  D0.NAME Owner                                                                      ,
  D0.ID Owner_ID
   FROM odmv_accesscontrollist ACL1,
  odmv_accesscontrollist ACL2      ,
  odmv_directoryobject D0          ,
  odmv_directoryobject D1          ,
  odmv_directoryobject D2
  WHERE ( ( ( ( ( ( ( ACL1.ACL = ACL2.ID )
AND ( ACL1.OWNER               = D0.ID ) ) )
AND ( ACL1.CREATOR             = D1.ID ) ) )
AND ( ACL1.LASTMODIFIER        = D2.ID ) ) )
WITH read only;

CREATE OR REPLACE VIEW IFS_ALL_DOCUMENTS AS
 SELECT DIROBJ3.NAME ModifiedBy                                                            ,
  DIROBJ3.ID Modifier_ID                                                                   ,
  FMT.NAME Format                                                                          ,
  FMT.ID Format_ID                                                                         ,
  DIROBJ2.NAME Creator                                                                     ,
  DIROBJ2.ID Creator_ID                                                                    ,
  DIROBJ1.NAME Owner                                                                       ,
  DIROBJ1.ID Owner_ID                                                                      ,
  MEDIA.NAME Media                                                                         ,
  MEDIA.ID Media_ID                                                                        ,
  DOC.NAME Name                                                                            ,
  DOC.ID Document_Id                                                                       ,
  DOC.DESCRIPTION Description                                                              ,
  DOC.CREATEDATE Create_DATE                                                               ,
  to_date('01-JAN-1970', 'DD-MON-YYYY') + (DOC.CREATEDATE/86400000) Create_Date_GMT        ,
  DOC.LASTMODIFYDATE Modified_Date                                                         ,
  to_date('01-JAN-1970', 'DD-MON-YYYY') + (DOC.LASTMODIFYDATE/86400000) Modified_Date_GMT  ,
  DOC.EXPIRATIONDATE Expiration_Date                                                       ,
  to_date('01-JAN-1970', 'DD-MON-YYYY') + (DOC.EXPIRATIONDATE/86400000) Expiration_Date_GMT,
  DOC.READBYOWNER Read_By_Owner                                                            ,
  CO.CONTENTSIZE DOCUMENT_SIZE                                                             ,
  CO.CHARACTERSET CHARACTERSET                                                             ,
  CO.LANGUAGE LANGUAGE                                                                     ,
  ACL.NAME Acl                                                                             ,
  ACL.ID Acl_ID
   FROM odmv_document DOC     ,
  odmv_accesscontrollist ACL  ,
  odmv_directoryobject DIROBJ1,
  odmv_directoryobject DIROBJ2,
  odm_contentobject CO        ,
  odm_format FMT              ,
  odm_media MEDIA             ,
  odmv_directoryobject DIROBJ3
  WHERE ( ( ( ( ( ( ( ( ( ( ( ( ( DOC.ACL = ACL.ID )
AND ( DOC.OWNER                           = DIROBJ1.ID ) ) )
AND ( DOC.CREATOR                         = DIROBJ2.ID ) ) )
AND ( DOC.CONTENTOBJECT                   = CO.ID ) ) ) AND ( CO.FORMAT = FMT.ID ) ) )
AND ( CO.MEDIA                            = MEDIA.ID ) ) )
AND ( DOC.LASTMODIFIER                    = DIROBJ3.ID ) ) )
WITH read only;

CREATE OR REPLACE VIEW IFS_FOLDERS AS
 SELECT DIROBJ3.NAME Modified_By                                                         ,
  DIROBJ3.ID Modifier_ID                                                                 ,
  DIROBJ2.NAME Creator                                                                   ,
  DIROBJ2.ID Creator_ID                                                                  ,
  DIROBJ1.NAME Owner                                                                     ,
  DIROBJ1.ID Owner_ID                                                                    ,
  F.NAME Name                                                                            ,
  F.ID Folder_ID                                                                         ,
  F.DESCRIPTION Description                                                              ,
  F.CREATEDATE Create_Date                                                               ,
  to_date('01-JAN-1970', 'DD-MON-YYYY') + (F.CREATEDATE/86400000) Create_Date_GMT        ,
  F.LASTMODIFYDATE Modified_Date                                                         ,
  to_date('01-JAN-1970', 'DD-MON-YYYY') + (F.LASTMODIFYDATE/86400000) Modified_Date_GMT  ,
  F.EXPIRATIONDATE Expiration_Date                                                       ,
  to_date('01-JAN-1970', 'DD-MON-YYYY') + (F.EXPIRATIONDATE/86400000) Expiration_Date_GMT,
  ACL.NAME Acl                                                                           ,
  ACL.ID Acl_ID
   FROM odmv_folder F          ,
  odmv_accesscontrollist ACL   ,
  odmv_directoryobject DIROBJ1 ,
  odmv_directoryobject DIROBJ2 ,
  odmv_directoryobject DIROBJ3
  WHERE ( ( ( ( ( ( ( F.ACL = ACL.ID )
AND ( F.OWNER               = DIROBJ1.ID ) ) )
AND ( F.CREATOR             = DIROBJ2.ID ) ) )
AND ( F.LASTMODIFIER        = DIROBJ3.ID ) ) )
WITH read only;

CREATE OR REPLACE VIEW IFS_FOLDER_ITEMS
AS
   SELECT DIROBJ.NAME Owner                                                        ,
    DIROBJ.ID Owner_ID                                                             ,
    PO.NAME Name                                                                   ,
    PO.DESCRIPTION Description                                                     ,
    PO.CREATEDATE Create_Date                                                      ,
    to_date('01-JAN-1970', 'DD-MON-YYYY') + (PO.CREATEDATE/86400000)Create_Date_GMT,
    PO.ID Object_ID                                                                ,
    F.NAME Folder_Name                                                             ,
    F.ID Folder_ID                                                                 ,
    ACL.NAME Acl                                                                   ,
    ACL.ID Acl_ID                                                                  ,
    CO.NAME Type
     FROM odmv_folderpathrelationship FPR,
    odmv_publicobject PO                 ,
    odmv_CLASSOBJECT CO                  ,
    odmv_folder F                        ,
    odmv_accesscontrollist ACL           ,
    odmv_directoryobject DIROBJ
    WHERE ( ( ( ( ( ( ( ( ( F.ID = FPR.LEFTOBJECT )
  AND ( FPR.RIGHTOBJECT          = PO.ID ) ) )
  AND ( PO.CLASSID               = CO.ID ) ) )
  AND ( PO.OWNER                 = DIROBJ.ID ) ) )
  AND ( PO.ACL                   = ACL.ID ) ) )
WITH read only;

CREATE OR REPLACE VIEW IFS_GROUPS
AS
   SELECT DIROBJ3.NAME Modified_By                                                  ,
    DIROBJ3.ID Modifier_ID                                                          ,
    DIROBJ2.NAME Creator                                                            ,
    DIROBJ2.ID Creator_ID                                                           ,
    DIROBJ1.NAME Owner                                                              ,
    DIROBJ1.ID Owner_ID                                                             ,
    DG.NAME Name                                                                    ,
    DG.ID Group_ID                                                                  ,
    DG.DESCRIPTION Description                                                      ,
    DG.CREATEDATE Create_Date                                                       ,
    to_date('01-JAN-1970', 'DD-MON-YYYY') + (DG.CREATEDATE/86400000) Create_Date_GMT,
    ACL.NAME Acl                                                                    ,
    ACL.ID Acl_ID
     FROM odmv_directorygroup DG,
    odmv_accesscontrollist ACL  ,
    odmv_directoryobject DIROBJ1,
    odmv_directoryobject DIROBJ2,
    odmv_directoryobject DIROBJ3
    WHERE ( ( ( ( ( ( ( DG.ACL = ACL.ID )
  AND ( DG.OWNER               = DIROBJ1.ID ) ) )
  AND ( DG.CREATOR             = DIROBJ2.ID ) ) )
  AND ( DG.LASTMODIFIER        = DIROBJ3.ID ) ) )
WITH read only;

CREATE OR REPLACE VIEW IFS_GROUP_MEMBERS
AS
   SELECT DO.NAME Member_Name                                                              ,
    DO.ID Member_ID                                                                        ,
    DO.DESCRIPTION Member_Description                                                      ,
    DO.CREATEDATE Member_Create_Date                                                       ,
    to_date('01-JAN-1970', 'DD-MON-YYYY') + (DO.CREATEDATE/86400000) Member_Create_Date_GMT,
    DG.NAME Name                                                                           ,
    DG.ID Group_ID                                                                         ,
    CO.NAME Type
     FROM odmv_groupmemberrelationship GMR,
    odmv_directoryobject DO               ,
    odmv_CLASSOBJECT CO                   ,
    odmv_directorygroup DG
    WHERE ( ( ( ( ( DG.ID = GMR.LEFTOBJECT )
  AND ( GMR.RIGHTOBJECT   = DO.ID ) ) )
  AND ( DO.CLASSID        = CO.ID ) ) )
WITH read only;

CREATE OR REPLACE VIEW IFS_USERS
AS
   SELECT DIROBJ3.NAME Modified_By                                                     ,
    DIROBJ3.ID Modifier_ID                                                             ,
    DIROBJ2.NAME Creator                                                               ,
    DIROBJ2.ID Creator_ID                                                              ,
    DIROBJ1.NAME Owner                                                                 ,
    DIROBJ1.ID Owner_ID                                                                ,
    F.NAME Home_Folder_Name                                                            ,
    F.ID Home_Folder_ID                                                                ,
    DUSER.NAME Name                                                                    ,
    DUSER.ID User_ID                                                                   ,
    DUSER.DESCRIPTION Description                                                      ,
    DUSER.CREATEDATE Create_Date                                                       ,
    to_date('01-JAN-1970', 'DD-MON-YYYY') + (DUSER.CREATEDATE/86400000) Create_Date_GMT,
    DUSER.DISTINGUISHEDNAME Distinguished_Name                                         ,
    DUSER.ADMINENABLED Admin_Enabled                                                   ,
    DUSER.CREDENTIALMANAGER Credential_Manager                                         ,
    DUSER.UNIQUENAME Unique_Name                                                       ,
    ACL.NAME Acl                                                                       ,
    ACL.ID Acl_ID
     FROM odmv_directoryuser DUSER,
    odmv_accesscontrollist ACL    ,
    odmv_directoryobject DIROBJ1  ,
    odmv_directoryobject DIROBJ2  ,
    odmv_directoryobject DIROBJ3  ,
    odmv_primaryuserprofile P     ,
    odmv_folder F
    WHERE ( ( ( ( ( ( ( ( ( ( ( DUSER.ACL = ACL.ID )
  AND ( DUSER.OWNER                       = DIROBJ1.ID ) ) )
  AND ( DUSER.CREATOR                     = DIROBJ2.ID ) ) )
  AND ( DUSER.LASTMODIFIER                = DIROBJ3.ID ) ) )
  AND ( DUSER.ID                          = P.DIRECTORYUSER ) ) )
  AND ( P.HOMEFOLDER                      = F.ID ) ) )
WITH read only;

CREATE OR REPLACE VIEW IFS_VERSIONED_DOCUMENTS
AS
   SELECT MEDIA.NAME Media                                                                   ,
    MEDIA.ID Media_ID                                                                        ,
    FMT.NAME Format                                                                          ,
    FMT.ID Format_ID                                                                         ,
    FAMILY.NAME Family                                                                       ,
    FAMILY.ID Family_ID                                                                      ,
    DIROBJ3.NAME ModifiedBy                                                                  ,
    DIROBJ3.ID Modifier_ID                                                                   ,
    CO.CONTENTSIZE DOCUMENT_SIZE                                                             ,
    CO.CHARACTERSET CHARACTERSET                                                             ,
    CO.LANGUAGE LANGUAGE                                                                     ,
    DIROBJ2.NAME Creator                                                                     ,
    DIROBJ2.ID Creator_ID                                                                    ,
    DOC.NAME Name                                                                            ,
    DOC.ID Document_Id                                                                       ,
    DOC.DESCRIPTION Description                                                              ,
    DOC.CREATEDATE Create_Date                                                               ,
    to_date('01-JAN-1970', 'DD-MON-YYYY') + (DOC.CREATEDATE/86400000) Create_Date_GMT        ,
    DOC.LASTMODIFYDATE Modified_Date                                                         ,
    to_date('01-JAN-1970', 'DD-MON-YYYY') + (DOC.LASTMODIFYDATE/86400000) Modified_Date_GMT  ,
    DOC.EXPIRATIONDATE Expiration_Date                                                       ,
    to_date('01-JAN-1970', 'DD-MON-YYYY') + (DOC.EXPIRATIONDATE/86400000) Expiration_Date_GMT,
    DOC.READBYOWNER Read_By_Owner                                                            ,
    DIROBJ1.NAME Owner                                                                       ,
    DIROBJ1.ID Owner_ID                                                                      ,
    ACL.NAME Acl                                                                             ,
    ACL.ID Acl_ID
     FROM odmv_document DOC     ,
    odmv_accesscontrollist ACL  ,
    odmv_directoryobject DIROBJ1,
    odmv_directoryobject DIROBJ2,
    odm_contentobject CO        ,
    odm_format FMT              ,
    odm_media MEDIA             ,
    odmv_family FAMILY          ,
    odmv_directoryobject DIROBJ3
    WHERE ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( DOC.ACL = ACL.ID )
  AND ( DOC.OWNER                               = DIROBJ1.ID ) ) )
  AND ( DOC.CREATOR                             = DIROBJ2.ID ) ) )
  AND ( DOC.CONTENTOBJECT                       = CO.ID ) ) )
  AND ( CO.FORMAT                               = FMT.ID ) ) )
  AND ( CO.MEDIA                                = MEDIA.ID ) ) )
  AND ( DOC.FAMILY                              = FAMILY.ID ) ) )
  AND ( DOC.LASTMODIFIER                        = DIROBJ3.ID ) ) )
WITH read only;

exit;

Rem Copyright (c) 2015, inxire GmbH and/or its affiliates.
Rem All rights reserved. 
Rem
Rem  NAME
Rem    SystemPreInstall.sql - Pre create some objects as system user before installing
Rem 
Rem  Usage:
Rem    @SystemPreInstall {IFS_SCHEMA_NAME} {IFS_SCHEMA_PASSWORD} {IFS_MAIN_TBS_NAME} {IFS_TEMP_TBS_NAME}
Rem
Rem History:
Rem     21-dec-15 (dscholle)
Rem         Created.

whenever sqlerror exit sql.sqlcode

SET VERIFY OFF

-- Check if schema exists
declare
  cnt integer;
begin
  select count(*) into cnt from dba_users where username in (upper('&1'), upper('&1.$cm'));
  if cnt=1 or cnt=2
  then raise_application_error(-20000, 'User &1 and/or &1.$cm already exists');
  end if;
end;
/

Prompt action: CreateIfsSchemas
declare
  len integer;
begin
  select lengthb('&1') into len from dual;
  if len > 10
  then raise_application_error(-20000, 'Schema name cannot be longer than 10 characters');
  end if;
end;
/

create user &1 identified by &2 default tablespace &3 temporary tablespace &4;

grant RESOURCE,UNLIMITED TABLESPACE,ALTER SESSION,CREATE CLUSTER,CREATE DATABASE LINK,CREATE SEQUENCE,CREATE SESSION,CREATE SYNONYM,CREATE TABLE,CREATE VIEW to &1;
grant QUERY REWRITE to &1;

Prompt action: CreateIfsCredentialManagerSchema
create user &1.$CM identified by &1.$CM default tablespace &3 temporary tablespace &4;
grant RESOURCE,UNLIMITED TABLESPACE,ALTER SESSION,CREATE CLUSTER,CREATE DATABASE LINK,CREATE SEQUENCE,CREATE SESSION,CREATE SYNONYM,CREATE TABLE,CREATE VIEW to &1.$CM;

-- @{IFS_ADMIN_SQL}/GrantJavaFilePermissionsToIfs.sql &1
Prompt Granting privileges to &1

call dbms_java.grant_permission( upper('&1'), 'SYS:java.io.FilePermission', '<<ALL FILES>>', 'write, read, delete' );

commit;

-- @{IFS_ADMIN_SQL}/GrantDirectoryToIfs.sql &1
Prompt Granting privileges to &1

grant DROP ANY DIRECTORY TO &1;
grant CREATE ANY DIRECTORY TO &1;

-- @{IFS_ADMIN_SQL}/GrantContextToIFS.sql &1
Prompt Granting privileges to &1
grant ctxapp to &1;

Prompt Setting up Indexing memory size(default=16M, max=2G)
create or replace procedure ctxsys.ifsadmin(param in varchar2, val in varchar2) is
begin ctx_adm.set_parameter(param, val);
end;
/
exec ctxsys.ifsadmin('max_index_memory', '2147483647');
exec ctxsys.ifsadmin('default_index_memory', '16000000');
drop procedure ctxsys.ifsadmin;

Prompt granting ctx packages to &1
create or replace procedure ctxsys.ifsgrant(pkg in varchar2) is
begin execute immediate 'grant execute on '||pkg||' to &1';
end;
/

exec ctxsys.ifsgrant('ctx_adm');
exec ctxsys.ifsgrant('ctx_ddl');
exec ctxsys.ifsgrant('ctx_thes');
exec ctxsys.ifsgrant('ctx_query');

whenever sqlerror continue none;

Rem
Rem create funneling procedure wrapper.  Embed ifs schema name in procname
Rem to avoid namespace collision. Call twin wrapper procedure in iFS schema.
Rem
Prompt Creating Indexing Procedure wrapper in ctxsys schema 
create or replace procedure ctxsys.&1._WP(rid in rowid,
                                          tlob in out nocopy blob) is
begin &1..&1._WP(rid, tlob);
end;
/

show errors

exec ctxsys.ifsgrant('&1._WP');

drop procedure ctxsys.ifsgrant;

Rem Copyright (c) 2001, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    GrantAqToIfs.sql - Setup AQ privileges for 9iFS
Rem
Rem  History:
Rem    18-oct-01 (vdevadha)
Rem        Created.
Rem    22-oct-01 (vdevadha)
Rem        Removed redundant grant statements from the file.

whenever sqlerror exit sql.sqlcode

Prompt Granting privileges to &1

grant aq_administrator_role to &1;

commit;
exit;



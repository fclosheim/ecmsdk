Rem Copyright (c) 2015, inxire GmbH and/or its affiliates. All rights reserved.
Rem
Rem  NAME
Rem    GrantIfsCredentialManagerToIfs.sql - grants access to the 
Rem      credential manager schema.
Rem
Rem  History:
Rem    02-feb-15 (fcloshei)
Rem      Created.  

whenever sqlerror exit sql.sqlcode
set serveroutput on

Prompt Granting connect permissions to &1

grant select on IFSCREDENTIALMANAGER to &1;
grant insert on IFSCREDENTIALMANAGER to &1;
grant update on IFSCREDENTIALMANAGER to &1;
grant delete on IFSCREDENTIALMANAGER to &1;

whenever sqlerror exit 0

commit;

exit;

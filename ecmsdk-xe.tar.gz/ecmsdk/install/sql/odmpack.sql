Rem Copyright (c) 2001, 2008, Oracle. All rights reserved.  

Rem
Rem  NAME:  odmpack.sql
Rem
Rem         Defines the odm package.
Rem
Rem  History:
Rem    07/21/98 (hbutani)
Rem      Created.
Rem    07/29/98 (hbutani)
Rem      Added createsCycle fn.
Rem    07/30/98 (hbutani)
Rem      Use dynamic sql in createsCycle fn, because tables are created
Rem      after the package.
Rem    11/15/98 (hbutani)
Rem      Added reIndexing functions
Rem    11/15/98 (hbutani)
Rem      Added dropPartitions function
Rem    2/17/99 (hbutani)
Rem      Added order-by to subclassid retrival
Rem    04/29/99 (jfroese)
Rem      Removed dynamic sql from createsCycle.
Rem    03/23/01 (lmatter)
Rem      use databaseobjectname instead of class name for partition name.
Rem

whenever sqlerror exit sql.sqlcode

create or replace package odm is

procedure partitionSubClasses(className STRING);
procedure dropPartitions(className STRING);
procedure rebuildIndexes(className STRING);
procedure rebuildIndexPartitions(className STRING); 
function createsCycle(parentFolder float, subFolder float) return integer;

end odm;
/
show errors

create or replace package body odm is

	ODM_TABLE_PREFIX CONSTANT VARCHAR2(10) := 'ODM_';
	ODM_NEWSUBCLASS_PARTITION VARCHAR(100) := 'NEWSUBCLASSES';
	Type DMClass is RECORD (
		name odm_schemaobject.name%TYPE,
		dbname odm_classobject.databaseobjectname%TYPE,
		id odm_schemaobject.id%TYPE);
	Type ClassList is VARRAY(5000) of DMClass;

-- Private Functions

function isPartitionedOn(tableName STRING, subClass STRING) return BOOLEAN IS
	ispart BOOLEAN;
	name user_part_col_statistics.partition_name%TYPE;
begin
	select distinct(partition_name) into name
	from user_part_col_statistics
	where table_name = tableName and partition_name = subClass;
	return true;
exception
	when no_data_found then
		return false;
end isPartitionedOn;

procedure addPartition(tableName STRING, subClass DMClass) is
	selectStr VARCHAR(2000);
	classid odm_schemaobject.id%TYPE;
	cur INTEGER;
	ret INTEGER;
begin
	classid := subclass.id + 1;
	selectStr := 'alter table ' || tableName ||
		' split partition ' || ODM_NEWSUBCLASS_PARTITION ||
		' at (' || classid || ')' ||
		' into (partition ' || subClass.dbname ||
		', partition ' || ODM_NEWSUBCLASS_PARTITION ||
		')';
	
	cur := dbms_sql.open_cursor;
	dbms_sql.parse(cur, selectStr, dbms_sql.NATIVE);
	ret := dbms_sql.execute(cur);
	dbms_sql.close_cursor(cur);
end addPartition;

procedure dropPartition(tableName STRING, partitionName STRING) is
	selectStr VARCHAR(2000);
	classid odm_schemaobject.id%TYPE;
	cur INTEGER;
	ret INTEGER;
begin
	selectStr := 'alter table ' || tableName ||
		' drop partition ' || partitionName;
	cur := dbms_sql.open_cursor;
	dbms_sql.parse(cur, selectStr, dbms_sql.NATIVE);
	ret := dbms_sql.execute(cur);
	dbms_sql.close_cursor(cur);
end dropPartition;

procedure addPartitions(tableName STRING, subClasses ClassList) is
begin
	for i in subClasses.FIRST..subClasses.LAST LOOP
		if ( not ( isPartitionedOn(tableName, subClasses(i).dbname) ) ) then
			dbms_output.put_line('Adding Partition ' || subclasses(i).dbname );
			addPartition(tableName, subClasses(i));	
		end if;
	end loop;
end addPartitions;

procedure rebuildIndex(indexName STRING) is
	selectStr VARCHAR(2000);
	cur INTEGER;
	ret INTEGER;
begin
	selectStr := 'alter index ' || indexName || ' rebuild nologging';
	
	cur := dbms_sql.open_cursor;
	dbms_sql.parse(cur, selectStr, dbms_sql.NATIVE);
	ret := dbms_sql.execute(cur);
	dbms_sql.close_cursor(cur);
end rebuildIndex;

procedure rebuildIndexPartition(indexName STRING, partitionName STRING) is
	selectStr VARCHAR(2000);
	cur INTEGER;
	ret INTEGER;
begin
	selectStr := 'alter index ' || indexName || 
		' rebuild partition ' || partitionName || ' nologging';
	
	cur := dbms_sql.open_cursor;
	dbms_sql.parse(cur, selectStr, dbms_sql.NATIVE);
	ret := dbms_sql.execute(cur);
	dbms_sql.close_cursor(cur);
end rebuildIndexPartition;

-- Public Functions

procedure rebuildIndexes(className STRING) is
	tName VARCHAR2(2000);
	CURSOR c1(t user_indexes.table_name%TYPE) is
		select index_name
		from user_indexes
		where table_name = t and
		status = 'UNUSABLE';
begin
	dbms_output.enable(10000);

	tName :=  ODM_TABLE_PREFIX || className;
	for idx in c1(tName) LOOP
		dbms_output.put_line('Rebuilding Index ' || idx.index_name );
		rebuildIndex(idx.index_name);
	end loop;
end rebuildIndexes;

procedure rebuildIndexPartitions(className STRING) is
	tName VARCHAR2(2000);
	CURSOR c1(t user_indexes.table_name%TYPE) is
		select p.index_name, p.partition_name
		from user_indexes i, user_ind_partitions p
		where i.table_name = t and  i.index_name = p.index_name
		and p.status = 'UNUSABLE';
begin
	dbms_output.enable(10000);

	tName :=  ODM_TABLE_PREFIX || className;
	for idx in c1(tName) LOOP
		dbms_output.put_line('Rebuilding Index Partition ' || 
			idx.index_name || ':' || idx.partition_name );
		rebuildIndexPartition(idx.index_name, idx.partition_name);
	end loop;
end rebuildIndexPartitions;

procedure partitionSubClasses(className STRING) is
	isPartitioned user_tables.partitioned%TYPE;
	tName VARCHAR2(2000);
	classid odm_schemaobject.id%TYPE;
	subclasses ClassList := ClassList();
	CURSOR c1 (c odm_schemaobject.id%TYPE) is
		select co.name name, upper(co.databaseobjectname) dbname, co.id id from odmz_class_hierarchy, odmv_classobject co
		where odmz_class_hierarchy.classid = c and
		subclassid = co.id order by co.id;
begin

	dbms_output.enable(10000);

	tName :=  ODM_TABLE_PREFIX || className;

	begin
		select id into classid 
		from odmv_classobject
		where name = className;
	exception
		when no_data_found then
			dbms_output.put_line('Class ' || className || ' not found');
			raise;
	end;

	select partitioned into isPartitioned
	from user_tables
	where table_name = tName ;
	if ( isPartitioned != 'YES' ) then
		dbms_output.put_line('Class ' || className || ' is not partitioned');
		return;
	end if;
	
	for subclass in c1(classid) LOOP
		subclasses.extend;
		subclasses(subclasses.last).name := subclass.name;
		subclasses(subclasses.last).dbname := subclass.dbname;
		subclasses(subclasses.last).id := subclass.id;
	end loop;

	addPartitions(tName, subClasses);
		
end partitionSubClasses;

-- drops partitions of deleted subClasses
procedure dropPartitions(className STRING) is
	isPartitioned user_tables.partitioned%TYPE;
	tName VARCHAR2(2000);
	classid odm_schemaobject.id%TYPE;
	CURSOR c1 (t user_tab_partitions.table_name%TYPE, c odm_schemaobject.id%TYPE) is
		select partition_name from user_tab_partitions
		where table_name = t
		and partition_name <> ODM_NEWSUBCLASS_PARTITION
		and partition_name not in 
		( select upper(databaseobjectname)
		from odmv_classobject co, odmz_class_hierarchy ch
		where co.id = ch.subclassid and ch.classid = c );
begin
	dbms_output.enable(10000);

	tName :=  ODM_TABLE_PREFIX || className;

	begin
		select id into classid 
		from odmv_classobject
		where name = className;
	exception
		when no_data_found then
			dbms_output.put_line('Class ' || className || ' not found');
			raise;
	end;

	select partitioned into isPartitioned
	from user_tables
	where table_name = tName ;
	if ( isPartitioned != 'YES' ) then
		dbms_output.put_line('Class ' || className || ' is not partitioned');
		return;
	end if;
	
	for subclass in c1(tName, classid) LOOP
		dbms_output.put_line('Dropping Partition ' || subclass.partition_name
			|| ' from table ' || tName);
		dropPartition(tName, subclass.partition_name);
	end loop;

end dropPartitions;

--
-- Checks if adding subFolder to parentFolder, creates a cycle in the
-- Folder Hierarchy.
--
FUNCTION createsCycle(parentFolder float, subFolder float) RETURN INTEGER IS
	result float := 0;
	rVal integer := 0;
BEGIN
	-- Check for self-cycles seperately
	IF ( parentFolder = subFolder ) THEN
		return 1;
	END IF;

	-- Try to select data to see if this is a cycle
	SELECT rightobject INTO result FROM odm_relationship
	WHERE rightobject = parentFolder
	START WITH leftobject = subfolder
	CONNECT BY PRIOR rightobject = leftobject
		AND PRIOR rightobject != rightobject;

	-- Oops, we have a result. This means we have cycles
	IF ( result > 0 ) THEN
		rVal := 1;
	END IF;

	RETURN rVal;

EXCEPTION
	-- We expect this, no cycles found
	WHEN NO_DATA_FOUND THEN
		rVal := 0;
		RETURN rVal;

	-- We have more than one row, we found more than one cycles.
	WHEN TOO_MANY_ROWS THEN
		rVal := 1;
		RETURN rVal;

	-- Something bad happened
	WHEN OTHERS THEN
		RAISE;
END createsCycle;

end odm;
/
show errors
commit;
exit;


Rem Copyright (c) 2004, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    CreateLykeIndex.sql - create lyke type index on name column of odm_publicobject. 
Rem
Rem  History:
Rem    25-mar-04 (vdevadha)
Rem      Created.
Rem    09-jul-04 (vdevadha)
Rem      Handled moving of lyke functionality to IFSSYS schema from CTXSYS schema.

whenever sqlerror exit sql.sqlcode

create index ifs_lyke on odm_publicobject(nls_upper(name)) indextype is ctxsubstr;
alter index ifs_lyke parallel 1;

commit;
exit;


Rem Copyright (c) 2002, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    GrantJavaFilePermissionsToIfs.sql - Setup Java.io.FilePermission privileges 
Rem
Rem  History:
Rem    17-jan-02 (kgillett)
Rem        Created.
Rem    17-jan-02 (kgillett)
Rem        Changed to Grantpermissions on AllFiles.

whenever sqlerror exit sql.sqlcode

Prompt Granting privileges to &1

call dbms_java.grant_permission( upper('&1'), 'SYS:java.io.FilePermission', '<<ALL FILES>>', 'write, read, delete' );

commit;
exit;


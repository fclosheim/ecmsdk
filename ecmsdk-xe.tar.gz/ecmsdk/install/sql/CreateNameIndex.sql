Rem Copyright (c) 2003, 2012, Oracle and/or its affiliates. All rights reserved.
Rem
Rem  NAME
Rem    CreateNameIndex.sql - create name indexes. 
Rem
Rem  History:
Rem    03-feb-03 (vdevadha)
Rem      Created.
Rem    22-aug-12 (dlong)
Rem      Fix 6708309 - include parens in the syntax, so function-based
Rem      indexes are created.

whenever sqlerror exit sql.sqlcode

declare
    s varchar2(200);
begin
    select a.id into s from odmv_attribute a, odmv_classobject c where a.class = c.id and c.name = 'PUBLICOBJECT' and a.name = 'NAME';
    execute immediate 'create index odmi_' || s || '_uppercase_forward on odm_publicobject (nls_upper(name))';
    select a.id into s from odmv_attribute a, odmv_classobject c where a.class = c.id and c.name = 'PUBLICOBJECT' and a.name = 'NAME';
    execute immediate 'create index odmi_' || s || '_uppercase_reverse on odm_publicobject (nls_upper(reverse(name)))';
end;
/

commit;
exit;

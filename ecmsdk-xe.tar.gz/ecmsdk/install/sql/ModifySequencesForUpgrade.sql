REM
REM

whenever sqlerror exit sql.sqlcode

grant SELECT ANY SEQUENCE to &1;

drop SEQUENCE &1..odm_id_seq;
create synonym &1..odm_id_seq for &2..odm_id_seq;

drop SEQUENCE &1..odm_auditid_seq;
create synonym &1..odm_auditid_seq for &2..odm_auditid_seq;

drop SEQUENCE &1..odmz_acl_resolution_seq;
create synonym &1..odmz_acl_resolution_seq for &2..odmz_acl_resolution_seq;

drop SEQUENCE &1..odmz_event_seq;
create synonym &1..odmz_event_seq for &2..odmz_event_seq;
    
drop SEQUENCE &1..odmz_folderindex_update_seq;
create synonym &1..odmz_folderindex_update_seq for &2..odmz_folderindex_update_seq;

commit;
exit;


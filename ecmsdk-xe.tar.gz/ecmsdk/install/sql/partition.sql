Rem Copyright (c) 2001, 2008, Oracle. All rights reserved.  

whenever sqlerror exit sql.sqlcode

set serveroutput on
exec odm.partitionSubClasses('PUBLICOBJECT');
exec odm.rebuildIndexes('PUBLICOBJECT');
exec odm.rebuildIndexPartitions('PUBLICOBJECT');
exit;


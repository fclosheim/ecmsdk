Rem Copyright (c) 2002, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    convert_to_partitioning.sql - convert iFS schema to use partitioning
Rem
Rem History:
Rem  28-apr-02 (dlong)
Rem    Created.

whenever sqlerror exit sql.sqlcode
set serveroutput on

create table odmz_publicobject_temp as select * from odm_publicobject;
drop table odm_publicobject;

create table odm_publicobject
(
	ID                      NUMBER(20) PRIMARY KEY
	,CLASSID                NUMBER(20)
	,NAME                   VARCHAR2(700)
	,DESCRIPTION            VARCHAR2(2000)
	,OWNER                  NUMBER(20)
	,ACL                    NUMBER(20)
	,FAMILY                 NUMBER(20)
	,RESOLVEDPUBLICOBJECT   NUMBER(20)
	,CREATEDATE             NUMBER(20)
	,CREATOR                NUMBER(20)
	,LASTMODIFYDATE         NUMBER(20)
	,LASTMODIFIER           NUMBER(20)
	,DELETOR                NUMBER(20)
	,POLICYBUNDLE           NUMBER(20)
	,PROPERTYBUNDLE         NUMBER(20)
	,ADMINISTRATIONGROUP    NUMBER(20)
	,SECURINGPUBLICOBJECT   NUMBER(20)
	,EXPIRATIONDATE         NUMBER(20)
	,LOCKSTATE              NUMBER(10)
	,FLAGS                  NUMBER(10)
	,LOCKEDFORSESSION       NUMBER(20)
	,LOCKOBJECT             NUMBER(20)
) 
partition by range(classid)
(
	partition PUBLICOBJECT values less than (244),
	partition newsubclasses values less than (MAXVALUE)
);

insert into odm_publicobject select * from odmz_publicobject_temp;
drop table odmz_publicobject_temp;

update odm_classobject set partitioned = 1 where uniquename = 'PUBLICOBJECT';
commit;

declare
    s varchar2(200);
begin

    select a.id into s from odmv_attribute a, odmv_classobject c where a.class = c.id and c.name = 'PUBLICOBJECT' and a.name = 'OWNER';
    execute immediate 'create index odmi_' || s || '_uni on odm_publicobject (classid, owner) local';

    select a.id into s from odmv_attribute a, odmv_classobject c where a.class = c.id and c.name = 'PUBLICOBJECT' and a.name = 'ACL';
    execute immediate 'create index odmi_' || s || '_uni on odm_publicobject (classid, acl) local';

    select a.id into s from odmv_attribute a, odmv_classobject c where a.class = c.id and c.name = 'PUBLICOBJECT' and a.name = 'FAMILY';
    execute immediate 'create index odmi_' || s || '_uni on odm_publicobject (classid, family) local';
   
    select a.id into s from odmv_attribute a, odmv_classobject c where a.class = c.id and c.name = 'PUBLICOBJECT' and a.name = 'LOCKOBJECT';
    execute immediate 'create index odmi_' || s || '_uni on odm_publicobject (classid, lockobject) local';
    
end;
/

exec odm.partitionSubClasses('PUBLICOBJECT');
exec odm.rebuildIndexes('PUBLICOBJECT');
exec odm.rebuildIndexPartitions('PUBLICOBJECT');

exit;


Rem Copyright (c) 2004, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem     
Rem
Rem  History:
Rem    16-sep-05 (vdevadha)
Rem       Created.

declare
    jobid binary_integer;
    err_num number;
        CURSOR c1  is
                select job from user_jobs where what like 'collectStat%';
begin
        for cIdx in c1 loop
        dbms_output.put_line('Removing DBMS Job : ' || cIdx.job);
        dbms_job.remove( job=>cIdx.job);
    end loop;
end;
/

drop procedure collectStatsDuringUpgrade;

commit;

exit;



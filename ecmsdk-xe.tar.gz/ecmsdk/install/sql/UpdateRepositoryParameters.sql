Rem Copyright (c) 2015, inxire GmbH and/or its affiliates.
Rem All rights reserved. 
Rem
Rem  NAME
Rem    UpdateRepositoryParameters.sql - initial population of ODMZ_REPOSITORYPARAMETERS
Rem
Rem History:
Rem     15-apr-15 (fcloshei)
Rem         Created.

UPDATE odmz_repositoryparameter set value = '&2' where name = '&1';

Rem Copyright (c) 2001, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    GrantConnectToCmSchema.sql - Used in upgrade, so that we can connect to cm 
Rem                                 schema during loadjava. 
Rem
Rem  History:
Rem    08-may-00 (vdevadha)
Rem      Created.  
Rem    13-aug-04 (pyoung)
Rem      grant additional priviledges now omitted by 10g.

whenever sqlerror exit sql.sqlcode
set serveroutput on

Prompt Granting connect permissions from &1
GRANT CREATE SESSION TO &1;
GRANT CREATE TABLE TO &1;
GRANT CREATE VIEW TO &1;
GRANT CREATE SEQUENCE TO &1;
GRANT CREATE CLUSTER TO &1;
GRANT CREATE DATABASE LINK TO &1;
GRANT CREATE SYNONYM TO &1;
GRANT ALTER SESSION TO &1;

whenever sqlerror exit 0

commit;

exit;


Rem Copyright (c) 2004, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem   UpgradeStatsCollection.sql.sql - Used to generate stats during upgrade. 
Rem
Rem  History:
Rem    16-sep-05 (vdevadha)
Rem       Script to generate stats during upgrade. 

set serveroutput on;
spool UpgradeStatsCollection.log;

set echo on;

whenever sqlerror exit sql.sqlcode;

create or replace procedure collectStatsDuringUpgrade
 is
        CURSOR c1  is
                select table_name from user_tables where table_name like 'TP$%';
        tableName varchar(30);
        err_num NUMBER;
begin
        for cIdx in c1 loop
                begin
                        tableName := cIdx.table_name;
                        dbms_stats.gather_table_stats(ownname => '&1', tabname => tableName, granularity => 'ALL', cascade => TRUE );
                exception
                        when others then
                                err_num := SQLCODE;
                                if ( err_num != -25191 ) then
                                        raise;
                                end if;
                end;
        end loop;
end;

/
commit;

declare
    job binary_integer;
begin
    dbms_job.submit(job=>job,
      what=>'collectStatsDuringUpgrade;',
    interval=>'SYSDATE +((1/24) * (1/2))');
end;
/
commit;

exit;





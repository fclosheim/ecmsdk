Rem Copyright (c) 2004, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem   UpgradeContextIndex.sql - Used to upgrade context index. 
Rem
Rem  History:
Rem    12-sep-05 (vdevadha)
Rem       Script to upgrade context index. 

set serveroutput on;
spool UpgradeContextIndex.log;

set echo on;

whenever sqlerror exit sql.sqlcode;

create or replace procedure updatePref (name varchar2, value varchar2)
 is
    preCount number(2);
    begin
        SELECT count(*) into preCount from ctx_user_preferences where pre_name = name;
        if (preCount = 0)
        then
          ctx_ddl.create_preference(name, value);
        else
          dbms_output.put_line('Preference already exists : ' || name);
        end if;
    end;
/

create or replace procedure updateSectionGroup (name varchar2, value varchar2)
 is
    preCount number(2);
    begin
        SELECT count(*) into preCount from ctx_user_section_groups where sgp_name = name;
        if (preCount = 0)
        then
          ctx_ddl.create_section_group(name, value);
        else
          dbms_output.put_line('Section Group already exists : ' || name);
        end if;
    end;
/

create or replace procedure updatePolicy (name varchar2)
 is
    preCount number(2);
    begin
        SELECT count(*) into preCount from ctx_user_indexes where idx_name = name;
        if (preCount = 0)
        then
          ctx_ddl.create_policy(policy_name => 'IfsFilterPolicy',
            filter => 'IFS_VIEW_AS_HTML_FILTER',
            section_group => 'IFS_SECTION_GROUP',
            lexer => 'IFS_DEFAULT_LEXER',
          stoplist => 'CTXSYS.DEFAULT_STOPLIST',
          wordlist => 'IFS_DEF_WORDLIST');          
        else
          dbms_output.put_line('Policy already exists : ' || name);
        end if;
    end;
/
whenever sqlerror exit sql.sqlcode

Rem
Rem  Stemming & Fuzzy Queries are enabled, Soundex Queries are disabled.
Rem
Prompt Setting up Default WordList Preference.
exec updatePref('IFS_DEF_WORDLIST', 'BASIC_WORDLIST');

Rem ---
Rem ---  Create sublexers for the "global" multi-lexer
Rem ---

Rem
Rem Setup Default LEXER with theme & text indexing enabled
Rem but no base letter to get an exact match on the indexing
Rem
Prompt Setting up Default (English) Lexer with text and theme indexing enabled.
exec updatePref('IFS_DEFAULT_LEXER', 'BASIC_LEXER');
exec ctx_ddl.set_attribute('IFS_DEFAULT_LEXER', 'INDEX_THEMES', 'NO');
exec ctx_ddl.set_attribute('IFS_DEFAULT_LEXER', 'INDEX_TEXT', 'YES');
exec ctx_ddl.set_attribute('IFS_DEFAULT_LEXER', 'BASE_LETTER', 'YES');

Rem 
Rem Setup German LEXER
Rem 
Prompt Setting up German Lexer
exec updatePref('IFS_GERMAN_LEXER', 'BASIC_LEXER');
exec ctx_ddl.set_attribute('IFS_GERMAN_LEXER', 'ALTERNATE_SPELLING', 'GERMAN');
exec ctx_ddl.set_attribute('IFS_GERMAN_LEXER', 'BASE_LETTER', 'YES');
Rem German Composite spelling forces MIXED_CASE=YES
Rem and BASE_LETTER=NO, so it is not used.

Rem Setup Danish LEXER
Prompt Setting up Danish Lexer
exec updatePref('IFS_DANISH_LEXER', 'BASIC_LEXER');
exec ctx_ddl.set_attribute('IFS_DANISH_LEXER', 'ALTERNATE_SPELLING', 'DANISH');
exec ctx_ddl.set_attribute('IFS_DANISH_LEXER', 'BASE_LETTER', 'YES');

Rem 
Rem Setup Swedish LEXER
Rem 
Prompt Setting up Swedish Lexer
exec updatePref('IFS_SWEDISH_LEXER', 'BASIC_LEXER');
exec ctx_ddl.set_attribute('IFS_SWEDISH_LEXER', 'ALTERNATE_SPELLING', 'SWEDISH');
exec ctx_ddl.set_attribute('IFS_SWEDISH_LEXER', 'BASE_LETTER', 'YES');

Rem
Rem  Now setup the multi byte lexers
Rem 

Rem
Rem Setup Japanese LEXER
Rem
Prompt Setting up Japanese Lexer
exec updatePref('IFS_JAPANESE_LEXER', 'JAPANESE_VGRAM_LEXER');

Rem
Rem Setup Chinese LEXER
Rem
Prompt Setting up Chinese Lexer
exec updatePref('IFS_CHINESE_LEXER', 'CHINESE_VGRAM_LEXER');

Rem
Rem Setup Korean LEXER
Rem
Prompt Setting up Korean Lexer
exec updatePref('IFS_KOREAN_LEXER', 'KOREAN_MORPH_LEXER');

Rem
Rem Now create the Global Lexer
Rem
Prompt Creating Global LEXER 
exec updatePref('IFS_GLOBAL_LEXER', 'multi_lexer');
Prompt adding Default sublexer
exec ctx_ddl.add_sub_lexer('IFS_GLOBAL_LEXER','default','IFS_DEFAULT_LEXER');
Prompt adding Japanese sublexer
exec ctx_ddl.add_sub_lexer('IFS_GLOBAL_LEXER','JAPANESE','IFS_JAPANESE_LEXER');
Prompt adding Simplified Chinese sublexer
exec ctx_ddl.add_sub_lexer('IFS_GLOBAL_LEXER','SIMPLIFIED CHINESE','IFS_CHINESE_LEXER');
Prompt adding Traditional Chinese sublexer
exec ctx_ddl.add_sub_lexer('IFS_GLOBAL_LEXER','TRADITIONAL CHINESE','IFS_CHINESE_LEXER');
Prompt adding Korean sublexer
exec ctx_ddl.add_sub_lexer('IFS_GLOBAL_LEXER','KOREAN','IFS_KOREAN_LEXER');
Prompt adding German sublexer
exec ctx_ddl.add_sub_lexer('IFS_GLOBAL_LEXER','GERMAN','IFS_GERMAN_LEXER');
Prompt adding Danish sublexer
exec ctx_ddl.add_sub_lexer('IFS_GLOBAL_LEXER','DANISH','IFS_DANISH_LEXER');
Prompt adding Swedish sublexer
exec ctx_ddl.add_sub_lexer('IFS_GLOBAL_LEXER','SWEDISH','IFS_SWEDISH_LEXER');

alter index ifs_text rebuild parameters('replace metadata lexer
IFS_GLOBAL_LEXER');

Rem create filter preference for view_as_html. 
exec updatePref('IFS_VIEW_AS_HTML_FILTER', 'INSO_FILTER');
exec ctx_ddl.set_attribute('IFS_VIEW_AS_HTML_FILTER', 'TIMEOUT', '120');

Prompt Creating filter policy for view_as_html functionality

exec updateSectionGroup('IFS_SECTION_GROUP', 'AUTO_SECTION_GROUP');

Prompt creating new policy
exec updatePolicy('IfsFilterPolicy');

drop procedure updatePref;
drop procedure updateSectionGroup;
drop procedure updatePolicy;

exit;



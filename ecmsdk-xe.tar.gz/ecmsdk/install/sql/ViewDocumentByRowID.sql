Rem Copyright (c) 2001, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    ViewDocumentByRowID.sql 
Rem
Rem    Retrieves information about a document by its RowID.
Rem 
Rem    This is useful for examining what document has just been 
Rem    indexed by Oracle Text (if you are logging RowIDs).  
Rem    See SyncContextIndex.sql for more information.
Rem
Rem  History:
Rem    27-jun-01 (awiersba)
Rem      Created
Rem    09-jul-01 (awiersba)
Rem      Modified descriptions
Rem      Removed whenever sqlerror 
Rem      Changed to support command line argument
Rem    22-oct-07 (dpitfiel)
Rem      ID column of odmz_context_router is now the ContentObject id.

Rem Run as the Oracle 9iFS schema user, for example, ifssys
Rem Run this in SQLPLUS for 80-column formatting

Prompt Enter rowid from Oracle Text log to view information about the document.

column name format a28
column uniquename format a19 heading 'OWNER'
column filebytes format 999999999

select du.uniquename, vd.name, co.contentsize filebytes
from odmv_document vd, 
     odm_contentobject co, 
     odm_document od, 
     odm_directoryuser du, 
     odmz_context_router oc 
where vd.id = od.id 
  and od.contentobject = co.id 
  and du.id = vd.owner 
  and co.id = oc.id 
  and oc.rowid = '&1'
/


Rem Copyright (c) 2002, 2008, Oracle. All rights reserved.  
Rem
Rem  History:
Rem    2002-04-15  spinto    Created
Rem

set autocommit off;
set echo on;

create or replace package IFS_FSA as

procedure SetUpApprovers(itemtype  in varchar2,
                  itemkey   in varchar2,
                  actid     in number,
                  funcmode  in varchar2,
                  resultout in out varchar2);

procedure SetUpDocList(itemtype  in varchar2,
                  itemkey   in varchar2,
                  actid     in number,
                  funcmode  in varchar2,
                  resultout in out varchar2);

procedure SetProcessInfo(itemtype  in varchar2,
                  itemkey   in varchar2,
                  actid     in number,
                  funcmode  in varchar2,
                  resultout in out varchar2);

procedure SetUpAgents(itemtype  in varchar2,
                  itemkey   in varchar2,
                  actid     in number,
                  funcmode  in varchar2,
                  resultout in out varchar2);

end IFS_FSA;
/

show errors;
 
create or replace package body IFS_FSA as

-- SetUpApprovers
--  Sets the list of approvers and reviewers on the event.
-- IN
--   itemtype  - item type
--   itemkey   - item key
--   actid     - process activity instance id
--   funcmode  - execution mode
-- OUT
--   comparison result (WFSTD_COMPARISON lookup code)
--   GT LT EQ NULL
-- ACTIVITY ATTRIBUTES REFERENCED
--   EVENT - Event whose property is to be compared
--   PROPERTY - Event Property Reference (Based on the lookup of EVENTPROPERTY
--   PARAMETER - Parameter Name if Lookup type = Parameter
--   VALUE - Constant value of correct type
procedure SetUpApprovers(itemtype  in varchar2,
                  itemkey   in varchar2,
                  actid     in number,
                  funcmode  in varchar2,
                  resultout in out varchar2)
is
  Approvers varchar2(200);
  Reviewers varchar2(200);
  rname     varchar2(30);
  rdname    varchar2(30);
  rname1     varchar2(30);
  rdname1    varchar2(30);

begin
   Approvers := wf_engine.getItemAttrText(itemtype, itemkey,
                                          'APPROVERS');

   Reviewers := wf_engine.getItemAttrText(itemtype, itemkey,
                                          'REVIEWERS');

   if (length(Approvers) != 0) then
     Wf_Directory.CreateAdHocRole(role_name => rname,
			          role_display_name => rdname,
		                  role_users => Approvers);
     wf_engine.setItemAttrText(itemtype, itemkey, 'APPROVERS', rname);
   end if;



   if (length(Reviewers) != 0) then
     Wf_Directory.CreateAdHocRole(role_name => rname1,
		                  role_display_name => rdname1,
		                  role_users => Reviewers);
     wf_engine.setItemAttrText(itemtype, itemkey, 'REVIEWERS', rname1);
   end if;

   resultout := wf_engine.eng_completed||':'||wf_engine.eng_null;
   

exception
  when others then
    Wf_Core.Context('Wf_Standard', 'SetUpApprovers', itemtype,
                    itemkey, to_char(actid), funcmode);
    raise;
end SetUpApprovers;

-- SetUpDocList
--  Sets a string of urls on the event
-- IN
--   itemtype  - item type
--   itemkey   - item key
--   actid     - process activity instance id
--   funcmode  - execution mode
-- OUT
--   comparison result (WFSTD_COMPARISON lookup code)
--   GT LT EQ NULL
-- ACTIVITY ATTRIBUTES REFERENCED
--   EVENT - Event whose property is to be compared
--   PROPERTY - Event Property Reference (Based on the lookup of EVENTPROPERTY
--   PARAMETER - Parameter Name if Lookup type = Parameter
--   VALUE - Constant value of correct type
procedure SetUpDocList(itemtype  in varchar2,
                       itemkey   in varchar2,
                       actid     in number,
                       funcmode  in varchar2,
                       resultout in out varchar2)
is
  numDocsString varchar2(3);
  numDocs int := 0;
  counter binary_integer := 0;
  docList varchar2(30015);
  docUrl varchar2(2000);
begin
   
   numDocsString := wf_engine.getItemAttrText(itemtype, itemkey,
                                              'NUMDOCS');
   numDocs := to_number(numDocsString);

   /*
    * Only 15 documents can be approved at a time - restricted by
    * the max lenght of a workflow message
    */
   if (numDocs > 15) then
     numDocs := 15;
   end if;

   while (counter < numDocs) loop
     docUrl := wf_engine.getItemAttrText(itemtype, itemkey,
                                         'URL'||to_char(counter));
     counter := counter + 1;
     docList := docList || wf_core.newline || docUrl;
   end loop;

   wf_engine.setItemAttrText(itemtype, itemkey, 'DOCLIST', docList);

   resultout := wf_engine.eng_completed||':'||wf_engine.eng_null;
   

exception
  when others then
    Wf_Core.Context('Wf_Standard', 'SetUpDocList', itemtype,
                    itemkey, to_char(actid), funcmode);
    raise;
end SetUpDocList;

-- SetProcessInfo
--  Sets the name of the local system
-- IN
--   itemtype  - item type
--   itemkey   - item key
--   actid     - process activity instance id
--   funcmode  - execution mode
-- OUT
--   comparison result (WFSTD_COMPARISON lookup code)
--   GT LT EQ NULL
-- ACTIVITY ATTRIBUTES REFERENCED
--   EVENT - Event whose property is to be compared
--   PROPERTY - Event Property Reference (Based on the lookup of EVENTPROPERTY
--   PARAMETER - Parameter Name if Lookup type = Parameter
--   VALUE - Constant value of correct type
procedure SetProcessInfo(itemtype  in varchar2,
                  itemkey   in varchar2,
                  actid     in number,
                  funcmode  in varchar2,
                  resultout in out varchar2)
is
    processUrl     varchar2(2000);    

begin
    processUrl := 
      wf_monitor.GetEnvelopeUrl(wf_core.Translate('WF_WEB_AGENT'),
                               itemtype,
                               itemkey,
                               'NO');

   wf_engine.setItemAttrText(itemtype, itemkey, 'PROCESSURL', processUrl);

   resultout := wf_engine.eng_completed||':'||wf_engine.eng_null;

exception
  when others then
    Wf_Core.Context('Wf_Standard', 'SetProcessInfo', itemtype,
                    itemkey, to_char(actid), funcmode);
    raise;
end SetProcessInfo;


-- SetUpAgents
--  Sets the name of the local system
-- IN
--   itemtype  - item type
--   itemkey   - item key
--   actid     - process activity instance id
--   funcmode  - execution mode
-- OUT
--   comparison result (WFSTD_COMPARISON lookup code)
--   GT LT EQ NULL
-- ACTIVITY ATTRIBUTES REFERENCED
--   EVENT - Event whose property is to be compared
--   PROPERTY - Event Property Reference (Based on the lookup of EVENTPROPERTY
--   PARAMETER - Parameter Name if Lookup type = Parameter
--   VALUE - Constant value of correct type
procedure SetUpAgents(itemtype  in varchar2,
                  itemkey   in varchar2,
                  actid     in number,
                  funcmode  in varchar2,
                  resultout in out varchar2)
is

    localSystem    varchar2(40);
    agentName      varchar2(40);

begin
    
    select name into localSystem
    from wf_systems
	where guid = wf_core.translate('WF_SYSTEM_GUID');

    agentName := 'ifs_in@'||localSystem;  
    resultout := wf_engine.eng_completed||':'||wf_engine.eng_null;
    wf_engine.setItemAttrText(itemtype, itemkey, 'IFSINQUEUE', agentName);
   

exception
  when others then
    Wf_Core.Context('Wf_Standard', 'SetUpAgents', itemtype,
                    itemkey, to_char(actid), funcmode);
    raise;
end SetUpAgents;

END IFS_FSA;
/
show errors;

exit;




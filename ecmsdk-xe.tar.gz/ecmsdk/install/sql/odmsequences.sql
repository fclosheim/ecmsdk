Rem
Rem Copyright (c) 2000, 2008, Oracle and/or its affiliates.
Rem All rights reserved. 
Rem
Rem Creates supporting sequences.

whenever sqlerror exit sql.sqlcode

Prompt creating odm_id_seq
CREATE SEQUENCE odm_id_seq
                START WITH 100
                INCREMENT BY 1
                NOMAXVALUE
                NOCYCLE
                ORDER
                CACHE 200;

Prompt creating deferred ACL resolution sequence
CREATE SEQUENCE odmz_acl_resolution_seq
                START WITH 100
                INCREMENT BY 1
                NOMAXVALUE
                NOCYCLE
                ORDER
                CACHE 200;

Prompt creating event sequence
CREATE SEQUENCE odmz_event_seq
                NOCYCLE
                ORDER
                CACHE 200;
    
Prompt creating odmz_folderindex_update_seq
CREATE SEQUENCE odmz_folderindex_update_seq
	              START WITH 100
	              INCREMENT BY 1
	              NOMAXVALUE
	              NOCYCLE
                ORDER
	              CACHE 200;

commit;
exit;

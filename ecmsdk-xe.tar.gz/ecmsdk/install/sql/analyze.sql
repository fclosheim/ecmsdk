Rem Copyright (c) 2001, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    analyze.sql - analyzes Document Management Schema
Rem
Rem  History:
Rem    03-oct-98 (dlong)
Rem      Created
Rem    27-oct-98 (aalavi)
Rem      Use upper('&1') instead of '&1'.
Rem    28-jul-00 (asamuels)
Rem      Use dbms_stats package from 8i
Rem    08-may-02 (pyoung)
Rem      Added creation and export of backup statistics information.
Rem    29-may-02 (vdevadha)
Rem      Dropped stats for DR$% tables.
Rem    29-may-02 (vdevadha)
Rem      Ignore error message if backup stats table already exists.
Rem    03-jul-02 (vdevadha)
Rem      Drop stats for DR$ tables only if they exist.
Rem    23-sep-03 (vdevadha)
Rem      Fix for 3142669 - Made analyze more efficient.  
Rem    04-aug-05 (vdevadha)
Rem      Fix for 4475458 - Changed the name of the stats. 
Rem    26-oct-05 (vdevadha)
Rem      Fix for 4697705 - Again changed the name of the stats. 

Rem unlock schema stats
exec dbms_stats.unlock_schema_stats('&1'); 

Rem Create backup export table

declare
    err_num  NUMBER;
begin
    dbms_stats.create_stat_table(upper('&1'), 'IFS_BACKUP_STATS' );
exception
    when others then
        err_num := SQLCODE;
        if( err_num != -20002 ) then
            raise;
        end if;
end;
/

Rem Export backup table...
exec dbms_stats.export_schema_stats( upper('&1'), 'IFS_BACKUP_STATS', to_char(sysdate, '"stats_"YYYY_MM_DD_HH24_MI_SS'), upper('&1') );

declare
	CURSOR c1  is
		select table_name from user_tables where table_name not like 'DR$%'; 
	tableName varchar(30);
	err_num NUMBER;
begin
	for cIdx in c1 loop
		begin
			tableName := cIdx.table_name;
			dbms_stats.gather_table_stats(ownname => '&1', tabname => tableName, granularity => 'ALL', cascade => TRUE );
		exception
			when others then
				err_num := SQLCODE;
				if ( err_num != -25191 ) then
					raise;
				end if;
		end;
	end loop;
end;

/
commit;
exit;


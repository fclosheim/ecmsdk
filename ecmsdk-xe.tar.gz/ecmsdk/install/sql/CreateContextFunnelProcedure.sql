--
-- Copyright (c) 2008, 2008, Oracle. All rights reserved.  
--
-- History:
--  2001-05-10  lmatter   Created.
--  2001-05-10  lmatter   Changed procedure to return BLOB directly.
--  2007-10-22  dpitfiel  Store ContentObject ID in the ID column of
--                        odmz_context_router.
--  2008-02-20  dpitfiel  Added support for indirect full-text indexing.
--  2008-05-08  dpitfiel  Added CONTENTINDEXPROCEDURE attribute to Media.
--
-- Creates IFS_CONTENT_CONTEXT_PROC.
-- 

CREATE OR REPLACE PROCEDURE ifs_content_context_proc(
  rid IN ROWID,
  content IN OUT NOCOPY BLOB
) IS
  cid NUMBER(20);
  contentindexprocedure VARCHAR(30);
BEGIN
  SELECT cr.indexablecontent, co.content, m.contentindexprocedure
    INTO content, cid, contentindexprocedure
    FROM odmz_context_router cr, odm_contentobject co, odm_media m
    WHERE cr.rowid = rid
      AND cr.id = co.id
      AND co.media = m.id;

  -- Was the content extracted into the INDEXABLECONTENT column?
  IF content IS NULL THEN
    -- No.  Is there a CONTENTINDEXPROCEDURE?
    IF contentindexprocedure IS NULL THEN
      -- No.  Must have been moved from a direct indexed media to an indirect
      -- indexed media before indexing took place.  Schedule for content
      -- extraction.
      UPDATE odmz_context_router
        SET format = 'IGNORE',
            indexingstate = 1       -- 1 = INDEXINGSTATE_AWAITING_EXTRACTION
        WHERE rowid = rid;
    ELSE
      -- Yes.  So call the CONTENTINDEXPROCEDURE to get the content.
      EXECUTE IMMEDIATE
        'BEGIN ' || contentindexprocedure || '(:cid, :content); END;'
        USING cid, IN OUT content;
    END IF;
  ELSE
    -- Yes, the content was extracted.  Use it.  Clear INDEXABLECONTENT.
    UPDATE odmz_context_router
      SET indexablecontent = null
      WHERE rowid = rid;
  END IF;
END;
/
SHOW ERRORS;

CREATE OR REPLACE PROCEDURE &1._wp(
  rid IN ROWID,
  content IN OUT NOCOPY BLOB
) AUTHID DEFINER IS
BEGIN
  ifs_content_context_proc(rid, content);
END;
/
SHOW ERRORS;

GRANT EXECUTE ON &1._wp TO ctxsys;

--
-- EOF
--

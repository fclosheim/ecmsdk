Rem Copyright (c) 2015, inxire GmbH and/or its affiliates.
Rem All rights reserved. 
Rem
Rem  NAME
Rem    InitializeRepositoryParameters.sql - initial population of ODMZ_REPOSITORYPARAMETERS
Rem
Rem History:
Rem     15-Apr-15 (fcloshei)
Rem         Created.

Prompt create repository parameter table
CREATE TABLE odmz_repositoryparameter
(
        name VARCHAR2(700) PRIMARY KEY,
        value VARCHAR2(700)
);


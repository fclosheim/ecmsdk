Rem Copyright (c) 2001, 2012, Oracle and/or its affiliates. 
Rem All rights reserved. 
Rem
Rem  NAME
Rem    CreateIfsCredentialManager2.sql - Second part of credential manager schema creation.
Rem
Rem  History:
Rem    02-jun-00 (vdevadha)
Rem      Created.
Rem    05-jul-00 (vdevadha)
Rem      Ifs Schema owner needs just execute on the package.
Rem    07-jul-00 (vdevadha)
Rem      Code review changes.  
Rem    12-jul-00 (dpitfiel)
Rem      Added FUNCTION getVersionString.
Rem    12-jul-00 (vdevadha)
Rem      Fixed comments.
Rem    28-nov-00 (vdevadha)
Rem      Improved debugging facility in IFS Credential Manager.
Rem    23-jun-09 (dpitfiel)
Rem      Removed columns ntpassword and lmpassword.
Rem    17-feb-12 (dlong)
Rem      Added status column.


whenever sqlerror exit sql.sqlcode

/* create table for directory users */
CREATE TABLE IfsCredentialManager
(
		  distinguishedname VARCHAR2(255) PRIMARY KEY
		, password   VARCHAR2(512)
		, subscriber VARCHAR2(512)
		, status NUMBER(10)
);

exit;

Rem Copyright (c) 2003, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    DrpNameIndex.sql - drops name indexes. 
Rem
Rem  History:
Rem    03-feb-03 (vdevadha)
Rem      Created.

whenever sqlerror exit sql.sqlcode

declare
    s varchar2(200);
begin
    select a.id into s from odmv_attribute a, odmv_classobject c where a.class = c.id and c.name = 'PUBLICOBJECT' and a.name = 'NAME';
    execute immediate 'drop index odmi_' || s || '_uppercase_forward' ; 
    select a.id into s from odmv_attribute a, odmv_classobject c where a.class = c.id and c.name = 'PUBLICOBJECT' and a.name = 'NAME';
    execute immediate 'drop index odmi_' || s || '_uppercase_reverse';
end;
/

commit;
exit;


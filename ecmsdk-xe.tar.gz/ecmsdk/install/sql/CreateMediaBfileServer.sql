--
-- Copyright (c) 2007, 2009, Oracle and/or its affiliates. 
-- All rights reserved. 
--
--  History:
--   2007-12-18  dpitfiel  Created.
--   2008-05-05  dpitfiel  Added basepath parameters.
--   2008-09-18  dpitfiel  Added bufferSize parameter to createbfilefrombfile
--                         and createbfilefromblob.
--   2009-03-16  dpitfiel  Added getabsolutepath.
--
-- Creates PL/SQL package MediaBfileServer.
--

WHENEVER SQLERROR EXIT SQL.SQLCODE

CREATE OR REPLACE PACKAGE mediabfileserver AS
  FUNCTION createbfilefrombfile(
    error OUT VARCHAR2, contenttablename VARCHAR2, columnname VARCHAR2,
    cid NUMBER, mediaId NUMBER, partitionvalue NUMBER,
    basepath VARCHAR2, relativepath VARCHAR2, filename VARCHAR2,
    BFILE bfile, buffersize NUMBER) RETURN NUMBER;
  FUNCTION createbfilefromblob(
    error OUT VARCHAR2, contenttablename VARCHAR2, columnname VARCHAR2,
    cid NUMBER, mediaId NUMBER, partitionvalue NUMBER,
    basepath VARCHAR2, relativepath VARCHAR2, filename VARCHAR2,
    blob BLOB, buffersize NUMBER) RETURN NUMBER;
  FUNCTION createbfilefromreference(
    error OUT VARCHAR2, contenttablename VARCHAR2, columnname VARCHAR2,
    cid NUMBER, mediaId NUMBER, partitionvalue NUMBER,
    basepath VARCHAR2, contentreference VARCHAR2) RETURN NUMBER;
  FUNCTION destroycontent(
    error OUT VARCHAR2, contenttablename VARCHAR2, columnname VARCHAR2,
    cid NUMBER, deletefilerule NUMBER) RETURN NUMBER;
  FUNCTION getabsolutepath(path VARCHAR2) RETURN VARCHAR2;
END MEDIABFILESERVER;
/
SHOW ERRORS;

CREATE OR REPLACE PACKAGE BODY mediabfileserver AS
  FUNCTION createbfilefrombfile(
    error OUT VARCHAR2, contenttablename VARCHAR2, columnname VARCHAR2,
    cid NUMBER, mediaId NUMBER, partitionvalue NUMBER,
    basepath VARCHAR2, relativepath VARCHAR2, filename VARCHAR2,
    bfile BFILE, buffersize NUMBER) RETURN NUMBER
    AS LANGUAGE JAVA NAME 'oracle.ifs.server.S_MediaBfileServer.createBfileFromBfile(
      java.lang.String[], java.lang.String, java.lang.String,
      java.lang.Long, java.lang.Long, java.lang.Long,
      java.lang.String, java.lang.String, java.lang.String,
      oracle.sql.BFILE, int) return int';
  FUNCTION createbfilefromblob(
    error OUT VARCHAR2, contenttablename VARCHAR2, columnname VARCHAR2,
    cid NUMBER, mediaId NUMBER, partitionvalue NUMBER,
    basepath VARCHAR2, relativepath VARCHAR2, filename VARCHAR2,
    blob BLOB, buffersize NUMBER) RETURN NUMBER
    AS LANGUAGE JAVA NAME 'oracle.ifs.server.S_MediaBfileServer.createBfileFromBlob(
      java.lang.String[], java.lang.String, java.lang.String,
      java.lang.Long, java.lang.Long, java.lang.Long,
      java.lang.String, java.lang.String, java.lang.String,
      oracle.sql.BLOB, int) return int';
  FUNCTION createbfilefromreference(
    error OUT VARCHAR2, contenttablename VARCHAR2, columnname VARCHAR2,
    cid NUMBER, mediaId NUMBER, partitionvalue NUMBER,
    basepath VARCHAR2, contentreference VARCHAR2) RETURN NUMBER
    AS LANGUAGE JAVA NAME 'oracle.ifs.server.S_MediaBfileServer.createBfileFromContentReference(
      java.lang.String[], java.lang.String, java.lang.String,
      java.lang.Long, java.lang.Long, java.lang.Long,
      java.lang.String, java.lang.String) return int';
  FUNCTION destroycontent(
    error OUT VARCHAR2, contenttablename VARCHAR2, columnname VARCHAR2,
    cid NUMBER, deletefilerule NUMBER) RETURN NUMBER
    AS LANGUAGE JAVA NAME 'oracle.ifs.server.S_MediaBfileServer.destroyContent(
      java.lang.String[], java.lang.String, java.lang.String,
      java.lang.Long, int) return int';
  FUNCTION getabsolutepath(path VARCHAR2) RETURN VARCHAR2
    AS LANGUAGE JAVA NAME 'oracle.ifs.server.S_MediaBfileServer.getAbsolutePath(
      java.lang.String) return java.lang.String';
END MEDIABFILESERVER;
/
SHOW ERRORS;

EXIT;

--
-- EOF
--

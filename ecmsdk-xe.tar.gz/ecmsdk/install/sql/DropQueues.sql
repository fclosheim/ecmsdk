Rem Copyright (c) 2002, 2008, Oracle. All rights reserved.  
Rem
Rem  History:
Rem    2002-06-10  vdevadha  Created.
Rem

whenever sqlerror continue;

set serveroutput on

rem ==========================================
rem Stop Queue ifs_in and ifs_out
rem ==========================================

DECLARE
BEGIN
    dbms_output.put_line ('Stopping  Queue ifs_in...');
    dbms_aqadm.stop_queue
    (
        queue_name => '&1..ifs_in',
        wait       => TRUE
    );
    dbms_output.put_line ('Stopped Queue ifs_in.');
END;
/

DECLARE
BEGIN
    dbms_output.put_line ('Stopping  Queue ifs_out...');
    dbms_aqadm.stop_queue
    (
        queue_name => '&1..ifs_out',
        wait       => TRUE
    );
    dbms_output.put_line ('Stopped Queue ifs_out.');
END;
/

DECLARE
BEGIN
    dbms_output.put_line ('Stopping  exception queue for ifs_in...');
    dbms_aqadm.stop_queue
    (
        queue_name => '&1..aq$_ifs_in_table_e',
        wait       => TRUE
    );
    dbms_output.put_line ('Stopped exception queue for ifs_in.');
END;
/

DECLARE
BEGIN
    dbms_output.put_line ('Stopping  exception queue for ifs_out...');
    dbms_aqadm.stop_queue
    (
        queue_name => '&1..aq$_ifs_out_table_e',
        wait       => TRUE
    );
    dbms_output.put_line ('Stopped exception queue for ifs_out.');
END;
/

rem ==========================================
rem Drop Queue ifs_in and ifs_out
rem ==========================================

DECLARE
BEGIN
    dbms_output.put_line ('Dropping  Queue ifs_in...');
    dbms_aqadm.drop_queue
    (
        queue_name => '&1..ifs_in'
    );
    dbms_output.put_line ('Dropped Queue ifs_in.');
END;
/

DECLARE
BEGIN
    dbms_output.put_line ('Dropping  Queue ifs_out...');
    dbms_aqadm.drop_queue
    (
        queue_name => '&1..ifs_out'
    );
    dbms_output.put_line ('Dropped Queue ifs_out.');
END;
/


rem ==========================================
rem Drop Input Queue Table
rem ==========================================

DECLARE
BEGIN
    dbms_output.put_line ('Dropping Queue Table ifs_in_table...');
    dbms_aqadm.drop_queue_table
    (
        queue_table => '&1..ifs_in_table',
        force => TRUE
    );
    dbms_output.put_line ('Dropped Queue Table ifs_in_table.');

END;
/

DECLARE
BEGIN
    dbms_output.put_line ('Dropping Queue Table ifs_out_table...');
    dbms_aqadm.drop_queue_table
    (
        queue_table => '&1..ifs_out_table',
        force => TRUE
    );
    dbms_output.put_line ('Dropped Queue Table ifs_out_table.');

END;
/
exit;


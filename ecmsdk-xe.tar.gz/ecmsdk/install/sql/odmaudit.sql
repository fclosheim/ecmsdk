Rem Copyright (c) 2000, 2012, Oracle and/or its affiliates.
Rem All rights reserved. 
Rem
Rem  NAME
Rem    odmaudit.sql - initial creation of Audit database objects.
Rem
Rem History:
Rem     09-jan-12 (dlong)
Rem         Created (split from odmmain.sql)

whenever sqlerror continue

DROP SEQUENCE odm_auditid_seq;

whenever sqlerror exit sql.sqlcode

Prompt creating odm_auditid_seq
CREATE SEQUENCE odm_auditid_seq
                START WITH 100
                INCREMENT BY 1
                NOMAXVALUE
                NOCYCLE
                ORDER
                CACHE 200;

Prompt create RAW audit event table
CREATE TABLE odmza_rawauditevent
(  
      id                  NUMBER(20) PRIMARY KEY
    , domainid            NUMBER(20)
    , operationtype       NUMBER(10) 
    , createdate          NUMBER(20)
    , creatorid           NUMBER(20)
    , sessionuserid       NUMBER(20)
    , sessionid           NUMBER(20)
    , appsessionid        NUMBER(20)
    , operationsucceeded  NUMBER(1) 
    , targetobjectid      NUMBER(20)
    , targetclassid       NUMBER(20)
    , auxobjectid1        NUMBER(20)
    , auxobjectid2        NUMBER(20)
    , auxobjectid3        NUMBER(20)
    , auxobjectid4        NUMBER(20)
    , auxobjectid5        NUMBER(20)
    , auxclassid1         NUMBER(20)
    , auxclassid2         NUMBER(20)
    , auxclassid3         NUMBER(20)
    , auxclassid4         NUMBER(20)
    , auxclassid5         NUMBER(20)
    , propertyid          NUMBER(20)
    , foldercontextid     NUMBER(20)
    , folderpathid        NUMBER(20)
    , inobjecthistory     NUMBER(1)
) CACHE;

Prompt create audit event property table
CREATE TABLE odmza_auditeventproperty
(  
      propertyid          NUMBER(20)
    , seq                 NUMBER(10)
    , infokey             VARCHAR2(200)
    , info                VARCHAR2(700)
);

CREATE INDEX odmzi_auditeventproperty_id ON odmza_auditeventproperty
(
    propertyid
);


Prompt create inline string table
CREATE TABLE odmza_inlinestring
(  
      seq                 NUMBER(20) PRIMARY KEY
    , enabled             NUMBER(1)
    , value               VARCHAR2(2000)
);

CREATE INDEX odmzi_inlinestring_value ON odmza_inlinestring
(
    value
);


Prompt create audit event folder path context table
CREATE TABLE odmza_folderpath
(  
      folderpathid        NUMBER(20) PRIMARY KEY
    , expiretime          NUMBER(20)
    , foldercontextid     NUMBER(20)
    , entrycount          NUMBER(10)
    , pathentry1          NUMBER(20)
    , pathentry2          NUMBER(20)
    , pathentry3          NUMBER(20)
    , pathentry4          NUMBER(20)
    , pathentry5          NUMBER(20)
    , pathentry6          NUMBER(20)
    , pathentry7          NUMBER(20)
    , pathentry8          NUMBER(20)
    , pathentry9          NUMBER(20)
    , pathentry10         NUMBER(20)
    , pathentry11         NUMBER(20)
    , pathentry12         NUMBER(20)
    , pathentry13         NUMBER(20)
    , pathentry14         NUMBER(20)
    , pathentry15         NUMBER(20)
    , pathentry16         NUMBER(20)
    , pathentry17         NUMBER(20)
    , pathentry18         NUMBER(20)
    , pathentry19         NUMBER(20)
    , pathentry20         NUMBER(20)
);

CREATE INDEX odmza_folderpath_folderid ON odmza_folderpath
(
    foldercontextid
);

Prompt create audit event folder path overflow table
CREATE TABLE odmza_folderpathoverflow
(  
      folderpathid        NUMBER(20)
    , seq                 NUMBER(10)
    , pathentry           NUMBER(20)
);

CREATE INDEX odmzi_folderpathoverflow_id ON odmza_folderpathoverflow
(
    folderpathid
);

Prompt create audit event table
CREATE TABLE odmza_auditevent
(  
      id                  NUMBER(20) PRIMARY KEY
    , domainid            NUMBER(20)
    , operationtype       NUMBER(10) 
    , createdate          NUMBER(20)
    , creatorid           NUMBER(20)
    , sessionuserid       NUMBER(20)
    , sessionid           NUMBER(20)
    , appsessionid        NUMBER(20)
    , operationsucceeded  NUMBER(1) 
    , targetobjectid      NUMBER(20)
    , targetclassid       NUMBER(20)
    , auxobjectid1        NUMBER(20)
    , auxobjectid2        NUMBER(20)
    , auxobjectid3        NUMBER(20)
    , auxobjectid4        NUMBER(20)
    , auxobjectid5        NUMBER(20)
    , auxclassid1         NUMBER(20)
    , auxclassid2         NUMBER(20)
    , auxclassid3         NUMBER(20)
    , auxclassid4         NUMBER(20)
    , auxclassid5         NUMBER(20)
    , propertyid          NUMBER(20)
    , foldercontextid     NUMBER(20)
    , auditspecid         NUMBER(20)
);

CREATE INDEX odmzi_auditevent_domainid ON odmza_auditevent
(
    domainid
);

CREATE INDEX odmzi_auditevent_specid ON odmza_auditevent
(
    auditspecid
);

CREATE INDEX odmzi_auditevent_target ON odmza_auditevent
(
    targetobjectid
);

Prompt create unioned view of property references

CREATE VIEW odmza_unionedpropertyview as
select propertyid from odmza_rawauditevent
union all
select propertyid from odmza_auditevent;

Prompt create audit operation type registration table
CREATE TABLE odmza_auditoptype
(  
      optype              NUMBER(10) PRIMARY KEY
    , targetcode          NUMBER(10) NOT NULL
    , opcode              NUMBER(10) NOT NULL
    , targetclassname     VARCHAR2(700) NOT NULL
    , optypekey           VARCHAR2(200) NOT NULL
    , createdorfreed      VARCHAR2(10)
    , deleted             NUMBER(1)
) CACHE;

CREATE UNIQUE INDEX odmzi_auditoptype_key ON odmza_auditoptype
(
    optypekey
);

Prompt create audit target code registration tables and view
CREATE TABLE odmza_audittargetcode
(  
      targetcode          NUMBER(10) PRIMARY KEY
    , optypekeyprefix     VARCHAR2(200) NOT NULL
) CACHE;

CREATE TABLE odmza_audittargetalias
(  
      targettypealias     VARCHAR2(200) PRIMARY KEY
    , optypekeyprefix     VARCHAR2(200) NOT NULL
) CACHE;

CREATE VIEW odmza_audittargetcodealias as
select c.targetcode, c.optypekeyprefix, a.targettypealias
from odmza_audittargetcode c, odmza_audittargetalias a
where c.optypekeyprefix = a.optypekeyprefix;

Prompt audit target code registration tables
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (1, 'DOMAIN');
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (2, 'CONTAINER');
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (3, 'WORKSPACE');
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (4, 'FOLDER');
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (5, 'DOCUMENT');
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (6, 'FAMILY');
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (7, 'LINK');
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (8, 'FOLDERLINK');
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (9, 'ARCHIVE');
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (10, 'TRASHFOLDER');
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (11, 'USER');
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (12, 'GROUP');
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (13, 'ROLE');
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (14, 'FILEPLAN');
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (15, 'RECORDSERIES');
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (16, 'RECORDCATEGORY');
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (17, 'RECORDFOLDER');
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (18, 'CATEGORY_CLASS');
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (19, 'REQUEST');
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (20, 'AUDIT_SPECIFICATION');
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (21, 'RELATION');
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (22, 'SYSTEM');
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (23, 'SERVICESTATE');
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (24, 'NODESTATE');
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (25, 'SERVERSTATE');
INSERT into odmza_audittargetcode (targetcode, optypekeyprefix) 
    values (26, 'HANDLERSTATE');

INSERT into odmza_audittargetalias (targettypealias, optypekeyprefix) 
    select optypekeyprefix, optypekeyprefix from odmza_audittargetcode;

INSERT into odmza_audittargetalias (targettypealias, optypekeyprefix) 
    values ('DIRECTORYUSER', 'USER');
INSERT into odmza_audittargetalias (targettypealias, optypekeyprefix) 
    values ('DOMAINUSER', 'USER');
INSERT into odmza_audittargetalias (targettypealias, optypekeyprefix) 
    values ('DIRECTORYGROUP', 'GROUP');
INSERT into odmza_audittargetalias (targettypealias, optypekeyprefix) 
    values ('USERGROUP', 'GROUP');
INSERT into odmza_audittargetalias (targettypealias, optypekeyprefix) 
    values ('AUDITSPECIFICATION', 'AUDIT_SPECIFICATION');

Prompt create audit event view used for searches
CREATE VIEW odmzav_auditevent as 
select ae.*, 
       ae.AUXCLASSID5 AUXNUMBER,
       inline1.value APPUSER, 
       inline2.value APPCONTEXT, 
       inline3.value AUXSTRING,
       op.optypekey OPTYPEKEY
  from odmza_auditevent ae, 
       odmza_inlinestring inline1,
       odmza_inlinestring inline2,
       odmza_inlinestring inline3,
       odmza_auditoptype  op
  where ae.operationtype = op.optype and
        ae.AUXOBJECTID4 = inline1.seq (+) and
        ae.AUXOBJECTID5 = inline2.seq (+) and
        ae.AUXCLASSID4  = inline3.seq (+);

Prompt create audit target type registration table
CREATE TABLE odmza_audittargetclass
(  
      targetclassname     VARCHAR2(700)
    , detailclassname     VARCHAR2(700)
) CACHE;

Prompt populate audit target type registration table
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('DOMAIN', 'DOMAIN');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('DIRECTORYUSER', 'DIRECTORYUSER');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('DOMAINUSER', 'DOMAINUSER');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('USERGROUP', 'USERGROUP');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('DIRECTORYGROUP', 'DIRECTORYGROUP');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('ROLE', 'ROLE');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('CONTAINER', 'CONTAINER');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('WORKSPACE', 'WORKSPACE');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('TRASHFOLDER', 'TRASHFOLDER');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('ARCHIVE', 'ARCHIVE');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('FOLDER', 'FOLDER');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('FAMILY', 'FAMILY');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('DOCUMENT', 'DOCUMENT');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('LINK', 'LINK');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('FOLDERLINK', 'FOLDERLINK');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('FILEPLAN', 'FILEPLAN');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('RECORDSERIES', 'RECORDSERIES');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('RECORDCATEGORY', 'RECORDCATEGORY');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('RECORDFOLDER', 'RECORDFOLDER');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('ADHOCSCHEMACATEGORY', 'ADHOCSCHEMACATEGORY');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('REQUEST', 'REQUEST');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('AUDITSPECIFICATION', 'AUDITSPECIFICATION');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('RELATION', 'RELATION');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('SYSTEM', 'SYSTEM');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('SERVICESTATE', 'SERVICESTATE');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('NODESTATE', 'NODESTATE');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('SERVERSTATE', 'SERVERSTATE');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('HANDLERSTATE', 'HANDLERSTATE');

Prompt populate audit target types that are descendents
Prompt everything descends from Domain
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    select 'DOMAIN', detailclassname 
    from odmza_audittargetclass where targetclassname != 'DOMAIN';

INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('SYSTEM', 'AUDITSPECIFICATION');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('SYSTEM', 'SERVICESTATE');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('SYSTEM', 'NODESTATE');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('SYSTEM', 'SERVERSTATE');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('SYSTEM', 'HANDLERSTATE');

INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('DIRECTORYUSER', 'DOMAINUSER');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('DIRECTORYGROUP', 'USERGROUP');

INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('FOLDER', 'FAMILY');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('FOLDER', 'DOCUMENT');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('FOLDER', 'LINK');
INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    values ('FOLDER', 'FOLDERLINK');

INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    select 'WORKSPACE', detailclassname 
    from odmza_audittargetclass where targetclassname = 'FOLDER';

INSERT into odmza_audittargetclass (targetclassname, detailclassname) 
    select 'CONTAINER', detailclassname 
    from odmza_audittargetclass where targetclassname = 'WORKSPACE';

Prompt create custom audit operation key registration tables
CREATE TABLE odmza_customopcode
(
    opcode                NUMBER(10) PRIMARY KEY
    , opcodekey           VARCHAR2(160) NOT NULL
) CACHE;

CREATE UNIQUE INDEX odmzi_customopcode_key ON odmza_customopcode
(
    opcodekey
);

CREATE TABLE odmza_nextcustomopcode
(
    opcode                NUMBER(10) NOT NULL
) CACHE;

Prompt initialize so that first custom opcode is 10000
insert into odmza_nextcustomopcode (opcode) values (9999);

Prompt create audit certificate table
CREATE TABLE odmza_objectcertificate
(  
      id                  NUMBER(20) PRIMARY KEY
    , classid             NUMBER(20)
    , freed               NUMBER(1)
    , createdate          NUMBER(20)
    , creatorid           NUMBER(20)
    , domainid            NUMBER(20)
    , secured             NUMBER(1)
    , freedate            NUMBER(20)
    , deletorid           NUMBER(20)
    , tombstoneid         NUMBER(20)
    , name                VARCHAR2(700)
    , classname           VARCHAR2(700)
);

Prompt create repository parameter that enables auditing
INSERT INTO odmz_repositoryparameter
  (name, value) VALUES ('AUDITINGENABLED', 'true');

commit;
exit;


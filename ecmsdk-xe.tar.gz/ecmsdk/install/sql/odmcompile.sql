Rem Copyright (c) 2001, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME: odmcompile.sql
Rem
Rem        This file is used to catch all objects marked as
Rem        INVALID and create a recompile script from it. At 
Rem        the end it will report all objects that are still
Rem        not compiled.
Rem
Rem  History:
Rem    01-jun-99 (jfroese)
Rem      Initial creation
Rem

set termout off
set pagesize 0
set heading off
spool compile.sql

select 'ALTER ' || object_type || ' ' || object_name || ' COMPILE;'
from user_objects where status = 'INVALID';

spool off;

@compile.sql

--
--	Now check if all is clean, this MUST return 0 rows now
--
set termout on
set heading on

select object_name, object_type, status from user_objects where status = 'INVALID';

exit



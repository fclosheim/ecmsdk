REM Copyright (c) 2004, 2008, Oracle. All rights reserved.  
REM
REM    NAME
REM      Upgrade10gConnectPrivs.sql - upgrade to provide additional
REM      priviledges now omitted by 10g R2.
REM
REM   History
REM     08-sep-04 (pyoung)
REM        created.
REM     31-may-05 (sgarg)
REM        removed references to $dr schema

whenever sqlerror exit sql.sqlcode;
set serveroutput on

prompt Applying 10g connect role fix

REM grant privs once available to CONNECT role for CMSDK schema
GRANT CREATE VIEW TO &1;
GRANT CREATE TABLE TO &1;
GRANT ALTER SESSION TO &1;
GRANT CREATE CLUSTER TO &1;
GRANT CREATE SESSION TO &1;
GRANT CREATE SYNONYM TO &1;
GRANT CREATE SEQUENCE TO &1;
GRANT CREATE DATABASE LINK TO &1;

REM grant privs once available to CONNECT role for CMSDK credential manager
REM schema
GRANT CREATE VIEW TO &1$id;
GRANT CREATE TABLE TO &1$id;
GRANT ALTER SESSION TO &1$id;
GRANT CREATE CLUSTER TO &1$id;
GRANT CREATE SESSION TO &1$id;
GRANT CREATE SYNONYM TO &1$id;
GRANT CREATE SEQUENCE TO &1$id;
GRANT CREATE DATABASE LINK TO &1$id;

whenever sqlerror exit 0;

exit;


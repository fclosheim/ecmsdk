Rem Copyright (c) 2007, 2008, Oracle. All rights reserved.
Rem
Rem NAME
Rem   odmviews.sql - initial population of views for CDB.
Rem
Rem History:
Rem   2007-11-28  dlong     Created.
Rem   2008-09-05  dpitfiel  Renamed CONTENTPROCEDURE to CONTENTINDEX in
Rem                         odmz_context_router.

whenever sqlerror exit sql.sqlcode

Prompt creating odmz_context_document
CREATE OR REPLACE VIEW odmz_context_document as
  select doc.*, cr.contentindex contentindex
   from ODMV_DOCUMENT doc, ODMZ_CONTEXT_ROUTER cr
   where doc.CONTENTOBJECT = cr.ID;

commit;
exit;


Rem Copyright (c) 2000, 2012, Oracle and/or its affiliates. All rights reserved.
Rem
Rem  NAME
Rem    RevokeIfsCredentialManager.sql - revoke access from the 
Rem      credential manager user.
Rem
Rem  History:
Rem    05-jul-00 (vdevadha)
Rem      Created.  
Rem    16-aug-04 (pyoung)
Rem      Update connect privileges for 10g security changes.
Rem    12-feb-12 (dlong)
Rem      Renamed from CreateIfsCredentialManager3.sql.

whenever sqlerror exit sql.sqlcode
set serveroutput on

Prompt Revoking connect permissions from &1
REVOKE ALTER SESSION FROM &1;
REVOKE CREATE CLUSTER FROM &1;
REVOKE CREATE DATABASE LINK FROM &1;
REVOKE CREATE SEQUENCE FROM &1;
REVOKE CREATE SESSION FROM &1;
REVOKE CREATE SYNONYM FROM &1;
REVOKE CREATE TABLE FROM &1;
REVOKE CREATE VIEW FROM &1;

whenever sqlerror exit 0

commit;

exit;


Rem Copyright (c) 2001, 2008, Oracle. All rights reserved.  
Rem
Rem NAME
Rem     CreateOidCredentiqlManager.sql
Rem         Sets up database objects for OiD synchronization.
Rem
Rem PARAMETERS
Rem     &1  schema name, e.g. ifsuser
Rem     &2  schema password, e.g. ifsuser
Rem     &3  DBA name, e.g. sys
Rem     &4  DBA password, e.g. change_on_install
Rem
Rem History:
Rem     23-oct-01 (dpitfiel)
Rem         Created.
Rem     23-oct-01 (dpitfiel)
Rem         Renamed odmv_oidcredentialmanagerdn to
Rem         odmzv_oidcredentialmanagerdn.
Rem     09-nov-01 (dpitfiel)
Rem         Added &5 for connect string.
Rem     13-dec-02 (dpitfiel)
Rem         Augmented event table.
Rem     16-dec-02 (dpitfiel)
Rem         Made idempotent.
Rem     06-jan-03 (dpitfiel)
Rem         Removed use of synonym to TYPE.
Rem     13-aug-04 (pyoung)
Rem         grant additional priviledges now omitted by 10g.
Rem     08-Jul-04 (dmaser)
Rem         Upgrade package LDAP_NTFY to OID provisioning interface version 3.0
Rem     19-Oct-04 (dmaser)
Rem         Changed all LDAP_<xx> to LDAP_<xx>_V3 as required by OID 9.0.5
Rem         

WHENEVER sqlerror EXIT SQL.SQLCODE
SET SERVEROUTPUT ON


--
-- Connect as DBA and create the <base>$id schema.
--

CONNECT &3/&4 AS sysdba;

DECLARE
    CURSOR c IS
        SELECT username FROM DBA_USERS WHERE username = UPPER('&1$id');
        
    cur         INTEGER;
    ret         INTEGER;
    sel         VARCHAR(2000);
BEGIN
    FOR cx in c LOOP
        sel := 'DROP USER ' || UPPER('&1$id') || ' CASCADE';
        DBMS_OUTPUT.PUT_LINE('Dropping schema: ' || sel);
        cur := DBMS_SQL.OPEN_CURSOR;
        DBMS_SQL.PARSE(cur, sel, DBMS_SQL.NATIVE);
        ret := DBMS_SQL.EXECUTE(cur);
        DBMS_SQL.CLOSE_CURSOR(cur);
    END LOOP;
 END;
/
SHOW ERRORS


CREATE USER &1$id IDENTIFIED BY temporary;
GRANT CONNECT TO &1$id;
GRANT RESOURCE TO &1$id;
GRANT CREATE SESSION TO &1$id;
GRANT CREATE TABLE TO &1$id;
GRANT CREATE VIEW TO &1$id;
GRANT CREATE SEQUENCE TO &1$id;
GRANT CREATE CLUSTER TO &1$id;
GRANT CREATE DATABASE LINK TO &1$id;
GRANT CREATE SYNONYM TO &1$id;
GRANT ALTER SESSION TO &1$id;



--
-- Reconnect as the <base> iFS schema and create a table for
-- OidCredentialManager events and a view of DirectoryUser
-- distinguished names.
--

CONNECT &1/&2;

-- The following makes this script idempotent.  This is
-- important since this script is also used for upgrades.
-- Dropping the odmz_oidcredentialmanagerevent table is
-- specifically required for the 903->904 upgrade case.
WHENEVER sqlerror CONTINUE
DROP TABLE odmz_oidcredentialmanagerevent;
DROP VIEW odmzv_oidcredentialmanagerdn;
DROP TABLE odmz_oidcredentialmanagerevnt;
DROP TYPE LDAP_ATTR_NAME_LIST_V3;

CONNECT &1$id/temporary;

DROP TYPE LDAP_EVENT_LIST_V3;
DROP TYPE LDAP_EVENT_V3;
DROP TYPE LDAP_EVENT_STATUS_LIST_V3;
DROP TYPE LDAP_EVENT_STATUS_V3;
DROP TYPE LDAP_ATTR_LIST_V3;
DROP TYPE LDAP_ATTR_V3;
DROP TYPE LDAP_ATTR_VALUE_LIST_V3;
DROP TYPE LDAP_ATTR_VALUE_V3;


CONNECT &1/&2;
WHENEVER sqlerror EXIT SQL.SQLCODE

CREATE TYPE LDAP_ATTR_NAME_LIST_V3 AS TABLE OF VARCHAR2(255);
/
SHOW ERRORS;

GRANT EXECUTE ON LDAP_ATTR_NAME_LIST_V3 TO &1$id;

CREATE TABLE odmz_oidcredentialmanagerevnt
(
    event_id        NUMBER(32) PRIMARY KEY,
    object_guid     VARCHAR2(200),
    event_type      VARCHAR2(200),
    profile_id      VARCHAR2(200),
    attr_name_list  LDAP_ATTR_NAME_LIST_V3
) NESTED TABLE attr_name_list STORE AS odmz_oidcredentialmanagerevnta;

GRANT INSERT ON odmz_oidcredentialmanagerevnt TO &1$id;

CREATE VIEW odmzv_oidcredentialmanagerdn
    AS SELECT distinguishedname FROM odmv_directoryobject;

GRANT SELECT ON odmzv_oidcredentialmanagerdn TO &1$id;
/

--
-- Reconnect as the <base>$id schema and create the synonynms,
-- the sequence, the types, and the package.
--

CONNECT &1$id/temporary;

CREATE SYNONYM odmz_oidcredentialmanagerevnt FOR &1..odmz_oidcredentialmanagerevnt;
CREATE SYNONYM odmzv_oidcredentialmanagerdn FOR &1..odmzv_oidcredentialmanagerdn;

CREATE SEQUENCE ldap_seq NOCYCLE ORDER CACHE 200;


CREATE TYPE LDAP_ATTR_VALUE_V3 AS OBJECT (                                
     attr_value       VARCHAR2(4000),
     attr_bvalue      RAW(2048),
     attr_value_len   INTEGER
);
/
SHOW ERRORS;

GRANT EXECUTE ON LDAP_ATTR_VALUE_V3 TO public;
CREATE TYPE LDAP_ATTR_VALUE_LIST_V3 AS TABLE OF LDAP_ATTR_VALUE_V3;
/
GRANT EXECUTE ON LDAP_ATTR_VALUE_LIST_V3 TO public;

-- LDAP ATTR
----------------------------------------------------------------
--
--  Name        : LDAP_ATTR_V3
--  Data Type   : OBJECT
--  DESCRIPTION : This structure contains details regarding 
--                an attribute. 
--
----------------------------------------------------------------
CREATE TYPE LDAP_ATTR_V3 AS OBJECT (                                
     attr_name        VARCHAR2(255),
     attr_type        INTEGER, 
     attr_mod_op      INTEGER,
     attr_values      LDAP_ATTR_VALUE_LIST_V3
);
/
SHOW ERRORS;

GRANT EXECUTE ON LDAP_ATTR_V3 TO public;
/
SHOW ERRORS;

-------------------------------------------------------------
--
--  Name        : LDAP_ATTR_LIST_V3
--  Data Type   : COLLECTION
--  DESCRIPTION : This structure contains collection 
--                of attributes.
--
-------------------------------------------------------------
CREATE TYPE LDAP_ATTR_LIST_V3 AS TABLE OF LDAP_ATTR_V3;
/
SHOW ERRORS;
GRANT EXECUTE ON LDAP_ATTR_LIST_V3 TO public;

-------------------------------------------------------------
-- Name:        LDAP_EVENT_V3
-- Data Type:   OBJECT
-- DESCRIPTION: This structure contains event information 
--              plus the attribute List
-------------------------------------------------------------

CREATE TYPE LDAP_EVENT_V3 AS OBJECT (
          event_type  VARCHAR2(32),
          event_id    VARCHAR2(32),
          event_src   VARCHAR2(1024),
          event_time  VARCHAR2(32),
          object_name VARCHAR2(1024),
          object_type VARCHAR2(32),
          object_guid VARCHAR2(32),
          object_dn   VARCHAR2(1024),
          profile_id  VARCHAR2(1024),
          attr_list   LDAP_ATTR_LIST_V3
) ;
/
SHOW ERRORS;

GRANT EXECUTE ON LDAP_EVENT_V3 to public;
CREATE TYPE LDAP_EVENT_LIST_V3 AS TABLE OF LDAP_EVENT_V3;
/
GRANT EXECUTE ON LDAP_EVENT_LIST_V3 to public;
/

-----------------------------------------------------------
-- Name:        LDAP_EVENT_STATUS_V3
-- Data Type:   OBJECT
-- DESCRIPTION: This structure contains information that is 
--              sent by the consumer of an event to the 
--              supplier in response to the actual event.
------------------------------------------------------------

CREATE TYPE LDAP_EVENT_STATUS_V3 AS OBJECT (
          event_id     VARCHAR2(32),
          status       VARCHAR2(32),
          status_msg   VARCHAR2(2048),
          object_guid  VARCHAR2(32)
) ;
/
SHOW ERRORS;
GRANT EXECUTE ON LDAP_EVENT_STATUS_V3 to public;
CREATE TYPE LDAP_EVENT_STATUS_LIST_V3 AS TABLE OF LDAP_EVENT_STATUS_V3;
/
GRANT EXECUTE ON LDAP_EVENT_STATUS_LIST_V3 to public;
/

-------------------------------------------------------------------------------
--
--  NAME        : LDAP_NTFY
--  DESCRIPTION : This a notifier interface implemented by Provisioning System
--                clients to receive information about changes in OID.
--                The name of package can be customized as needed. 
--                The functions names within this package SHOULD NOT be changed.
--
--
-------------------------------------------------------------------------------
CREATE PACKAGE LDAP_NTFY AS

    --
    -- LDAP_NTFY data type definitions
    --
    
    -- Event Types
    USER_ADD                  CONSTANT VARCHAR2(256) := 'USER_ADD';
    USER_DELETE               CONSTANT VARCHAR2(256) := 'USER_DELETE';
    USER_MODIFY               CONSTANT VARCHAR2(256) := 'USER_MODIFY';
    GROUP_ADD                 CONSTANT VARCHAR2(256) := 'GROUP_ADD';
    GROUP_DELETE              CONSTANT VARCHAR2(256) := 'GROUP_DELETE';
    GROUP_MODIFY              CONSTANT VARCHAR2(256) := 'GROUP_MODIFY';

    -- Attribute Type
    ATTR_TYPE_STRING             CONSTANT NUMBER  := 0;
    ATTR_TYPE_BINARY             CONSTANT NUMBER  := 1;
    ATTR_TYPE_ENCRYPTED_STRING   CONSTANT NUMBER  := 2;

    -- Values for attr_mod_op in LDAP_ATTR_V3 object.
    MOD_ADD                   CONSTANT NUMBER  := 0;
    MOD_DELETE                CONSTANT NUMBER  := 1;
    MOD_REPLACE               CONSTANT NUMBER  := 2;

    -- Return Codes (Boolean)
    SUCCESS                   CONSTANT NUMBER  := 1;
    FAILURE                   CONSTANT NUMBER  := 0;

    -- The Event dispostions constants
    EVENT_SUCCESS             CONSTANT VARCHAR2(32)  := 'EVENT_SUCCESS';
    EVENT_IN_PROGRESS         CONSTANT VARCHAR2(32)  := 'EVENT_IN_PROGRESS';
    EVENT_USER_NOT_REQUIRED   CONSTANT VARCHAR2(32)  := 'EVENT_USER_NOT_REQUIRED';
    EVENT_ERROR               CONSTANT VARCHAR2(32)  := 'EVENT_ERROR';
    EVENT_ERROR_ALERT         CONSTANT VARCHAR2(32)  := 'EVENT_ERROR_ALERT';
    EVENT_ERROR_ABORT         CONSTANT VARCHAR2(32)  := 'EVENT_ERROR_ABORT';


    --
    -- LDAP_NTFY function definitions
    --
    
    /**
     ******************************************************
     *
     * FUNCTION    : user_exists
     * DESCRIPTION : A callback function invoked by Provisioning System
     *               to check if a user is enrolled with application
     * INPUTS      : 
     *               user_name   IN VARCHAR2 - user Id.
     *               user_guid   IN VARCHAR2 - Global User Id. 
     *               user_dn     IN VARCHAR2 - Dn attribute of the user entry.
     * OUTPUT      : Returns a(any) positive number if the user exists
     *
     ******************************************************
     */
    FUNCTION user_exists ( user_name    IN VARCHAR2,
                           user_guid    IN VARCHAR2,
                           user_dn      IN VARCHAR2)
    RETURN NUMBER;

    /**
     ******************************************************
     *
     * FUNCTION    : group_exists
     * DESCRIPTION : A callback function invoked by Provisioning System
     *               to check whether a group exists in the application.
     * INPUTS      : 
     *               group_name IN VARCHAR2 -  group Simple name.
     *               group_guid IN VARCHAR2 -  GUID of the group.
     *               group_dn   IN VARCHAR2 -  DN of the group entry.
     * OUTPUT      : Returns a positive number if the group exists
     *               Returns zero if the group doesn't exists
     *
     ******************************************************
     */
    FUNCTION group_exists ( group_name IN VARCHAR2,
                            group_guid IN VARCHAR2,
                            group_dn   IN VARCHAR2)
    RETURN NUMBER;

    /**
     ******************************************************
     *
     * FUNCTION    : event_ntfy
     * DESCRIPTION : A callback function invoked by the Provisioning System
     *               to deliver change notification events for objects
     *               modeled in OID.
     *               Currently modify and delete change notification events
     *               are delivered for users and groups in OID.
     *
     *               While delivering events for an object(represented in OID),
     *               the related attributes are also sent along 
     *               with other details. 
     *               The attributes are delivered as a Collection(array)
     *               of attribute containers, which are in un-normalized form, 
     *               ie.,if an attribute has two values 
     *               then two rows would be sent in the collection
     *               viz.,: 
     *                     -----------------
     *                     ATTR : VALUE
     *                     -----------------
     *                     "cn",  "Harry"
     *                     "cn",  "Harry_US"
     *
     * INPUTS      : 
     *               event_type  IN VARCHAR2 - Type of event :
     *                                         Possible values:
     *                                           - 'USER_ADD'
     *                                           - 'USER_DELETE'
     *                                           - 'USER_MODIFY'
     *                                           - 'GROUP_ADD'
     *                                           - 'GROUP_DELETE'
     *                                           - 'GROUP_MODIFY'
     *               event_id    IN VARCHAR2 - Event id(ChangeLog Number.)
     *               event_src   IN VARCHAR2 - DN of the modifier responsible
     *                                         for this event 
     *               event_time  IN VARCHAR2 - Time when this event 
     *                                         occured.
     *               object_name IN VARCHAR2 - Simple name of the entry. 
     *               object_guid IN VARCHAR2 - GUID of the entry.
     *               object_dn   IN VARCHAR2 - DN of the entry.
     *               profile_id  IN VARCHAR2 - Name of the Provisioning Agent.
     *               attr_list   IN LDAP_ATTR_LIST_V3 - Collection of ldap
     *                                               attributes of the entry.
     *                                       
     * OUTPUT      : On success returns a positive number.
     *               On failure returns zero.
     *
     ******************************************************
     */

    FUNCTION event_ntfy ( event_type  IN VARCHAR2,
                          event_id    IN VARCHAR2,
                          event_src   IN VARCHAR2,
                          event_time  IN VARCHAR2,
                          object_name IN VARCHAR2,
                          object_guid IN VARCHAR2,
                          object_dn   IN VARCHAR2,
                          profile_id  IN VARCHAR2,
                          attr_list   IN LDAP_ATTR_LIST_V3 )
    RETURN NUMBER;


    /**
     ******************************************************
     *
     * PROCEDURE   : PutOIDEvents
     * DESCRIPTION : A callback procedure invoked by the DIP Server to sends 
     *               event to applications. It also expects an status event 
     *               object in response as an OUT parameter. 
     * INPUTS      : 
     *               event        IN  LDAP_EVENT_LIST_V3 - List of change events
     *
     * OUTPUT      : 
     *               event_status OUT LDAP_EVENT_STATUS_LIST_V3 - List of event 
     *                                                         status
     *
     ******************************************************
     */

    PROCEDURE PutOIDEvents (event         IN  LDAP_EVENT_LIST_V3,
                           event_status  OUT LDAP_EVENT_STATUS_LIST_V3);


END LDAP_NTFY;
/
SHOW ERRORS

CREATE OR REPLACE PACKAGE BODY LDAP_NTFY AS

    FUNCTION user_exists ( user_name IN VARCHAR2,
                           user_guid IN VARCHAR2,
                           user_dn   IN VARCHAR2)
        RETURN NUMBER
    IS
        c NUMBER;
    BEGIN
        SELECT COUNT(*) INTO c FROM odmzv_oidcredentialmanagerdn
            WHERE distinguishedname = user_guid;

        RETURN c;
    END;

    FUNCTION group_exists ( group_name IN VARCHAR2,
                           group_guid   IN VARCHAR2,
                           group_dn IN VARCHAR2)
        RETURN NUMBER
    IS
        c NUMBER;
    BEGIN
        SELECT COUNT(*) INTO c FROM odmzv_oidcredentialmanagerdn
            WHERE distinguishedname = group_guid;

        RETURN c;
    END;

    FUNCTION event_ntfy ( event_type  IN VARCHAR2,
                          event_id    IN VARCHAR2,
                          event_src   IN VARCHAR2,
                          event_time  IN VARCHAR2,
                          object_name IN VARCHAR2,
                          object_guid IN VARCHAR2,
                          object_dn   IN VARCHAR2,
                          profile_id  IN VARCHAR2,
                          attr_list   IN LDAP_ATTR_LIST_V3 )
        RETURN NUMBER
    IS
        attr_name_list &1..LDAP_ATTR_NAME_LIST_V3;
    BEGIN
        attr_name_list := &1..LDAP_ATTR_NAME_LIST_V3();
        
        IF attr_list IS NOT NULL
        THEN
            FOR i IN attr_list.FIRST .. attr_list.LAST
            LOOP
                attr_name_list.EXTEND;
                attr_name_list(i) := attr_list(i).attr_name;
            END LOOP;
        END IF;
    
        INSERT INTO odmz_oidcredentialmanagerevnt (
            event_id,
            object_guid,
            event_type,
            profile_id,
            attr_name_list
        ) VALUES (
            ldap_seq.NEXTVAL,
            object_guid,
            event_type,
            profile_id,
            attr_name_list
        );
        
        COMMIT;

        RETURN 1;
    END;

    PROCEDURE PutOIDEvents (event         IN  LDAP_EVENT_LIST_V3,
                            event_status  OUT LDAP_EVENT_STATUS_LIST_V3)
    IS
        attr_name_list &1..LDAP_ATTR_NAME_LIST_V3;
        eventId VARCHAR2(32);
    BEGIN

        IF event IS NOT NULL
        THEN 

            event_status := &1$id.LDAP_EVENT_STATUS_LIST_V3();

            FOR i IN event.FIRST .. event.LAST
            LOOP
                attr_name_list := &1..LDAP_ATTR_NAME_LIST_V3();

		IF event(i).attr_list IS NOT NULL
		THEN

                	FOR j IN event(i).attr_list.FIRST .. event(i).attr_list.LAST
                	LOOP
                    		attr_name_list.EXTEND;
                    		attr_name_list(j) := event(i).attr_list(j).attr_name;
                	END LOOP;
		END IF;

                INSERT INTO odmz_oidcredentialmanagerevnt (
                    event_id,
                    object_guid,
                    event_type,
                    profile_id, 
                    attr_name_list
                ) VALUES (
                    ldap_seq.NEXTVAL,
                    event(i).object_guid,
                    event(i).event_type,
                    event(i).profile_id,
                    attr_name_list
                );

                COMMIT;
                
                event_status.EXTEND;
                event_status(i) := &1$id.LDAP_EVENT_STATUS_V3(event(i).event_id, EVENT_IN_PROGRESS, EVENT_IN_PROGRESS, event(i).object_guid);

            END LOOP;
        END IF;
 
    END PutOIDEvents;

END LDAP_NTFY;
/
SHOW ERRORS


--
-- Reconect as DBA and revoke RESOURCE from <base>$id.
--

CONNECT &3/&4 AS sysdba;
REVOKE RESOURCE FROM &1$id;
 
EXIT;

-- EOF


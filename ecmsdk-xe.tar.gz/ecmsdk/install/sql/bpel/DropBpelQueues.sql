Rem Copyright (c) 2002, 2008, Oracle. All rights reserved.  
Rem
Rem  History:
Rem    2002-05-04  vvedula  Created.
Rem

whenever sqlerror continue;

set serveroutput on

rem ==========================================
rem Stop Queue ifs_bpel_in and ifs_bpel_out
rem ==========================================

DECLARE
BEGIN
    dbms_output.put_line ('Stopping  Queue ifs_bpel_in...');
    dbms_aqadm.stop_queue
    (
        queue_name => '&1..ifs_bpel_in',
        wait       => TRUE
    );
    dbms_output.put_line ('Stopped Queue ifs_bpel_in.');
END;
/

DECLARE
BEGIN
    dbms_output.put_line ('Stopping  Queue ifs_bpel_out...');
    dbms_aqadm.stop_queue
    (
        queue_name => '&1..ifs_bpel_out',
        wait       => TRUE
    );
    dbms_output.put_line ('Stopped Queue ifs_bpel_out.');
END;
/

DECLARE
BEGIN
    dbms_output.put_line ('Stopping  exception queue for ifs_bpel_in...');
    dbms_aqadm.stop_queue
    (
        queue_name => '&1..aq$_ifs_bpel_in_table_e',
        wait       => TRUE
    );
    dbms_output.put_line ('Stopped exception queue for ifs_bpel_in.');
END;
/

DECLARE
BEGIN
    dbms_output.put_line ('Stopping  exception queue for ifs_bpel_out...');
    dbms_aqadm.stop_queue
    (
        queue_name => '&1..aq$_ifs_bpel_out_table_e',
        wait       => TRUE
    );
    dbms_output.put_line ('Stopped exception queue for ifs_bpel_out.');
END;
/

rem ==========================================
rem Drop Queue ifs_bpel_in and ifs_bpel_out
rem ==========================================

DECLARE
BEGIN
    dbms_output.put_line ('Dropping  Queue ifs_bpel_in...');
    dbms_aqadm.drop_queue
    (
        queue_name => '&1..ifs_bpel_in'
    );
    dbms_output.put_line ('Dropped Queue ifs_bpel_in.');
END;
/

DECLARE
BEGIN
    dbms_output.put_line ('Dropping  Queue ifs_bpel_out...');
    dbms_aqadm.drop_queue
    (
        queue_name => '&1..ifs_bpel_out'
    );
    dbms_output.put_line ('Dropped Queue ifs_bpel_out.');
END;
/


rem ==========================================
rem Drop Input Queue Table
rem ==========================================

DECLARE
BEGIN
    dbms_output.put_line ('Dropping Queue Table ifs_bpel_in_table...');
    dbms_aqadm.drop_queue_table
    (
        queue_table => '&1..ifs_bpel_in_table',
        force => TRUE
    );
    dbms_output.put_line ('Dropped Queue Table ifs_bpel_in_table.');

END;
/

DECLARE
BEGIN
    dbms_output.put_line ('Dropping Queue Table ifs_bpel_out_table...');
    dbms_aqadm.drop_queue_table
    (
        queue_table => '&1..ifs_bpel_out_table',
        force => TRUE
    );
    dbms_output.put_line ('Dropped Queue Table ifs_bpel_out_table.');

END;
/
exit;


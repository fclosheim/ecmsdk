whenever sqlerror continue;

set serveroutput on;

declare
  privilege_not_granted exception;
  pragma exception_init(privilege_not_granted, -01927);
  not_subscribed exception;
  pragma exception_init(not_subscribed, -24035);
  subscriber sys.aq$_agent;
begin
  
  begin
    execute immediate 'revoke all on Ifs_Bpel_in_Table from &1';
    dbms_output.put_line('Revoked all  privilege from &1 on Ifs_Bpel_in_Table');
  exception 
    when privilege_not_granted then
      dbms_output.put_line('All  privilege not granted to &1 on Ifs_Bpel_in_Table');
  end;
  
  begin
    execute immediate 'revoke all  on Ifs_Bpel_out_Table from &1';
    dbms_output.put_line('Revoked All  privilege from &1 on Ifs_Bpel_out_Table');
  exception
    when privilege_not_granted then
      dbms_output.put_line('All  privilege not granted to &1 on Ifs_Bpel_out_Table');
  end;

  begin
    dbms_aqadm.revoke_queue_privilege(
      privilege => 'DEQUEUE',
      queue_name => 'IFS_BPEL_OUT',
      grantee => '&1');
    dbms_output.put_line ('Revoked dequeue privilege from &1 on IFS_BPEL_OUT');
  exception
    when privilege_not_granted then
      dbms_output.put_line('Dequeue privilege not granted to &1 on IFS_BPEL_OUT');
  end;

  begin  
    dbms_aqadm.revoke_queue_privilege(
      privilege => 'ENQUEUE',
      queue_name => 'IFS_BPEL_IN',
      grantee => '&1');
    dbms_output.put_line ('Revoked enqueue privilege from &1 on IFS_BPEL_IN');
  exception
    when privilege_not_granted then
      dbms_output.put_line('Enqueue privilege not granted to &1 on IFS_BPEL_IN');
  end;
 
  begin
    subscriber := sys.aq$_agent('wf', NULL, NULL);
    dbms_aqadm.remove_subscriber(
        queue_name => 'IFS_BPEL_OUT',
        subscriber => subscriber);
    dbms_output.put_line ('Removed subscriber wf from IFS_BPEL_OUT');
  exception
    when not_subscribed then
      dbms_output.put_line('wf not subscribed to IFS_BPEL_OUT');
  end;

end;
/

commit;
exit;


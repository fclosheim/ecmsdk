Rem Copyright (c) 2001, 2009, Oracle and/or its affiliates. 
Rem All rights reserved. 
Rem
Rem  NAME
Rem   SetBpelQueeuePrivileges.sql - Grant Queue Privileges to Workflow.
Rem
Rem  History:
Rem    28-03-2005 vvedula - created.

set serveroutput on;

grant execute on IfsQueueMessage to &1;
grant execute on IfsQueueMessageParameter    to &1;
grant execute on Parameters    to &1;
grant select, insert, update, delete on Ifs_Bpel_In_Table    to &1;
grant select, insert, update, delete on Ifs_Bpel_Out_Table    to &1;

begin
dbms_aqadm.grant_queue_privilege(
    privilege => 'DEQUEUE',
    queue_name => 'IFS_BPEL_OUT',
	grantee => '&1',
	grant_option => TRUE);
    dbms_output.put_line ('Granted dequeue privilege on IFS_BPEL_OUT to &1');
end;
/

begin
dbms_aqadm.grant_queue_privilege(
    privilege => 'ENQUEUE',
    queue_name => 'IFS_BPEL_IN',
	grantee => '&1',
	grant_option => TRUE);
    dbms_output.put_line ('Granted enqueue privilege on IFS_BPEL_IN to &1');
end;
/

declare
    subscriber sys.aq$_agent;
begin
    subscriber := sys.aq$_agent('wf', NULL, NULL);
    dbms_aqadm.add_subscriber(
        queue_name => 'IFS_BPEL_OUT',
        subscriber => subscriber);
    dbms_output.put_line ('Added subscriber wf to IFS_BPEL_OUT.');

end;
/

commit;
exit;


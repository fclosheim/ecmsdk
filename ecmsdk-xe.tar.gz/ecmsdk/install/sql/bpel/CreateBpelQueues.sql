Rem Copyright (c) 2001, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    CreateBpelQueues.sql - Create Queues for BPEL integration.
Rem
Rem  History:
Rem    28-03-2005 vvedula - created.
set serveroutput on;

whenever sqlerror exit sql.sqlcode

rem Create Queue table, Queues, Subscribers

rem ====================================================
rem Create a queue table  IFS_BPEL_IN_table and IFS_BPEL_OUT_table
rem ====================================================

DECLARE
    err_num NUMBER;
BEGIN
    dbms_output.put_line ('Creating Queue Table IFS_BPEL_IN_table...');

    dbms_aqadm.CREATE_queue_table(
        queue_table => 'IFS_BPEL_IN_table',
        multiple_consumers => TRUE,
        queue_payload_type => 'IfsQueueMessage',
        compatible => '9.0.0',
        comment => 'Creating input queue table');

    dbms_output.put_line ('Created Queue Table IFS_BPEL_IN_table.');

EXCEPTION
    when others then
        err_num := SQLCODE;
        if( err_num = -24001 ) then
    		dbms_output.put_line ('IFS_BPEL_IN_table already exists. Continue ...');
        else
            raise;
        end if;
END;
/

DECLARE
    err_num NUMBER;
BEGIN
    dbms_output.put_line ('Creating Queue Table IFS_BPEL_OUT_table...');

    dbms_aqadm.CREATE_queue_table(
        queue_table => 'IFS_BPEL_OUT_table',
        multiple_consumers => TRUE,
        queue_payload_type => 'IfsQueueMessage',
        compatible => '9.0.0',
        comment => 'Creating output queue table');

    dbms_output.put_line ('Created Queue Table IFS_BPEL_OUT_table.');
EXCEPTION
    when others then
        err_num := SQLCODE;
        if( err_num = -24001 ) then
    		dbms_output.put_line ('IFS_BPEL_OUT_table already exists. Continue ...');
        else
            raise;
        end if;
END;
/

rem ==========================================
rem Create queues IFS_BPEL_IN and IFS_BPEL_OUT
rem ==========================================

DECLARE
    err_num NUMBER;
BEGIN
    dbms_output.put_line ('Creating Queue IFS_BPEL_IN...');

    dbms_aqadm.CREATE_queue(
        queue_name => 'IFS_BPEL_IN',
        queue_table => 'IFS_BPEL_IN_table',
        comment => 'Demo Queue',
        retry_delay => 600);

    dbms_output.put_line ('Created Queue IFS_BPEL_IN.');
EXCEPTION
    when others then
        err_num := SQLCODE;
        if( err_num = -24006 ) then
    		dbms_output.put_line ('IFS_BPEL_IN queue already exists. Continue ...');
        else
            raise;
        end if;
END;
/

DECLARE
    err_num NUMBER;
BEGIN
    dbms_output.put_line ('Creating Queue IFS_BPEL_OUT...');

    dbms_aqadm.CREATE_queue(
        queue_name => 'IFS_BPEL_OUT',
        queue_table => 'IFS_BPEL_OUT_table',
        comment => 'Demo Queue',
        retry_delay => 600);

    dbms_output.put_line ('Created Queue IFS_BPEL_OUT.');
EXCEPTION
    when others then
        err_num := SQLCODE;
        if( err_num = -24006 ) then
    		dbms_output.put_line ('IFS_BPEL_OUT queue already exists. Continue ...');
        else
            raise;
        end if;
END;
/

rem ====================================
rem Start input queue IFS_BPEL_IN
rem ====================================

DECLARE
BEGIN
    dbms_output.put_line('starting queue IFS_BPEL_IN...');

    dbms_aqadm.start_queue(
        queue_name => 'IFS_BPEL_IN');

    dbms_output.put_line ('Started Queue IFS_BPEL_IN.');

    dbms_output.put_line('starting queue IFS_BPEL_OUT...');

    dbms_aqadm.start_queue(
        queue_name => 'IFS_BPEL_OUT');

    dbms_output.put_line ('Started Queue IFS_BPEL_OUT.');

    dbms_output.put_line('starting queue exception queue for IFS_BPEL_IN...');

    dbms_aqadm.start_queue(
        queue_name => 'aq$_IFS_BPEL_IN_table_e', enqueue => false);

    dbms_output.put_line ('Started exception Queue for IFS_BPEL_IN.');

    dbms_output.put_line('starting exception queue for IFS_BPEL_OUT...');

    dbms_aqadm.start_queue(
        queue_name => 'aq$_IFS_BPEL_OUT_table_e', enqueue => false);

    dbms_output.put_line ('Started exception Queue for IFS_BPEL_OUT.');

END;
/

rem ========================================
rem Create queue subscribers
rem ========================================

DECLARE
    subscriber sys.aq$_agent;
    err_num NUMBER;
BEGIN
    dbms_output.put_line('Adding subscriber ifs to IFS_BPEL_IN queue...');
    subscriber := sys.aq$_agent('ifs', NULL, NULL);
    dbms_aqadm.add_subscriber(
        queue_name => 'IFS_BPEL_IN',
        subscriber => subscriber);
    dbms_output.put_line ('Added subscriber ifs to IFS_BPEL_IN.');
EXCEPTION
    when others then
        err_num := SQLCODE;
        if( err_num = -24034 ) then
    		dbms_output.put_line ('Subscriber ifs already exists. Continue ...');
        else
            raise;
        end if;
END;
/

exit;



Rem Copyright (c) 2001, 2008, Oracle. All rights reserved.  
Rem
Rem     NAME
Rem             SyncContextIndex.sql
Rem             Request content indexing of documents in ctx_user_pending
Rem 
Rem             Shows logging RowID of each document after it is indexed.
Rem             See also ViewDocumentByRowID.sql 
Rem
Rem
Rem     History:
Rem             09-Jul-01 (awiersba)
Rem                     Modified descriptions
Rem                     Removed LOG_DIRECTORY information
Rem                     Corrected typo in file name
Rem             27-Jun-01 (awiersba)
Rem                     Created

whenever sqlerror exit sql.sqlcode

REM Run the following as Oracle 9iFS schema user (IFSSYS by default).
REM 
REM If you want to log which rowid from the ODMZ_CONTENT_ROUTER table 
REM has just been indexed, then uncomment the following lines.
REM By default, log file will be written to $ORACLE_HOME/ctx directory.

/*  exec ctx_output.start_log(Logfile => 'ifs_ctx.log'); */
/*  exec ctx_output.add_event(ctx_output.event_index_print_rowid); */ 

REM Check to see how many documents need to be indexed

select count(*) PENDING_DOCS_BEFORE from ctx_user_pending;

REM Create the index, and optionally log each document's rowid after it is indexed.

exec ctx_ddl.sync_index('IFS_TEXT'); 

REM Use ViewDocumentByRowID.sql to examine (in a separate SQLPLUS session), 
REM what documents have finished being indexed.

REM Check to see how many documents are still in Oracle Text queue. 
select count(*) PENDING_DOCS_AFTER from ctx_user_pending;

REM Uncomment following line if you are using logging.

/* exec ctx_output.end_log; */

exit


Rem Copyright (c) 2000, 2012, Oracle and/or its affiliates.
Rem All rights reserved. 
Rem
Rem  NAME
Rem    odmmain.sql - initial population of Document Management Schema
Rem
Rem History:
Rem     02-feb-98 (dlong)
Rem         Created.
Rem     06-feb-98 (lmatter)
Rem         Added media initialization
Rem     08-feb-98 (dlong)
Rem         Added Format class initialization
Rem     08-feb-98 (sperez)
Rem         Added ServerClassPath attr for 
Rem         ClassObject
Rem     08-feb-98 (sperez)
Rem         Changed JavaClassPath to BeanClassPath
Rem     10-feb-98 (dlong)
Rem         fixed several hardcoded inserts (last one: Format's
Rem         superclass should be 94.
Rem     14-feb-98 (dlong)
Rem         fix Media's superclass (should be SYSTEMOBJECT)
Rem         use 0 for "null" object id refs
Rem     14-feb-98 (dlong)
Rem         fix attribute names for ClassObject's attributes.
Rem     17-feb-98 (vpesati)
Rem         Add table for directory users.
Rem     20-feb-98 (vpesati)
Rem         Add tables for roles and orgs
Rem     20-feb-98 (dlong)
Rem         change so that all directory objects share same sequence
Rem     23-feb-98 (vpesati)
Rem         Remove redundant sequences for user, role, org
Rem     04-mar-98 (vpesati)
Rem         Consolidate bootstrapping
Rem     14-mar-98 (dlong)
Rem         remove extraneous sequences; add odm_acl_discoverers
Rem     24-mar-98 (dlong)
Rem         rename DM user to 'dmuser' (was 'dlong')
Rem     26-mar-98 (dlong)
Rem         rename acl_discoverers table to 'odmz_acl_discoverers'
Rem     03-apr-98 (dlong)
Rem         add viewname, tablename, and selector path to hardcoded
Rem         classobject inserts
Rem     05-may-98 (dlong)
Rem         add classobject.createacl and attribute.*
Rem         (* = is_settable, is_updateable, columnname
Rem         classdomain, valuedomain, valuedefault,
Rem         validatevaluedomain, refintegrity) 
Rem     26-may-98 (dpitfiel)
Rem         Corrected the BeanClassPath of Attribute.
Rem         Changed LIBRARYOBJECT and LIBRARYOBJECT_ARRAY data types
Rem         to the proper new data type.
Rem     11-jun-98 (lmatter)
Rem         Removed the LONG and LONGRAW media instances.  No longer used.
Rem     12-jun-98 (dpitfiel)
Rem         Split out preodmmain.sql to allow remote databases.
Rem     12-jun-98 (dpitfiel)
Rem         Changed column order in views to be consistent with
Rem         S_ClassObject-created views.
Rem     07-jul-98 (dpitfiel)
Rem         Added tables for array-type attribute values
Rem     09-jul-98 (dlong)
Rem         change admin to have qualified name
Rem     12-jul-98 (dlong)
Rem         add DOmap entry for the "world" group
Rem     28-jul-98 (hbutani)
Rem         made odmz_acl_discoverers table a CACHED.
Rem     29-sep-98 (dlong)
Rem         changed admin user to a fixed Id (96)
Rem     11-oct-98 (dlong)
Rem         add odmz_read_indication
Rem     20-oct-98 (vijain)
Rem         add odmz_auditrecords & odmz_auditsequence
Rem     29-oct-98 (dpitfiel)
Rem         Added odmz_referentialintegrity.
Rem     04-nov-98 (dpitfiel)
Rem         Changed RI constants.  Made REFERENTIALINTEGRITYRULE updateable.
Rem     15-nov-98 (dlong)
Rem         add policybundle to schemaobject
Rem     25-nov-98 (dlong)
Rem         remove audit table & sequence
Rem     14-dec-98 (jfroese)
Rem         changed boolean attrbutes to number(1)
Rem     15-dec-98 (jfroese)
Rem         changed integer attributes to number(10)
Rem     21-dec-98 (jfroese)
Rem         changed stringsizes 
Rem     12-jan-99 (dpitfiel)
Rem         Added odmz_event and odmz_event_seq.
Rem     25-jan-99 (jfroese)
Rem         added UNIQUENAME and additonal Insert statements
Rem     11-feb-99 (jfroese)
Rem         changed DatabaseObjectname size to 24
Rem     20-feb-99 (dlong)
Rem         made CLASSDOMAIN attribute updateable
Rem     24-feb-99 (jfroese)
Rem         added ACTIVE attribute to SchemaObject
Rem     18-mar-99 (jfroese)
Rem         changed IS_ABSTRACT,IS_PARTITIONED,IS_UNIQUE,IS_FINAL
Rem     28-apr-99 (dpitfiel)
Rem         General cleanup.  See SchemaCleanup.txt.
Rem     28-apr-99 (dpitfiel)
Rem         Renamed VALUEDOMAININVALIDATED to VALUEDOMAINVALIDATED.
Rem     30-apr-99 (jfroese)
Rem         Changed REFERENTIALINTEGRITYRULE to NOT NULL
Rem     02-may-99 (dpifiel)
Rem         Changed VARCHAR2(1000) to VARCHAR2(700).
Rem     04-may-99 (dlong)
Rem         add PropertyBundle attribute to SchemaObject
Rem     15-may-99 (dpitfiel)
Rem         Removed ATTRIBUTE.DATABASEINDEXNAME.
Rem     28-may-99 (sperez)
Rem         Changed ATTRIBUTE.CLASS to be indexed. (#883571)
Rem         Added creating indexes for classobject (#883582)
Rem     29-may-99 (dlong)
Rem         Change MV date table to use Number(20)
Rem     30-may-99 (dlong)
Rem         add ACL Proxy table
Rem     24-oct-99 (dlong)
Rem         add Sessions table
Rem     31-oct-99 (dlong)
Rem         make classobject.uniquename index unique; 
Rem         same for classobject.databaseobjectname.
Rem     07-nov-99 (dlong)
Rem         add seviceid to Sessions table (needed for auto-cleanup)
Rem         add sevice table
Rem     30-nov-99 (dpitfiel)
Rem         Changed layout of odmz_directoryuser.
Rem     05-dec-99 (dpitfiel)
Rem         Changed layout of odmz_event.
Rem     07-dec-99 (dpitfiel)
Rem         Deleted odmz_services.
Rem         Indexed odmz_sessions by serviceid.
Rem     08-dec-99 (dpitfiel)
Rem         Renamed odmz_sessions to odmz_session.
Rem         Renamed odmz_acl_discoverers to odmz_acl_discoverer.
Rem     12-dec-99 (dpitfiel)
Rem         Cleaned up index naming.
Rem     26-jan-00 (dpitfiel)
Rem         Added odmz_tokencredential.
Rem     26-jan-00 (dpitfiel)
Rem         Reduced odmz_tokencredential.token to 700 bytes.
Rem     03-feb-00 (dpitfiel)
Rem         Added odmz_repositoryparameters.
Rem     15-feb-00 (dlong)
Rem         Added Description attribute on Attribute.
Rem     16-feb-00 (dlong)
Rem         do not ref Tie classes for Attribute or ClassObject
Rem     01-jun-00 (vdevadha)
Rem         Do not need odmz_directoryuser table anymore.   
Rem     07-mar-01 (lmatter)
Rem         added creation of ODMZ_CONTEXT_ROUTER.
Rem     16-apr-01 (dpitfiel)
Rem         Added 2 indexes to odmz_tokencredential.
Rem     10-oct-01 (dlong)
Rem         Added audit tables, sequence and views
Rem     13-dec-01 (dlong)
Rem         Added audit tables for array attributes
Rem     27-mar-02 (dlong)
Rem         Added ACL index tables for groupindex and
Rem         other of its inner subservices
Rem     14-may-02 (kgillett)
Rem         Added temp bfile table for transaction semantics 
Rem     10-oct-02 (dpitfiel)
Rem         Added KO.PolicyList and CO.ClassPolicyList attributes.
Rem     25-jul-03 (dlong)
Rem         renamed KO.PolicyList to KO.PolicyLists; removed ApplicationPolicyList
Rem     11-aug-04 Itseto)
Rem         Modify odmz_systemauditentrytable.
Rem     26-jan-05 (vdevadha)
Rem         Modify odmz_aclproxy.
Rem     03-apr-05 (dlong)
Rem         Added odmz_repositoryparameter BFILE_SEMAPHORE
Rem     29-dec-05 (dlong)
Rem         remove odma tables (old object AE)
Rem     21-jan-06 (dlong)
Rem         remove old audit tables/indexes; add new ones (stubbed)
Rem     01-feb-06 (dlong)
Rem         final verson of the new auditing aux. tables
Rem     04-feb-06 (dlong)
Rem         use separate table for raw audit events
Rem     05-feb-06 (dlong)
Rem         add aux. numbers to audit tables; make odmz_auditoptype cached.
Rem     10-feb-06 (dlong)
Rem         add sessionuserid to audit event tables, so that creator can
Rem         always be the "regular" user
Rem     15-feb-06 (dlong)
Rem         rename audit tables to use odmza_ prefix
Rem     08-mar-06 (dlong)
Rem         add aux. class id columns to the audit event tables.
Rem     12-mar-06 (dlong)
Rem         add object certificate table.
Rem     09-sep-07 (dlong)
Rem         add inline string table.
Rem     24-sep-07 (dlong)
Rem         add custom audit event tables; add column to odmza_auditoptype.
Rem     04-oct-07 (dlong)
Rem         add audit target class mappings for Relation.
Rem     24-oct-07 (dlong)
Rem         add odmzav_auditevent view.
Rem     21-nov-07 (dlong)
Rem         add optypekey to odmzav_auditevent view.
Rem     15-jan-08 (dpitfiel)
Rem         Added INDEXABLECONTENT to ODMZ_CONTEXT_ROUTER.
Rem     27-jan-08 (dpitfiel)
Rem         Removed repository parameter BFILE_SEMAPHORE.
Rem         Removed table odmz_temp_bfile.
Rem     20-feb-08 (dpitfiel)
Rem         Added indexingstate to odmz_context_router.
Rem     05-sep-08 (dpitfiel)
Rem         Renamed CONTENTPROCEDURE to CONTENTINDEX in odmz_context_router.
Rem     11-dec-08 (dlong)
Rem         add SYSTEM audit traget type mapping.
Rem     08-nov-11 (dlong)
Rem         map AUDITSPECIFICATION audit events to SYSTEM
Rem     17-dec-11 (dlong)
Rem         make raw audit event table a cached table
Rem     09-jan-12 (dlong)
Rem         split out auditing creation to odmaudit.sql
Rem     15-apr-15 (fcloshei)
Rem         removed create table odmz_repositoryparameter
Rem         moved to InitializeRepositoryParameters.sql


whenever sqlerror exit sql.sqlcode

Prompt create SchemaObject tables
CREATE TABLE odm_schemaobject
(
          id    NUMBER(20)          PRIMARY KEY
        , classid NUMBER(20)            NOT NULL
        , name VARCHAR2(700)            NOT NULL
        , policybundle NUMBER(20)
        , active NUMBER(1)          NOT NULL
        , propertybundle NUMBER(20)
        , policylists NUMBER(20)
);

create view odmv_schemaobject as select * from odm_schemaobject;

Prompt create ClassObject tables
CREATE TABLE odm_classobject
(
          id    NUMBER(20)              PRIMARY KEY
        , superclass NUMBER(20)
        , description VARCHAR2(2000)
        , serverclasspath VARCHAR2(700)
        , beanclasspath VARCHAR2(700)
        , selectorclasspath VARCHAR2(700)
        , databaseobjectname VARCHAR2(24)   NOT NULL
        , classacl NUMBER(20)
        , classpolicylist NUMBER(20)
        , abstract NUMBER(1)            NOT NULL
        , final NUMBER(1)           NOT NULL
        , partitioned NUMBER(1)         NOT NULL
        , uniquename VARCHAR2(700)      NOT NULL
);


create view odmv_classobject as select 
     x.*
    , co.superclass 
    , co.description 
    , co.serverclasspath 
    , co.beanclasspath 
    , co.selectorclasspath 
    , co.databaseobjectname
    , co.classacl 
    , co.classpolicylist
    , co.abstract 
    , co.final
    , co.partitioned
    , co.uniquename from
    odm_classobject co, odmv_schemaobject x 
    where co.id = x.id;

Prompt create Attribute tables
CREATE TABLE odm_attribute
(
          id    NUMBER(20)              PRIMARY KEY
        , class NUMBER(20)          NOT NULL
        , datatype NUMBER(10)           NOT NULL            
        , datalength NUMBER(10)         NOT NULL
        , datascale NUMBER(10)          NOT NULL
        , is_unique NUMBER(1)           NOT NULL
        , required NUMBER(1)            NOT NULL
        , indexed NUMBER(1)         NOT NULL
        , settable NUMBER(1)            NOT NULL
        , updateable NUMBER(1)          NOT NULL
        , databaseobjectname VARCHAR2(24)   NOT NULL
        , classdomain NUMBER(20)
        , valuedomain NUMBER(20)
        , valuedefault NUMBER(20)
        , valuedomainvalidated NUMBER(1)    NOT NULL
        , referentialintegrityrule NUMBER(10)   NOT NULL
        , description VARCHAR2(2000)
);

CREATE INDEX odmi_117_uni ON odm_attribute
(
         class
);

CREATE UNIQUE INDEX odmi_111_uni ON odm_classobject
(
         databaseobjectname
);

CREATE UNIQUE INDEX odmi_133_uni ON odm_classobject
(
         uniquename
);
create view odmv_attribute as select 
     x.*
    , ab.class 
    , ab.datatype 
    , ab.datalength 
    , ab.datascale 
    , ab.is_unique
    , ab.required 
    , ab.indexed 
    , ab.settable 
    , ab.updateable 
    , ab.databaseobjectname 
    , ab.classdomain 
    , ab.valuedomain 
    , ab.valuedefault 
    , ab.valuedomainvalidated 
    , ab.referentialintegrityrule
    , ab.description from
    odm_attribute ab, odmv_schemaobject x 
    where ab.id = x.id;

Prompt create array-type AttributeValue tables
CREATE TABLE odm_avintegerarray
(
          objectid  NUMBER(20)
        , attributeid NUMBER(20)
        , sequence NUMBER(20)
        , value NUMBER(10)
        , PRIMARY KEY (objectid, attributeid, sequence)
);

CREATE TABLE odm_avlongarray
(
          objectid  NUMBER(20)
        , attributeid NUMBER(20)
        , sequence NUMBER(20)
        , value NUMBER(20)
        , PRIMARY KEY (objectid, attributeid, sequence)
);

CREATE TABLE odm_avdoublearray
(
          objectid  NUMBER(20)
        , attributeid NUMBER(20)
        , sequence NUMBER(20)
        , value FLOAT(126)
        , PRIMARY KEY (objectid, attributeid, sequence)
);

CREATE TABLE odm_avstringarray
(
          objectid  NUMBER(20)
        , attributeid NUMBER(20)
        , sequence NUMBER(20)
        , value VARCHAR2(1000)
        , PRIMARY KEY (objectid, attributeid, sequence)
);

CREATE TABLE odm_avdatearray
(
          objectid  NUMBER(20)
        , attributeid NUMBER(20)
        , sequence NUMBER(20)
        , value NUMBER(20)
        , PRIMARY KEY (objectid, attributeid, sequence)
);

CREATE TABLE odm_avbooleanarray
(
          objectid  NUMBER(20)
        , attributeid NUMBER(20)
        , sequence NUMBER(20)
        , value NUMBER(1)
        , PRIMARY KEY (objectid, attributeid, sequence)
);

CREATE TABLE odm_avschemaobjectarray
(
          objectid  NUMBER(20)
        , attributeid NUMBER(20)
        , sequence NUMBER(20)
        , value NUMBER(20)
        , PRIMARY KEY (objectid, attributeid, sequence)
);

CREATE TABLE odm_avsystemobjectarray
(
          objectid  NUMBER(20)
        , attributeid NUMBER(20)
        , sequence NUMBER(20)
        , value NUMBER(20)
        , PRIMARY KEY (objectid, attributeid, sequence)
);

CREATE TABLE odm_avpublicobjectarray
(
          objectid  NUMBER(20)
        , attributeid NUMBER(20)
        , sequence NUMBER(20)
        , value NUMBER(20)
        , PRIMARY KEY (objectid, attributeid, sequence)
);

CREATE TABLE odm_avdirectoryobjectarray
(
          objectid  NUMBER(20)
        , attributeid NUMBER(20)
        , sequence NUMBER(20)
        , value NUMBER(20)
        , PRIMARY KEY (objectid, attributeid, sequence)
);

CREATE INDEX odmzi_avpublicobjectarray ON odm_avpublicobjectarray
(
         attributeid, value
);

CREATE INDEX odmzi_avdirectoryobjectarray ON odm_avdirectoryobjectarray
(
         attributeid, value
);

CREATE INDEX odmzi_avsystemobjectarray ON odm_avsystemobjectarray
(
         attributeid, value
);

CREATE INDEX odmzi_avschemaobjectarray ON odm_avschemaobjectarray
(
         attributeid, value
);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle) 
    values (91, 90, 'SCHEMAOBJECT', 0, 0, 1, 0);
INSERT into odm_classobject 
    (id, superclass, uniquename, description, serverclasspath, beanclasspath, 
    selectorclasspath, databaseobjectname,
    classacl, classpolicylist, abstract, final, partitioned) 
    values (91, 0, 'SCHEMAOBJECT',
    'Schema Objects', 'oracle.ifs.server.S_TieSchemaObject',
    'oracle.ifs.beans.TieSchemaObject', 
    'oracle.ifs.server.S_SchemaObjectSelector', 
    'schemaobject',
    0, 0, 1, 0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (90, 90, 'CLASSOBJECT', 0, 0, 1, 0);
INSERT into odm_classobject 
    (id, superclass, uniquename, description, serverclasspath, beanclasspath, 
    selectorclasspath, databaseobjectname,
    classacl, classpolicylist, abstract, final, partitioned) 
    values (90, 91, 'CLASSOBJECT',
    'Class Objects', 'oracle.ifs.server.S_ClassObject',
    'oracle.ifs.beans.ClassObject', 
    'oracle.ifs.server.S_ClassObjectSelector', 
    'classobject', 
    0, 0, 0, 1, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (92, 90, 'ATTRIBUTE', 0, 0, 1, 0);
INSERT into odm_classobject 
    (id, superclass, uniquename, description, serverclasspath, beanclasspath, 
    selectorclasspath, databaseobjectname, 
    classacl, classpolicylist, abstract, final, partitioned) 
    values (92, 91, 'ATTRIBUTE',
    'Attribute Objects', 'oracle.ifs.server.S_Attribute',
    'oracle.ifs.beans.Attribute', 
    'oracle.ifs.server.S_AttributeSelector', 
    'attribute',
    0, 0, 0, 1, 0);
    
INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'NAME', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule) 
    values (odm_id_seq.currval, 91, 2, 700, 0,  
        0, 1, 0, 1, 0,
        'NAME', 'The name of this SchemaObject.', 
        0, 0, 0,
        0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'POLICYBUNDLE', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description,
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule) 
    values (odm_id_seq.currval, 91, 11, 1, 0,  
        0, 0, 0, 1, 1,
        'POLICYBUNDLE', 'The PolicyPropertyBundle applied to this SchemaObject to define the Policies of the SchemaObject.',
        0, 0, 0,
        0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'ACTIVE', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule) 
    values (odm_id_seq.currval, 91, 5, 1, 0,  
        0, 1, 0, 1, 1,
        'ACTIVE', 'An indicator of whether this SchemaObject is still used.  Inactive SchemaObjects are not included in Collections.',
        0, 0, 0,
        0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'PROPERTYBUNDLE', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule) 
    values (odm_id_seq.currval, 91, 11, 1, 0,  
        0, 0, 0, 1, 1,
        'PROPERTYBUNDLE', 'The PropertyBundle applied to this SchemaObject which contains a set of name/value pairs.',
        0, 0, 0,
        0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'POLICYLISTS', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description,
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule) 
    values (odm_id_seq.currval, 91, 24, 1, 0,  
        0, 0, 0, 1, 1,
        'POLICYLISTS', 'The set of Policies explicitly applied to this object.',
        0, 0, 0,
        0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'SUPERCLASS', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule)
    values (odm_id_seq.currval, 90, 9, 1, 0,  
        0, 0, 0, 1, 0,
        'SUPERCLASS', 'The ClassObject that is the superclass of this ClassObject.',
        0, 0, 0,
        0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'DESCRIPTION', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule)
    values (odm_id_seq.currval, 90, 2, 2000, 0,  
        0, 0, 0, 1, 1,
        'DESCRIPTION', 'A textual description of this ClassObject.',
        0, 0, 0,
        0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'SERVERCLASSPATH', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule)
    values (odm_id_seq.currval, 90, 2, 700, 0,  
        0, 0, 0, 1, 1,
        'SERVERCLASSPATH', 'The fully-qualified classname of the Server Java class used to represent instances of this ClassObject in the repository service.',
        0, 0, 0,
        0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'BEANCLASSPATH', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule) 
    values (odm_id_seq.currval, 90, 2, 700, 0,  
        0, 0, 0, 1, 1,
        'BEANCLASSPATH', 'The fully-qualified classname of the Beans Java class used to represent instances of this ClassObject in the repository SDK.',
        0, 0, 0,
        0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'SELECTORCLASSPATH', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule)
    values (odm_id_seq.currval, 90, 2, 700, 0,  
        0, 0, 0, 1, 1,
        'SELECTORCLASSPATH', 'The fully-qualified classname of the Selector Java class used to fetch data from the database for instances of this ClassObject.',
        0, 0, 0,
        0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'DATABASEOBJECTNAME', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule)
    values (odm_id_seq.currval, 90, 2, 24, 0,  
        1, 1, 0, 1, 0,
        'DATABASEOBJECTNAME', 'The base name for database objects used to store data for instances of this ClassObject.',
        0, 0, 0,
        0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'CLASSACL', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule)
    values (odm_id_seq.currval, 90, 11, 1, 0,  
        0, 0, 0, 1, 1,
        'CLASSACL', 'The ClassAccessControlList that determines which users and/or groups can create instances of this ClassObject.  If a ClassACL is not specified, then any user can create an instance of the ClassObject (unless it is an abstract class).',
        0, 0, 0,
        0, 1);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'ABSTRACT', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule)
    values (odm_id_seq.currval, 90, 5, 1, 0,  
        0, 1, 0, 1, 0,
        'ABSTRACT', 'An indicator of whether this ClassObject is abstract.  Abstract ClassObjects cannot be instantiated.',
        0, 0, 0,
        0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'FINAL', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule)
    values (odm_id_seq.currval, 90, 5, 1, 0,  
        0, 1, 0, 1, 0,
        'FINAL', 'An indicator of whether this ClassObject is final.  Final ClassObjects cannot be subclassed.',
        0, 0, 0,
        0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'PARTITIONED', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule)
    values (odm_id_seq.currval, 90, 5, 1, 0,  
        0, 1, 0, 1, 0,
        'PARTITIONED', 'An indicator of whether the database table that stores data for instances of this ClassObject is partitioned.  Currently only PublicObject database tables are partitioned.',
        0, 0, 0,
        0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
        values (odm_id_seq.nextval, 92, 'UNIQUENAME', 0, 0, 1, 0);
INSERT into odm_attribute
        (id, class, datatype, datalength, datascale,
                is_unique, required, indexed, settable, updateable,
                databaseobjectname, description, 
                classdomain, valuedomain, valuedefault,
                valuedomainvalidated, referentialintegrityrule)
        values (odm_id_seq.currval, 90, 2, 700, 0,
                1, 1, 0, 0, 0,
                'UNIQUENAME', 'A system-set attribute used to ensure each ClassObject has a unique Name.',
                0, 0, 0,
                0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'CLASSPOLICYLIST', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description,
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule) 
    values (odm_id_seq.currval, 90, 10, 1, 0,  
        0, 0, 0, 1, 1,
        'CLASSPOLICYLIST', 'The set of Policies implicitly applied to all instances of this class',
        0, 0, 0,
        0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'CLASS', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule)
    values (odm_id_seq.currval, 92, 9, 1, 0,  
        0, 1, 1, 0, 0,
        'CLASS', 'The Referencing ClassObject for this Attribute',
        0, 0, 0,
        0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'DATATYPE', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule)
    values (odm_id_seq.currval, 92, 4, 1, 0,  
        0, 1, 0, 1, 0,
        'DATATYPE', 'The datatype of this Attribute- either scalar or array of integer, long, double, string, boolean, DirectoryObject, PublicObject, SchemaObject, SystemObject.',
        0, 0, 0,
        0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'DATALENGTH', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule)
    values (odm_id_seq.currval, 92, 4, 1, 0,  
        0, 1, 0, 1, 0,
        'DATALENGTH', 'The maximum size of this Attribute.  For String attributes, this is the maximum string length in bytes.  The Datalength attribute is ignored for non-String Attributes.',
        0, 0, 0,
        0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'DATASCALE', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule)
    values (odm_id_seq.currval, 92, 4, 1, 0,  
        0, 1, 0, 1, 0,
        'DATASCALE', 'The Datascale attribute is reserved for future use.',
        0, 0, 0,
        0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'UNIQUE', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule)
    values (odm_id_seq.currval, 92, 5, 1, 0,  
        0, 1, 0, 1, 0,
        'IS_UNIQUE', 'An indicator of whether each instance of the ClassObject must have a unique value for this Attribute (if not null).',
        0, 0, 0,
        0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'REQUIRED', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule)
    values (odm_id_seq.currval, 92, 5, 1, 0,  
        0, 1, 0, 1, 0,
        'REQUIRED', 'An indicator of whether each instance of the ClassObject must have a value for this Attribute.',
        0, 0, 0,
        0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'INDEXED', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule)
    values (odm_id_seq.currval, 92, 5, 1, 0,  
        0, 1, 0, 1, 0,
        'INDEXED', 'An indicator of whether the database table that stores data for instances of the ClassObject has an index on this Attribute.',
        0, 0, 0,
        0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'SETTABLE', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule)
    values (odm_id_seq.currval, 92, 5, 1, 0,  
        0, 1, 0, 1, 0,
        'SETTABLE', 'An indicator of whether this Attribute can be set using the repository SDK when creating new instances of the ClassObject.  Non-settable Attributes can only be set via server extensibility code.',
        0, 0, 0,
        0, 0);
        
INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'UPDATEABLE', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule)
    values (odm_id_seq.currval, 92, 5, 1, 0,  
        0, 1, 0, 1, 0,
        'UPDATEABLE', 'An indicator of whether this Attribute can be updated using the repository SDK for existing instances of the ClassObject.  The values of non-updateable Attributes can only be changed by server extensibility code.',
        0, 0, 0,
        0, 0);
    
INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'DATABASEOBJECTNAME', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule)
    values (odm_id_seq.currval, 92, 2, 24, 0,  
        0, 1, 0, 1, 0,
        'DATABASEOBJECTNAME', 'The name of the column for this Attribute in the database table for the ClassObject.',
        0, 0, 0,
        0, 0);
    
INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'CLASSDOMAIN', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule)
    values (odm_id_seq.currval, 92, 9, 1, 0,  
        0, 0, 0, 1, 1,
        'CLASSDOMAIN', 'The ClassDomain applied to this object-type Attribute to restrict the objects to which it refers by their ClassObject.  ClassDomain must be null for non object-type Attributes.',
        0, 0, 0,
        0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'VALUEDOMAIN', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule)
    values (odm_id_seq.currval, 92, 9, 1, 0,  
        0, 0, 0, 1, 1,
        'VALUEDOMAIN', 'The ValueDomain applied to this Attribute to restrict its values to a list of pre-specified allowed values for instances of the ClassObject.',
        0, 0, 0,
        0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'VALUEDEFAULT', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule)
    values (odm_id_seq.currval, 92, 9, 1, 0,  
        0, 0, 0, 1, 1,
        'VALUEDEFAULT', 'The default value of this Attribute in new instances of the ClassObject.',
        0, 0, 0,
        0, 0);
        
INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'VALUEDOMAINVALIDATED', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule)
    values (odm_id_seq.currval, 92, 5, 1, 0,  
        0, 1, 0, 1, 1,
        'VALUEDOMAINVALIDATED', 'An indicator of whether the ValueDomain is enforced or merely a guideline.',
        0, 0, 0,
        0, 0);

INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'REFERENTIALINTEGRITYRULE', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule)
    values (odm_id_seq.currval, 92, 4, 1, 0,  
        0, 1, 0, 1, 1,
        'REFERENTIALINTEGRITYRULE', 'The referential integrity behavior (clear, restrict) of this Attribute.',
        0, 0, 0,
        0, 0);
    
INSERT into odm_schemaobject (id, classid, name, policylists, policybundle, active, propertybundle)
    values (odm_id_seq.nextval, 92, 'DESCRIPTION', 0, 0, 1, 0);
INSERT into odm_attribute 
    (id, class, datatype, datalength, datascale, 
        is_unique, required, indexed, settable, updateable,
        databaseobjectname, description, 
        classdomain, valuedomain, valuedefault, 
        valuedomainvalidated, referentialintegrityrule)
    values (odm_id_seq.currval, 92, 2, 2000, 0,  
        0, 0, 0, 1, 1,
        'DESCRIPTION', 'The Description of this Attribute',
        0, 0, 0,
        0, 0);

Prompt create ACL Discoverer table and insert null ACL rows
CREATE TABLE odmz_acl_discoverer
(
    aclid NUMBER(20)
    , userid NUMBER(20)
    , PRIMARY KEY (aclid, userid)
) CACHE;

INSERT into odmz_acl_discoverer (aclid, userid)
    values (0, 1);

CREATE INDEX odmzi_acl_discoverer_userid ON odmz_acl_discoverer
(
    userid
);

Prompt create ACL non-conforming table
CREATE TABLE odmz_nonconformingacl
(
        aclid NUMBER(20)
        , groupid NUMBER(20)
) CACHE;

CREATE INDEX odmzi_nonconformingacl_acl ON odmz_nonconformingacl
(
         aclid
);

CREATE INDEX odmzi_nonconformingacl_group ON odmz_nonconformingacl
(
         groupid
);

Prompt create group index tables
Prompt Creating table odmz_groupindex
CREATE TABLE odmz_groupindex
(
    leftid NUMBER(20)
    , rightid NUMBER(20)
    , leftsource NUMBER(20)
) CACHE;

Prompt Creating index odmi_groupindex_left
CREATE INDEX odmi_groupindex_all ON odmz_groupindex (leftid, rightid, leftsource); 

Prompt Creating index odmi_groupindex_right
CREATE INDEX odmi_groupindex_right ON odmz_groupindex (rightid);

Prompt creating table odmz_groupindex_parameters
CREATE TABLE odmz_groupindex_parameters
(
    key NUMBER(20) PRIMARY KEY
    , value NUMBER(20)
) CACHE;

Prompt add lock row to odmz_groupindex_parameters
INSERT INTO odmz_groupindex_parameters
    (key, value) VALUES (1, 0);

Prompt create session table
CREATE TABLE odmz_session
(
        sessionid NUMBER(20) PRIMARY KEY
        , userid  NUMBER(20)
        , serviceid  NUMBER(20)
) CACHE;

CREATE INDEX odmzi_session_serviceid ON odmz_session
(
    serviceid
);


CREATE TABLE odmz_read_indication
(
    userid NUMBER(20),
    contentid NUMBER(20)
);

CREATE INDEX odmzi_read_indication_userid ON odmz_read_indication
(
         userid
);

Prompt create Class Hierarchy table
CREATE TABLE odmz_class_hierarchy
(
    classid NUMBER(20),
    subclassid NUMBER(20)
) CACHE;

Prompt create Convenience view of Class Hierarchy Table
create view odmzv_class_hierarchy as select
    co1.name supername, co2.name subname, o.classid, o.subclassid
    from odmv_classobject co1, odmv_classobject co2, odmz_class_hierarchy o
    where co1.id=o.classid and co2.id=o.subclassid;

insert into odmz_class_hierarchy values(91, 91);
insert into odmz_class_hierarchy values(91, 90);
insert into odmz_class_hierarchy values(91, 92);
insert into odmz_class_hierarchy values(90, 90);
insert into odmz_class_hierarchy values(92, 92);

Prompt create referential integrity table
CREATE TABLE odmz_referentialintegrity
(
          referencer NUMBER(20)
        , referencerattribute NUMBER(20)
        , referencee NUMBER(20)
);

CREATE INDEX odmzi_referentialintegrity_rr ON odmz_referentialintegrity
(
          referencer
        , referencerattribute
);

CREATE INDEX odmzi_referentialintegrity_re ON odmz_referentialintegrity
(
          referencee
);

Rem We could omit this index to improve insert and update performance.
Rem However this would result in full-table scans on Attribute.free
Rem and Attribute.setAttribute("REFERENTIALINTEGRITYRULE, ...).
CREATE INDEX odmzi_referentialintegrity_ra ON odmz_referentialintegrity
(
          referencerattribute
);

Prompt create ACL Proxy table
CREATE TABLE odmz_aclproxy
(
          securingpo NUMBER(20)
        , securedpo NUMBER(20)
        , securedpoclassid NUMBER(20)
        , primary key(securingpo, securedpo)
)
organization index;

Prompt create deferred ACL resolution table
CREATE TABLE odmz_acl_resolution
(
    id NUMBER(20) PRIMARY KEY
    , operationtype NUMBER(9)
    , leftid NUMBER(20)
    , rightid NUMBER(20)
);
                
Prompt create event table
CREATE TABLE odmz_event
(
          eventid NUMBER(20) PRIMARY KEY
        , id NUMBER(20)
        , classid NUMBER(20)
        , sessionid NUMBER(20)
        , serviceid NUMBER(20)
        , eventtype NUMBER(10)
        , eventsubtype NUMBER(10)
        , eventstatus NUMBER(10)
        , longpayload NUMBER(20)
) CACHE;

Prompt create token credential table
CREATE TABLE odmz_tokencredential
(
          token VARCHAR2(700) PRIMARY KEY
        , name VARCHAR2(700)
        , remainingauthenticationcount NUMBER(10)
        , timeout DATE
        , tokencredential BLOB 
)
LOB (tokencredential) store as (enable storage in row);

CREATE INDEX odmzi_tokencredential_rac ON odmz_tokencredential
(
        remainingauthenticationcount
);

CREATE INDEX odmzi_tokencredential_to ON odmz_tokencredential
(
        timeout
);

INSERT INTO odmz_repositoryparameter
(
    name,
    value
) VALUES (
    'ACLRESOLUTIONMODE',
    'SYNCHRONOUS'
);

Prompt create context routing table
CREATE TABLE odmz_context_router 
(
    id                  NUMBER(20) PRIMARY KEY,
    contentindex        VARCHAR2(40),
    characterset        VARCHAR2(40),
    language            VARCHAR2(40),
    format              VARCHAR2(40),
    indexingstate       NUMBER(10),
    indexablecontent    BLOB
);

CREATE INDEX odmzi_context_router ON odmz_context_router
(
  indexingstate
);

CREATE TABLE odmz_last_access_date
(
    id                  NUMBER(20) PRIMARY KEY,
    lastaccessdate      NUMBER(20)
);

CREATE INDEX odmzi_last_access_date ON odmz_last_access_date
(
    lastaccessdate,
    id
);

commit;
exit;


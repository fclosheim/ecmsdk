Rem Copyright (c) 2005, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    ManageSchemaVersionDuringUpgrade.sql - This script is run at the end of
Rem    Files to ECM upgrade to set up the schema version correctly. 
Rem
Rem  History:
Rem    30-aug-05 (vdevadha)
Rem        Created.

whenever sqlerror exit sql.sqlcode

delete from odmz_repositoryparameter where name = 'SCHEMAVERSION';

update odmz_repositoryparameter set name = 'SCHEMAVERSION' where name = 'REALSCHEMAVERSION';

exit;



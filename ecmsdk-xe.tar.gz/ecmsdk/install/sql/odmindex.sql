Rem Copyright (c) 2001, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    odmindex.sql - create custom indexes in Internet Documnet Schema
Rem
Rem	History:
Rem		18-jun-99 (dlong)
Rem			Created.
Rem		29-sep-99 (dlong)
Rem			change name so that SQLException can be parsed into a sensible
Rem			error message.  Warning!! the numerical value used below (219)
Rem			is subject to change as new classes get added; the value
Rem			is that of the RIGHTOBJECTNAME attribute.
Rem		17-oct-99 (dlong)
Rem			bump index sequence to 218 for index on odm_folderpathrelationship
Rem		15-feb-00 (dlong)
Rem			bump index sequence to 219 for index on odm_folderpathrelationship
Rem		06-sep-00 (dpitfiel)
Rem			back to 217
Rem		02-feb-01 (lmatter)
Rem			up to 218
Rem		07-may-01 (dpitfiel)
Rem			Fixed for all time; now done by EXECUTE IMMEDIATE.
Rem		23-dec-02 (vdevadha)
Rem			added forward, reverse indices on odm_publicobject.name .	
Rem		03-feb-03 (vdevadha)
Rem			removed name index creation at schema creation time.
Rem		30-dec-05 (dlong)
Rem			add creation of odmz_publicobject view
Rem		03-jun-07 (dlong)
Rem			add creation of index on document of the composite
Rem         (retentionpolicyid, retentionstate, baseretentiondate)
Rem		26-jun-07 (dlong)
Rem			change above index to:
Rem         (lifecyclepolicyid, lifecyclestate, lifecycledate)
Rem		22-sep-07 (dlong)
Rem			change above index to:
Rem         (lifecyclepolicyid, lifecyclepolicyentryid, lifecycledate)
Rem		12-jan-12 (dlong)
Rem			fix creator and owner of WORLD and SYSTEM objects

whenever sqlerror exit sql.sqlcode

declare
    s varchar2(200);
begin
    select a.id into s from odmv_attribute a, odmv_classobject c where a.class = c.id and c.name = 'FOLDERPATHRELATIONSHIP' and a.name = 'RIGHTOBJECTNAME';
    execute immediate 'create unique index odmi_' || s || '_uni on odm_folderpathrelationship (leftobjectcopy, rightobjectname)';
    select a.id into s from odmv_attribute a, odmv_classobject c where a.class = c.id and c.name = 'RELATIONSHIP' and a.name = 'LEFTOBJECT';
    execute immediate 'create index odmi_' || s || '_uni on odm_relationship (leftobject, rightobject)';
    select a.id into s from odmv_attribute a, odmv_classobject c where a.class = c.id and c.name = 'DOCUMENT' and a.name = 'LIFECYCLEDATE';
    execute immediate 'create index odmi_' || s || '_uni on odm_document (lifecyclepolicyid, lifecyclepolicyentryid, lifecycledate)';

    execute immediate 'create or replace view odmz_publicobject as select id, owner, acl from odm_publicobject';
end;
/

update odm_publicobject set creator = 96, owner = 96 where id = 96;
update odm_publicobject set creator = 96, owner = 96 where id = 1;
update odm_directorygroup set OWNERUNIQUENAME = '96-WORLD' where id = 1;

commit;
exit;


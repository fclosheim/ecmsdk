Rem Copyright (c) 2015, inxire GmbH and/or its affiliates.
Rem All rights reserved. 
Rem
Rem  NAME
Rem    SetRepositoryParameters.sql - initial population of ODMZ_REPOSITORYPARAMETERS
Rem
Rem History:
Rem     15-apr-15 (fcloshei)
Rem         Created.

INSERT INTO odmz_repositoryparameter
(
    name,
    value
) VALUES (
    '&1',
    '&2'
);

Rem Copyright (c) 2008, 2012, Oracle and/or its affiliates.
Rem All rights reserved. 
Rem
Rem  NAME
Rem    odmmain.sql - initial population of Document Management Schema
Rem
Rem History:
Rem     07-jun-08 (dlong)
Rem         Created.
Rem     17-jun-12 (dlong)
Rem         Remove references to ECM-mode artifacts.

whenever sqlerror continue

drop table odmz_attribute_datatype;
drop table odmz_crawler_alerttype;

create sequence odmc_alert_seq
  START WITH 1000
  INCREMENT BY 1
  NOMAXVALUE
  NOCYCLE
  ORDER
  CACHE 200;

whenever sqlerror exit sql.sqlcode

Prompt create and populate data type and alert type tables
create table odmz_attribute_datatype
(
    typeid        NUMBER(10)    PRIMARY KEY
  , description   VARCHAR2(30) NOT NULL
);

create table odmz_crawler_alerttype
(
    typeid        NUMBER(10)    PRIMARY KEY
  , description   VARCHAR2(700) NOT NULL
);

insert into odmz_attribute_datatype (typeid, description) 
  values (1, 'DATE');
insert into odmz_attribute_datatype (typeid, description) 
  values (2, 'STRING');
insert into odmz_attribute_datatype (typeid, description) 
  values (3, 'DOUBLE');
insert into odmz_attribute_datatype (typeid, description) 
  values (4, 'INTEGER');
insert into odmz_attribute_datatype (typeid, description) 
  values (5, 'BOOLEAN');
insert into odmz_attribute_datatype (typeid, description) 
  values (7, 'USER');
insert into odmz_attribute_datatype (typeid, description) 
  values (8, 'LONG');
commit;

insert into odmz_crawler_alerttype (typeid, description) 
  values (100, 'DOCUMENT_CREATED');
insert into odmz_crawler_alerttype (typeid, description) 
  values (101, 'DOCUMENT_UPDATED');
insert into odmz_crawler_alerttype (typeid, description) 
  values (102, 'DOCUMENT_DELETED');
insert into odmz_crawler_alerttype (typeid, description) 
  values (103, 'DOCUMENT_MOVED');
insert into odmz_crawler_alerttype (typeid, description) 
  values (104, 'DOCUMENT_SECURITY_REFERENCE_CHANGED');
insert into odmz_crawler_alerttype (typeid, description) 
  values (105, 'DOCUMENT_CATEGORY_INFO_CHANGED');
insert into odmz_crawler_alerttype (typeid, description) 
  values (106, 'DOCUMENT_CONTENT_CHANGED');
insert into odmz_crawler_alerttype (typeid, description) 
  values (107, 'DOCUMENT_DELETE_PENDING');
insert into odmz_crawler_alerttype (typeid, description) 
  values (108, 'DOCUMENT_DELETE_PENDING_CANCELED');

insert into odmz_crawler_alerttype (typeid, description) 
  values (200, 'SECURITY_DEFINITION_CREATED');
insert into odmz_crawler_alerttype (typeid, description) 
  values (201, 'SECURITY_DEFINITION_CHANGED');
insert into odmz_crawler_alerttype (typeid, description) 
  values (202, 'SECURITY_DEFINITION_DELETED');

insert into odmz_crawler_alerttype (typeid, description) 
  values (300, 'GRANTEE_CREATED');
insert into odmz_crawler_alerttype (typeid, description) 
  values (301, 'GRANTEE_RESOLUTION_CHANGED');
insert into odmz_crawler_alerttype (typeid, description) 
  values (302, 'GRANTEE_DELETED');

insert into odmz_crawler_alerttype (typeid, description) 
  values (400, 'USER_CREATED');
insert into odmz_crawler_alerttype (typeid, description) 
  values (401, 'USER_UPDATED');
insert into odmz_crawler_alerttype (typeid, description) 
  values (402, 'USER_DELETED');

insert into odmz_crawler_alerttype (typeid, description) 
  values (500, 'FOLDER_CREATED');
insert into odmz_crawler_alerttype (typeid, description) 
  values (501, 'FOLDER_RENAMED');
insert into odmz_crawler_alerttype (typeid, description) 
  values (502, 'FOLDER_DELETED');
insert into odmz_crawler_alerttype (typeid, description) 
  values (503, 'FOLDER_MOVED');

insert into odmz_crawler_alerttype (typeid, description) 
  values (600, 'CATEGORY_TYPE_CREATED');
insert into odmz_crawler_alerttype (typeid, description) 
  values (601, 'CATEGORY_TYPE_UPDATED');
insert into odmz_crawler_alerttype (typeid, description) 
  values (602, 'CATEGORY_TYPE_DELETED');
commit;

Prompt create views
create or replace view odmzv_domain_properties as
  select p.id, p.bundle, p.name propertyname, p.datatype, 
         p.stringvalue, p.datevalue,
         p.booleanvalue, p.integervalue, p.longvalue, p.doublevalue,
         p.publicobjectvalue, p.directoryobjectvalue, p.systemobjectvalue,
         p.schemaobjectvalue
  from   odm_property p, odm_propertybundle dompb,
         odm_property pref, odm_propertybundle vpb,
         odmv_valuedefault vd
  where  p.bundle = dompb.id and
         dompb.id = pref.publicobjectvalue and
         pref.name = 'VALUEDEFAULT' and
         pref.bundle = vpb.id and
         vpb.id = vd.valuedefaultpb and
         vd.name = 'IFS.DOMAIN.Properties';

create or replace view odmzv_candidateacls as
  select id aclid, 0 trashacl
  from odm_accesscontrollist;

create or replace view odmzv_resolved_user as
  select du.id id, du.id userid from odm_directoryuser du;

create or replace view odmzv_secured_document as
  select d.id documentid, d.acl securityid, d.primaryparentfolder parentfolderid,
  ra.trashacl deletepending, 1 latestversion
  from odmv_document d, odmzv_candidateacls ra 
  where d.acl = ra.aclid and d.family = 0 and d.primaryparentfolder > 0
  union all
  select d.id documentid, d.acl securityid, f.primaryparentfolder parentfolderid,
  ra.trashacl, decode(f.resolvedpublicobject, d.id, 1, 0)
  from odmv_document d, odmv_family f, odmzv_candidateacls ra 
  where d.acl = ra.aclid and d.family = f.id and f.primaryparentfolder > 0;

create or replace view odmzv_security_definition as
  select z.aclid securityid, z.userid granteeid,
  1 contentaccess, 1 metadataaccess, 0 relationaccess
  from odmz_acl_discoverer z, odmzv_candidateacls ra
  where z.aclid = ra.aclid;

create or replace view odmzv_resolved_grantee as
  select z.leftid granteeid, ru.userid userid
  from odmz_groupindex z, odmzv_resolved_user ru
  where z.rightid = ru.id;

create or replace view odmzv_user_info as
  select du.id userid, du.name, du.distinguishedname, du.name lastname, du.name firstname
  from odmv_directoryuser du;

create or replace view odmzv_document_info as
  select d.id documentid, d.name, d.description, ru1.userid creator_userid, 
         d.createdate, d.lastmodifydate, to_char(d.id) url_suffix, 
         c.contentsize, c.language, fmt.mimetype, 
         decode(bitand(d.flags, 65536), 65536, 1, 0) has_category
  from odmzv_secured_document sd, odmv_document d, odm_contentobject c,
       odmzv_resolved_user ru1, odm_format fmt
  where sd.documentid = d.id and d.contentobject = c.id 
        and d.creator = ru1.id and c.format = fmt.id;

create or replace view odmzv_folder_hierarchy as
  select f.id folderid, f.primaryparentfolder parentfolderid, f.name foldername
  from odmv_folder f;

create or replace view odmzv_document_category_info as
  select d.documentid, c.id categoryid, c.classid categorytypeid
  from odmzv_secured_document d, odmv_category c
  where d.documentid = c.associatedpublicobject;

create or replace view odmzv_document_category_type as
  select co.id categorytypeid, co.name categoryname, 
         'odmv_' || co.databaseobjectname viewname
  from odmv_classobject co
  where co.id in 
     (select ch.subclassid from odmz_class_hierarchy ch, odmv_classobject co2
          where ch.classid = co2.id and 
                ch.classid != ch.subclassid and 
                co2.name = 'CATEGORY');

create or replace view odmzv_document_category_attr as
  select ct.categorytypeid, a.name attributename,
         a.databaseobjectname columnname,
         ad.description datatype, a.datatype datatypeenum
  from   odmv_attribute a, odmz_class_hierarchy ch,
         odmz_attribute_datatype ad, odmzv_document_category_type ct
  where  ct.categorytypeid = ch.subclassid and
         a.class = ch.classid and
         a.datatype = ad.typeid and ch.classid NOT IN
            (select ch2.classid from odmz_class_hierarchy ch2, odmv_classobject co
                where ch2.subclassid = co.id and co.name = 'CATEGORY');

create or replace view odmzv_crawler_property as
  select 'DOCUMENT_CONTENT_URL_PREFIX' propertyname,
    decode( (select booleanvalue from odmzv_domain_properties where propertyname = 'IFS.DOMAIN.APPLICATION.ApplicationUseHttps'), 1, 'https://', 'http://')
    ||
    (select stringvalue from odmzv_domain_properties where propertyname = 'IFS.DOMAIN.APPLICATION.ApplicationHost')
    || ':' || 
    (select integervalue from odmzv_domain_properties where propertyname = 'IFS.DOMAIN.APPLICATION.ApplicationPort')
    ||
    (select stringvalue from odmzv_domain_properties where propertyname = 'IFS.DOMAIN.APPLICATION.WebDavMountPoint')
    || '/?docid='
    propertyvalue from dual
  union all
  select 'WEBDAV_MOUNTPOINT',
    decode( (select booleanvalue from odmzv_domain_properties where propertyname = 'IFS.DOMAIN.APPLICATION.ApplicationUseHttps'), 1, 'https://', 'http://')
    ||
    (select stringvalue from odmzv_domain_properties where propertyname = 'IFS.DOMAIN.APPLICATION.ApplicationHost')
    || ':' || 
    (select integervalue from odmzv_domain_properties where propertyname = 'IFS.DOMAIN.APPLICATION.ApplicationPort')
    ||
    (select stringvalue from odmzv_domain_properties where propertyname = 'IFS.DOMAIN.APPLICATION.WebDavMountPoint')
    from dual;

commit;
exit;

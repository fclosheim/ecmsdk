Rem Copyright (c) 2004, 2008, Oracle. All rights reserved.
Rem
Rem  NAME
Rem    contextsetup2.sql - Setup Context Schema for DM
Rem
Rem  History:
Rem    31-mar-04 (sayyagar)
Rem      Create fast filter preference
Rem    05-sep-08 (dpitfiel)
Rem      Renamed CONTENTPROCEDURE to CONTENTINDEX in odmz_context_router.
Rem    21-dec-15 (dscholle)
Rem      ECMSDK-41: Removed connect statement

whenever sqlerror exit sql.sqlcode

Prompt Setting up Default Filter Preference to FAST_FILTER.
exec ctx_ddl.create_preference('IFS_FAST_FILTER', 'INSO_FILTER');
exec ctx_ddl.set_attribute('IFS_FAST_FILTER', 'TIMEOUT', '120');
exec ctx_ddl.set_attribute('IFS_FAST_FILTER', 'OUTPUT_FORMATTING', 'FALSE');

Rem Creating index on routing table.
create index IFS_TEXT on ODMZ_CONTEXT_ROUTER(contentindex)
	indextype is ctxsys.CONTEXT
	parameters ( 'storage IFS_DEF_STORAGE datastore IFS_USER_DATASTORE lexer IFS_GLOBAL_LEXER language column language FILTER IFS_FAST_FILTER format column FORMAT charset column CHARACTERSET wordlist IFS_DEF_WORDLIST memory 32000000 stoplist CTXSYS.DEFAULT_STOPLIST section group IFS_SECTION_GROUP');

Rem create filter preference for view_as_html. 
exec ctx_ddl.create_preference('IFS_VIEW_AS_HTML_FILTER', 'INSO_FILTER');
exec ctx_ddl.set_attribute('IFS_VIEW_AS_HTML_FILTER', 'TIMEOUT', '120');

Prompt Creating filter policy for view_as_html functionality
exec  ctx_ddl.create_policy(policy_name => 'IfsFilterPolicy',
    	filter => 'IFS_VIEW_AS_HTML_FILTER',
    	section_group => 'IFS_SECTION_GROUP',
    	lexer => 'IFS_DEFAULT_LEXER',
    	stoplist => 'CTXSYS.DEFAULT_STOPLIST',
    	wordlist => 'IFS_DEF_WORDLIST');
commit;
exit;



Rem Copyright (c) 2002, 2008, Oracle. All rights reserved.  
Rem
Rem NAME
Rem     CreateDomainRegistry.sql
Rem         Creates the view odmzv_nodeconfiguration
Rem
Rem PARAMETERS
Rem     &1  schema name, e.g. ifsuser
Rem     &2  schema password, e.g. ifsuser
Rem
Rem History:
Rem     05-mar-02 (dpitfiel)
Rem         Created.
Rem     15-apr-02 (dpitfiel)
Rem         odmzv_nodeconfiguration includes inactive nodes.
Rem     15-may-02 (dlong)
Rem         fix 2377254; use create or replace view ...
Rem     13-aug-04 (pyoung)
Rem         grant additional priviledges now omitted by 10g.
Rem     25-jan-05 (sgarg)
Rem         removed odmzv_domaincontrollerconfig view
Rem     31-may-05 (sgarg)
Rem         removed $dr schema

WHENEVER SQLERROR EXIT SQL.SQLCODE
SET SERVEROUTPUT ON

CONNECT &1/&2;

CREATE OR REPLACE VIEW odmzv_nodeconfiguration
    AS
        SELECT
            nc.name nodename,
            nc.active nodeactive,
            p.*
        FROM
            odmv_property p,
            odmv_nodeconfiguration nc
        WHERE
            p.name LIKE 'IFS.NODE.%' AND
            nc.propertybundle = p.bundle; 

EXIT;

-- EOF


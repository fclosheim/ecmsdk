set serveroutput on;

declare
    jobid binary_integer;
    err_num number;
	CURSOR c1  is
		select job from all_jobs where what = 'wf_event.listen(''ECM_OUT'');';
begin
	for cIdx in c1 loop
        dbms_output.put_line('Removing DBMS Job : ' || cIdx.job);
        dbms_job.remove( job=>cIdx.job);
    end loop;
end;
/
exit;


    


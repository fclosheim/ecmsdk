Rem
Rem $Header: SetupWorkflowExpirationJob.sql 28-feb-2006.00:42:45 vvedula Exp $
Rem
Rem SetupWorkflowExpirationJob.sql
Rem
Rem Copyright (c) 2006, 2008, Oracle. All rights reserved.  
Rem
Rem    NAME
Rem      SetupWorkflowExpirationJob.sql - <one-line expansion of the name>
Rem
Rem    DESCRIPTION
Rem      Setup Oracle Workflow Background engine as DBMS JOB for request expiration.
Rem
Rem    NOTES
Rem      Runs the OWF Engine once a day.
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    vvedula     02/28/06 - Created
Rem

SET ECHO ON
SET FEEDBACK 1
SET NUMWIDTH 10
SET LINESIZE 80
SET TRIMSPOOL ON
SET TAB OFF
SET PAGESIZE 100

declare
    job binary_integer;
begin
    dbms_job.submit(job,
                    'wf_engine.background();',
                    TRUNC(SYSDATE, 'DD'),
                    'TRUNC(SYSDATE+1,''DD'')');

end;
/
exit;



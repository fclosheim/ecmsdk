set serveroutput on;

grant execute on IfsQueueMessage to &1;
grant execute on IfsQueueMessageParameter    to &1;
grant execute on Parameters    to &1;

begin
dbms_aqadm.grant_queue_privilege(
    privilege => 'DEQUEUE',
    queue_name => 'IFS_OUT',
	grantee => '&1',
	grant_option => TRUE);
    dbms_output.put_line ('Granted dequeue privilege on IFS_OUT to &1');
end;
/

begin
dbms_aqadm.grant_queue_privilege(
    privilege => 'ENQUEUE',
    queue_name => 'IFS_IN',
	grantee => '&1',
	grant_option => TRUE);
    dbms_output.put_line ('Granted enqueue privilege on IFS_IN to &1');
end;
/

commit;
exit;


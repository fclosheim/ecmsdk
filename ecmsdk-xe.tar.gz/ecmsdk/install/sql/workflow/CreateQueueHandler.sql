set autocommit off;
set echo on;

create or replace package ECM_QH as
    PROCEDURE dequeue(p_agent_guid in  raw,
                         p_event      out wf_event_t);
    PROCEDURE enqueue(p_event              in wf_event_t,
                      p_out_agent_override in wf_agent_t default null);
end ECM_QH;
/

show errors;

create or replace package body ECM_QH as

    PROCEDURE dequeue(p_agent_guid in  raw,
                         p_event      out wf_event_t) AS
    deq_msgid           RAW(16);
    dopt                dbms_aq.dequeue_options_t;
    mprop               dbms_aq.message_properties_t;
    payload             &1..IfsQueueMessage;
    params  		    &1..Parameters;
    no_messages         exception;
    pragma exception_init(no_messages, -25228);
    j			NUMBER;
    name                VARCHAR2(100);
    value               VARCHAR2(2000);
    messageType         VARCHAR2(30);
	levent              wf_event_t;
	agent               wf_agent_t;
	EventKey            varchar2(30);
	i                   NUMBER;
	qname               varchar2(30);
	agentName           varchar2(30);
	localSystem           varchar2(40);
BEGIN
    dopt.consumer_name := 'wf';
    dopt.wait := 1;

    select upper(queue_name)
    into   qname
    from   wf_agents
    where  guid = p_agent_guid;

    select upper(name)
    into   agentName
    from   wf_agents
    where  guid = p_agent_guid;

    select name into localSystem
    from wf_systems
	where guid = wf_core.translate('WF_SYSTEM_GUID');

    BEGIN
    dbms_aq.dequeue(
        queue_name => qname,
        dequeue_options => dopt,
        message_properties => mprop,
        payload => payload,
        msgid => deq_msgid);


    messageType := payload.getMessageType();

    wf_event_t.initialize(levent);

    levent.SetEventName(messageType);

	params := payload.GetParameterList();

	i := params.FIRST;

    while (i <= params.LAST) loop

        name := params(i).getName();
        value := params(i).getValue();

		if (name = 'IFS_ECM_WORKFLOW_PROCESSID') then
			levent.setCorrelationId(value);
		end if;

      	levent.AddParameterToList(name, value);

        i := params.next(i);

    end loop;

	agent := wf_agent_t(agentName, localSystem);
    levent.SetFromAgent(agent);

	p_event := levent;

    EXCEPTION
    when no_messages then
      wf_log_pkg.string(6, 'dequeue', 'No more messages in dequeue.');
      p_event := NULL;
      return;
	END;

EXCEPTION
  when others then
    Wf_Core.Context('ECM_QH', 'Dequeue', 'ECM_OUT',
                     'SQL err is '||substr(sqlerrm,1,200));
    raise;
END dequeue;

    PROCEDURE ENQUEUE(p_event                 wf_event_t,
                      p_out_agent_override    wf_agent_t ) AS
    EventName            varchar2(30);
    ParamName            varchar2(100);
    ParamValue           varchar2(2000);
    Message              &1..IfsQueueMessage;
    plist                wf_parameter_list_t;
    i                    number;
	qname				 varchar2(60);
    eopt                dbms_aq.enqueue_options_t;
    mprop               dbms_aq.message_properties_t;
    enq_msgid   RAW(16);
	x_out_agent_name     varchar2(30);
	x_out_system_name     varchar2(30);
	x_out_queue     varchar2(30);
BEGIN

   if (p_out_agent_override is not null) then
      x_out_agent_name := p_out_agent_override.GetName();
      x_out_system_name := p_out_agent_override.GetSystem();
   else
      x_out_agent_name := p_event.GetFromAgent().GetName();
      x_out_system_name := p_event.GetFromAgent().GetSystem();
   end if;

   select agt.queue_name into x_out_queue
   from   wf_agents  agt,
          wf_systems sys
   where  agt.name = x_out_agent_name
   and    sys.name = x_out_system_name
   and    sys.guid = agt.system_guid;

    EventName := p_event.getEventName();

    &1..IfsQueueMessage.initialize(EventName, Message);

    Message.setMessageType(EventName);

    plist := p_event.getParameterList();

    i := plist.FIRST;

    while (i <= plist.LAST) loop

        ParamName := plist(i).getName();
        ParamValue := plist(i).getValue();
        Message.AddParameterToList(ParamName, ParamValue, 'STRING');
        i := plist.next(i);

    end loop;

    mprop.priority := 1;
    qname := '&1..IFS_IN';

    dbms_aq.enqueue(
        queue_name => x_out_queue,
        enqueue_options => eopt,
        message_properties => mprop,
        payload => message,
        msgid => enq_msgid);

END enqueue;

END ECM_QH;
/
show errors;

exit;


set serveroutput on;

declare
    CurrentGuid     raw(16);
    StartEventName     varchar2(100);
    CancelEventName    varchar2(100);
begin

    StartEventName := 'START_STANDARD_WORKFLOW';
    CancelEventName := 'CANCEL_STANDARD_WORKFLOW';


    begin
      select subscriptions.guid into CurrentGuid
      from wf_event_subscriptions subscriptions,
           wf_events events
      where subscriptions.event_filter_guid = events.guid
      and   events.name = StartEventName;
      dbms_output.put_line('Dropping event susbscriptions of ' || StartEventName);
      dbms_output.put_line('      Event subscription GUID : ' || CurrentGuid);
      dbms_output.put_line('        ');
      wf_event_subscriptions_pkg.Delete_Row(CurrentGuid);
    exception
      when NO_DATA_FOUND then
        dbms_output.put_line('Event subscriptions not found for: ' || StartEventName); 
    end;   


    begin
      select subscriptions.guid into CurrentGuid
      from wf_event_subscriptions subscriptions,
           wf_events events
      where subscriptions.event_filter_guid = events.guid
      and   events.name = CancelEventName;
      dbms_output.put_line('Dropping event susbscriptions of ' || CancelEventName);
      dbms_output.put_line('      Event subscription GUID : ' || CurrentGuid);
      dbms_output.put_line('        ');
      wf_event_subscriptions_pkg.Delete_Row(CurrentGuid);
    exception
      when NO_DATA_FOUND then
        dbms_output.put_line('Event subscriptions not found for: ' || CancelEventName);
    end;


    begin
      select guid into CurrentGuid
      from wf_events
      where name = StartEventName;
      dbms_output.put_line('Dropping event ' || StartEventName);
      dbms_output.put_line('        ');
      wf_events_pkg.Delete_Row(CurrentGuid);
    exception
      when NO_DATA_FOUND then
        dbms_output.put_line('Event not found: ' || StartEventName);
    end;


    begin
      select guid into CurrentGuid
      from wf_events
      where name = CancelEventName;
      dbms_output.put_line('Dropping event ' || CancelEventName);
      dbms_output.put_line('        ');
      wf_events_pkg.Delete_Row(CurrentGuid);
    exception
      when NO_DATA_FOUND then
        dbms_output.put_line('Event not found: ' || CancelEventName);
    end;


    StartEventName := 'START_SERIAL_WORKFLOW';
    CancelEventName := 'CANCEL_SERIAL_WORKFLOW';


    begin
      select subscriptions.guid into CurrentGuid
      from wf_event_subscriptions subscriptions,
           wf_events events
      where subscriptions.event_filter_guid = events.guid
      and   events.name = StartEventName;
      dbms_output.put_line('Dropping event susbscriptions of ' || StartEventName);
      dbms_output.put_line('      Event subscription GUID : ' || CurrentGuid);
      dbms_output.put_line('        ');
      wf_event_subscriptions_pkg.Delete_Row(CurrentGuid);
    exception
      when NO_DATA_FOUND then
        dbms_output.put_line('Event susbscriptions not found for: ' || StartEventName);
    end;


    begin
      select subscriptions.guid into CurrentGuid
      from wf_event_subscriptions subscriptions,
           wf_events events
      where subscriptions.event_filter_guid = events.guid
      and   events.name = CancelEventName;
      dbms_output.put_line('Dropping event susbscriptions of ' || CancelEventName);
      dbms_output.put_line('      Event subscription GUID : ' || CurrentGuid);
      dbms_output.put_line('        ');
      wf_event_subscriptions_pkg.Delete_Row(CurrentGuid);
    exception
      when NO_DATA_FOUND then
        dbms_output.put_line('Event susbscriptions not found for: ' || CancelEventName);
    end;


    begin
      select guid into CurrentGuid
      from wf_events
      where name = StartEventName;
      dbms_output.put_line('Dropping event ' || StartEventName);
      dbms_output.put_line('        ');
      wf_events_pkg.Delete_Row(CurrentGuid);
    exception
      when NO_DATA_FOUND then
        dbms_output.put_line('Event not found: ' || StartEventName);
    end;    


    begin
      select guid into CurrentGuid
      from wf_events
      where name = CancelEventName;
      dbms_output.put_line('Dropping event ' || CancelEventName);
      dbms_output.put_line('        ');
      wf_events_pkg.Delete_Row(CurrentGuid);
    exception
      when NO_DATA_FOUND then
        dbms_output.put_line('Event not found: ' || CancelEventName);
    end;


    begin
      select guid into CurrentGuid
      from wf_agents
      where name = 'ECM_OUT';
      dbms_output.put_line('Dropping Agent ECM_OUT' );
      wf_agents_pkg.Delete_Row(CurrentGuid);
    exception
      when NO_DATA_FOUND then
        dbms_output.put_line('Agent not found: ECM_OUT');
    end;     


    begin
      select guid into CurrentGuid
      from wf_agents
      where name = 'ECM_IN';
      dbms_output.put_line('Dropping Agent ECM_IN' );
      wf_agents_pkg.Delete_Row(CurrentGuid);
    exception
      when NO_DATA_FOUND then
        dbms_output.put_line('Agent not found: ECM_IN');
    end;

end;

/
exit;



set serveroutput on;

declare
  privilege_not_granted exception;
  pragma exception_init(privilege_not_granted, -01927);
  not_subscribed exception;
  pragma exception_init(not_subscribed, -24035);
  subscriber sys.aq$_agent;
begin
  
  begin
    execute immediate 'revoke execute on IfsQueueMessage from &1';
    dbms_output.put_line('Revoked execute privilege from &1 on IfsQueueMessage');
  exception 
    when privilege_not_granted then
      dbms_output.put_line('Execute privilege not granted to &1 on IfsQueueMessage');
  end;
  
  begin
    execute immediate 'revoke execute on IfsQueueMessageParameter from &1';
    dbms_output.put_line('Revoked execute privilege from &1 on IfsQueueMessageParameter');
  exception
    when privilege_not_granted then
      dbms_output.put_line('Execute privilege not granted to &1 on IfsQueueMessageParameter');
  end;

  begin
    execute immediate 'revoke execute on Parameters from &1';
    dbms_output.put_line('Revoked execute privilege from &1 on Parameters');
  exception
    when privilege_not_granted then
      dbms_output.put_line('Execute privilege not granted to &1 on Parameters');
  end; 

  begin
    dbms_aqadm.revoke_queue_privilege(
      privilege => 'DEQUEUE',
      queue_name => 'IFS_OUT',
      grantee => '&1');
    dbms_output.put_line ('Revoked dequeue privilege from &1 on IFS_OUT');
  exception
    when privilege_not_granted then
      dbms_output.put_line('Dequeue privilege not granted to &1 on IFS_OUT');
  end;

  begin  
    dbms_aqadm.revoke_queue_privilege(
      privilege => 'ENQUEUE',
      queue_name => 'IFS_IN',
      grantee => '&1');
    dbms_output.put_line ('Revoked enqueue privilege from &1 on IFS_IN');
  exception
    when privilege_not_granted then
      dbms_output.put_line('Enqueue privilege not granted to &1 on IFS_IN');
  end;
 
  begin
    subscriber := sys.aq$_agent('wf', NULL, NULL);
    dbms_aqadm.remove_subscriber(
        queue_name => 'ifs_out',
        subscriber => subscriber);
    dbms_output.put_line ('Removed subscriber wf from ifs_out');
  exception
    when not_subscribed then
      dbms_output.put_line('wf not subscribed to ifs_out');
  end;

end;
/

commit;
exit;


Rem
Rem $Header: CleanupWorkflowExpirationJob.sql 28-feb-2006.00:42:57 vvedula Exp $
Rem
Rem CleanupWorkflowExpirationJob.sql
Rem
Rem Copyright (c) 2006, 2008, Oracle. All rights reserved.  
Rem
Rem    NAME
Rem      CleanupWorkflowExpirationJob.sql - <one-line expansion of the name>
Rem
Rem    DESCRIPTION
Rem      Removes the Workflow Expiration Job from OWF.
Rem
Rem    NOTES
Rem      Clear the wf_engine.background() job from OWF.
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    vvedula     02/28/06 - Created
Rem

SET ECHO ON
SET FEEDBACK 1
SET NUMWIDTH 10
SET LINESIZE 80
SET TRIMSPOOL ON
SET TAB OFF
SET PAGESIZE 100

set serveroutput on;

declare
    jobid binary_integer;
    err_num number;
        CURSOR c1  is
                select job from all_jobs where what = 'wf_engine.background();';
begin
        for cIdx in c1 loop
        dbms_output.put_line('Removing DBMS Job : ' || cIdx.job);
        dbms_job.remove( job=>cIdx.job);
    end loop;
end;
/
exit;



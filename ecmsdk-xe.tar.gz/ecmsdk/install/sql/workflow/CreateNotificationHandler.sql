rem  --------------------------------------
rem
rem  CreateNotificationHandler.sql - This file is used to
rem  to create a rule function that could be
rem  used to approve a notification in workflow process
rem  using BES. Currently, this is not being used
rem  by the sample, but is shipped as an example.
rem
rem ----------------------------------------


set echo on;

create or replace package ECM_NOTIFICATION as
		FUNCTION ApproveOrDeny(p_subscription_guid in     raw,
       			               p_event             in out wf_event_t) return varchar2;
end ECM_NOTIFICATION;
/

show errors;


create or replace package body ECM_NOTIFICATION as

FUNCTION ApproveOrDeny(p_subscription_guid in     raw,
                      p_event             in out wf_event_t) return varchar2

is
 l_parameter_list wf_parameter_list_t;
 notification_id number;
 pos number := 1;
 result  varchar2(100);
 l_responder varchar2(1000);
 l_comment varchar2(1000);
begin

l_parameter_list:= p_event.getParameterList();

  pos := l_parameter_list.LAST;
  while(pos is not null) loop
    if (l_parameter_list(pos).getName() = 'IFS_ECM_WORKFLOW_NID') then
     notification_id  := to_number(l_parameter_list(pos).getValue());
    elsif (l_parameter_list(pos).getName() = 'IFS_ECM_WORKFLOW_RESPONDER') then
     l_responder := l_parameter_list(pos).getValue();
    elsif(l_parameter_list(pos).getName() = 'IFS_ECM_WORKFLOW_RESPONSE') then
   result := l_parameter_list(pos).getValue();
    elsif(l_parameter_list(pos).getName() = 'IFS_ECM_WORKFLOW_COMMENT') then
  l_comment := l_parameter_list(pos).getValue();

    end if;
    pos := l_parameter_list.PRIOR(pos);
  end loop;

      wf_notification.SetAttrText(notification_id, 'RESULT' , result);
      wf_notification.SetAttrText(notification_id,'IFS_ECM_WORKFLOW_USERCOMMENTS',l_comment);
      wf_notification.respond(notification_id,l_comment,l_responder);

  return 'SUCCESS';

  exception
  when others then
    wf_core.context('Wf_Rule', 'Default_Rule', p_event.getEventName(),
                                                p_subscription_guid);
    wf_event.setErrorInfo(p_event, 'ERROR');
    return 'ERROR';
end;

END ECM_NOTIFICATION;
/
show errors;

exit;


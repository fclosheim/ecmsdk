set serveroutput on;

declare 
  no_package_found exception;
  pragma exception_init(no_package_found, -04043);
begin

  begin
    execute immediate 'drop package body ECM_RF';
    dbms_output.put_line('ECM_RF package body dropped');
  exception
    when no_package_found then
      dbms_output.put_line('ECM_RF package body not found');
  end;
  
  begin
    execute immediate 'drop package ECM_RF';
    dbms_output.put_line('ECM_RF package dropped');
  exception 
    when no_package_found then
      dbms_output.put_line('ECM_RF package not found');
  end;
  
end;
/

exit;


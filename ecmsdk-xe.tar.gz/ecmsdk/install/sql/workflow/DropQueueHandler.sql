set serveroutput on;

declare
  no_package_found exception;
  pragma exception_init(no_package_found, -04043);
begin

  begin
    execute immediate 'drop package body ECM_QH';
    dbms_output.put_line('ECM_QH package body dropped');
  exception
    when no_package_found then
      dbms_output.put_line('ECM_QH package body not found');
  end;

  begin
    execute immediate 'drop package ECM_QH';
    dbms_output.put_line('ECM_QH package dropped');
  exception
    when no_package_found then
      dbms_output.put_line('ECM_QH package not found');
  end;

end;
/

exit;


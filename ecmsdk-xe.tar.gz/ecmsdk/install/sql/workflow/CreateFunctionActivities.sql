SET autocommit off;
SET echo on;

CREATE OR REPLACE PACKAGE ECM_FA AS


PROCEDURE SetUpParameters(itemtype   IN      VARCHAR2,
                          itemkey    IN      VARCHAR2,
                          actid      IN      NUMBER,
                          funcmode   IN      VARCHAR2,
                          resultout  IN OUT  VARCHAR2);


PROCEDURE SetUpApprovers(itemtype   IN      VARCHAR2,
                         itemkey    IN      VARCHAR2,
                         actid      IN      NUMBER,
                         funcmode   IN      VARCHAR2,
                         resultout  IN OUT  VARCHAR2);


PROCEDURE SetUpMessageContent(document_id    IN      VARCHAR2,
                              display_type   IN      VARCHAR2,
                              document       IN OUT  VARCHAR2,
                              document_type  IN OUT  VARCHAR2); 


PROCEDURE SetUpAgents(itemtype   IN      VARCHAR2,
                      itemkey    IN      VARCHAR2,
                      actid      IN      NUMBER,
                      funcmode   IN      VARCHAR2,
                      resultout  IN OUT  VARCHAR2);


PROCEDURE VoteForResultType(itemtype   IN      VARCHAR2,
                            itemkey    IN      VARCHAR2,
                            actid      IN      NUMBER,
                            funcmode   IN      VARCHAR2,
                            resultout  IN OUT  VARCHAR2);


PROCEDURE GetNextApprover(itemtype   IN      VARCHAR2,
                          itemkey    IN      VARCHAR2,
                          actid      IN      NUMBER,
                          funcmode   IN      VARCHAR2,
                          resultout  IN OUT  VARCHAR2);

                           
END ECM_FA;
/

show errors;

CREATE OR REPLACE PACKAGE BODY ECM_FA AS


-- SetUpParameters
--   Sets the following workflow parameters:
--   IFS_REQUEST_TIMEOUT
--   IFS_RESPONDER_TIMEOUT
--   IFS_MESSAGE_PARAMETERS
--   IFS_ECM_WORKFLOW_MINYESVOTES
--   IFS_ECM_WORKFLOW_MINNOVOTES
--
-- IN
--   itemtype  - item type
--   itemkey   - item key
--   actid     - process activity instance id
--   funcmode  - execution mode
-- OUT
--   comparison result (WFSTD_COMPARISON lookup code)
--   GT LT EQ NULL
-- ACTIVITY ATTRIBUTES REFERENCED
--   EVENT     - Event whose property is to be compared
--   PROPERTY  - Event Property Reference (Based on the lookup of EVENTPROPERTY
--   PARAMETER - Parameter Name if Lookup type = Parameter
--   VALUE     - Constant value of correct type
PROCEDURE SetUpParameters(itemtype   IN      VARCHAR2,
                          itemkey    IN      VARCHAR2,
                          actid      IN      NUMBER,
                          funcmode   IN      VARCHAR2,
                          resultout  IN OUT  VARCHAR2)

IS

  requestTimeout    NUMBER;
  responderTimeout  NUMBER;
  strlen            NUMBER;
  minyesvotes       NUMBER;
  minnovotes        NUMBER;
  totalresponders   NUMBER := 1;
  messagesubject    VARCHAR2(2000);
  responderlist     VARCHAR2(2000);

BEGIN

  -- Retrieve Responder List
  responderlist := wf_engine.getItemAttrText(itemtype, 
                                             itemkey,
                                             'IFS_ECM_WORKFLOW_RESPONDERS');

  -- Calculate number of responders
  responderlist := ltrim(rtrim(responderlist));
  strlen := LENGTH(responderlist);
  FOR i IN 1..strlen
  LOOP
    IF (SUBSTR(responderlist, i, 1) = ' ') THEN
      totalresponders := totalresponders + 1;
    END IF;
  END LOOP;
  
  -- Retrieve number of votes
  minyesvotes := wf_engine.getItemAttrText(itemtype, 
                                           itemkey,
                                           'IFS_ECM_WORKFLOW_MINYESVOTES');
  minnovotes := wf_engine.getItemAttrText(itemtype, 
                                          itemkey,
                                          'IFS_ECM_WORKFLOW_MINNOVOTES');   

  -- Convert to percentages
  IF (minyesvotes = 0) THEN
    minyesvotes := 0;
  ELSIF (minyesvotes >= totalresponders) THEN
    minyesvotes := 100;
  ELSE
    minyesvotes := round((minyesvotes*100)/totalresponders, 4);
  END IF;  
  
  IF (minnovotes = 0) THEN
    minnovotes := 0;
  ELSIF (minnovotes >= totalresponders) THEN
    minnovotes := 100;
  ELSE
    minnovotes := round((minnovotes*100)/totalresponders, 4);
  END IF;
  
  -- Set voting percentages
  wf_engine.setItemAttrText(itemtype, 
                            itemkey, 
                            'IFS_ECM_WORKFLOW_MINYESVOTES', 
                            minyesvotes);  
  wf_engine.setItemAttrText(itemtype, 
                            itemkey, 
                            'IFS_ECM_WORKFLOW_MINNOVOTES', 
                            minnovotes); 

  -- Retrieve timeout values
  requestTimeout := wf_engine.getItemAttrText(itemtype, 
                                              itemkey,
                                              'IFS_REQUEST_TIMEOUT');
  responderTimeout := wf_engine.getItemAttrText(itemtype, 
                                                itemkey,
                                                'IFS_RESPONDER_TIMEOUT');   

  -- Convert to days
  requestTimeout := requestTimeout * 60 * 24;
  responderTimeout := responderTimeout * 60 * 24;
  
  -- Set timeout values
  wf_engine.setItemAttrText(itemtype, 
                            itemkey, 
                            'IFS_REQUEST_TIMEOUT', 
                            requestTimeout);  
  wf_engine.setItemAttrText(itemtype, 
                            itemkey, 
                            'IFS_RESPONDER_TIMEOUT', 
                            responderTimeout);  

 
  -- Set IFS_MESSAGE_PARAMETERS workflow attribute
  wf_engine.setItemAttrText(itemtype, 
                            itemkey, 
                            'IFS_MESSAGE_PARAMETERS', 
                            itemtype || ':' || itemkey);

  -- Set result string
  resultout := wf_engine.eng_completed || ':' || wf_engine.eng_null;

EXCEPTION

  WHEN OTHERS THEN
    Wf_Core.Context('Wf_Standard', 
                    'SetUpParameters', 
                    itemtype, 
                    itemkey, 
                    to_char(actid), 
                    funcmode);
    RAISE;

END SetUpParameters;


-- SetUpApprovers
--   Creates an ad-hoc role based on the list of responders
-- IN
--   itemtype  - item type
--   itemkey   - item key
--   actid     - process activity instance id
--   funcmode  - execution mode
-- OUT
--   comparison result (WFSTD_COMPARISON lookup code)
--   GT LT EQ NULL
-- ACTIVITY ATTRIBUTES REFERENCED
--   EVENT     - Event whose property is to be compared
--   PROPERTY  - Event Property Reference (Based on the lookup of EVENTPROPERTY
--   PARAMETER - Parameter Name if Lookup type = Parameter
--   VALUE     - Constant value of correct type
PROCEDURE SetUpApprovers(itemtype   IN      VARCHAR2,
                         itemkey    IN      VARCHAR2,
                         actid      IN      NUMBER,
                         funcmode   IN      VARCHAR2,
                         resultout  IN OUT  VARCHAR2)

IS

  i                NUMBER := 0;
  c                NUMBER := 1;
  rolename         VARCHAR2(2000);
  roledisplayname  VARCHAR2(2000);
  responderlist    VARCHAR2(2000);
  respondertable   WF_DIRECTORY.USERTABLE;

BEGIN

  -- Retrieve the list of responders
  responderlist := wf_engine.getActivityAttrText(itemtype,
                                                 itemkey,
                                                 actid,
                                                 'IFS_ECM_WORKFLOW_RESPONDERS');

  -- Fix bug 5196159: convert String of responders to a UserTable of responders
  -- Replace ';' in the usernames with spaces
  loop
    i := instr(responderlist, ' ');

    if (i = 0) then

      -- Add the last responder in the list and exit the loop
      respondertable(c) := replace(responderlist, ';', ' ');
      exit;

    else

      -- Add the next responder in the list
      respondertable(c) := replace(substr(responderlist, 1, i - 1), ';', ' ');

    end if;

    c := c + 1;

    -- Move to the next responder
    responderlist := substr(responderlist, i + 1);

  end loop;

  -- Create the ad-hoc role using this list
  -- This API uses WF_DIRECTORY.UserTable for creating the adhoc role  
  Wf_Directory.CreateAdHocRole2(role_name         => rolename,
                                role_display_name => roledisplayname,  
                                role_users        => respondertable);  

  -- Set APPROVERSROLENAME workflow attribute
  wf_engine.setItemAttrText(itemtype, 
                            itemkey, 
                            'APPROVERSROLENAME', 
                            rolename);

  -- Set result string
  resultout := wf_engine.eng_completed || ':' || wf_engine.eng_null;
   
EXCEPTION

  WHEN OTHERS THEN
    Wf_Core.Context('Wf_Standard', 
                    'SetUpApprovers', 
                    itemtype, 
                    itemkey, 
                    to_char(actid), 
                    funcmode);
    RAISE;

END SetUpApprovers;


-- SetUpMessageContent
--   Sets up the message content dynamically
-- IN
--   document_id  - document identifier
--   display_type - notification content type
-- OUT
--   document      - notification content (up to 32K)
--   document_type - document content type
PROCEDURE SetUpMessageContent(document_id    IN      VARCHAR2,
                              display_type   IN      VARCHAR2,
                              document       IN OUT  VARCHAR2,
                              document_type  IN OUT  VARCHAR2)

IS

  itemtype            VARCHAR2(2000);
  itemkey             VARCHAR2(2000);
  mesgheader          VARCHAR2(2000);
  mesgapprove         VARCHAR2(2000);
  mesgreject          VARCHAR2(2000);

BEGIN

  -- Retrieve itemtype and itemkey
  itemtype := substr (document_id, 1, instr(document_id, ':', 1,1) - 1);
  itemkey  := substr (document_id, instr(document_id, ':', 1,1) + 1);

  -- Retrieve workflow attributes for dynamic message content
  mesgheader := wf_engine.getItemAttrText(itemtype, 
                                          itemkey, 
                                          'IFS_MESSAGE_HEADER');
  mesgapprove := wf_engine.getItemAttrText(itemtype, 
                                           itemkey, 
                                           'IFS_APPROVE_MSG');
  mesgreject := wf_engine.getItemAttrText(itemtype, 
                                          itemkey, 
                                          'IFS_REJECT_MSG');
  
  -- Set message content
  document := mesgheader  || '<BR><BR>' ||
              mesgapprove || '<BR>'     ||  mesgreject;

  -- Set message type
  document_type := 'text/html';
  
EXCEPTION

  WHEN OTHERS THEN
    Wf_Core.Context('Wf_Standard', 
                    'SetUpMessageContent', 
                    itemtype, 
                    itemkey);
    RAISE;  

END SetUpMessageContent;


-- SetUpAgents
--   Sets the agent name for the workflow
-- IN
--   itemtype  - item type
--   itemkey   - item key
--   actid     - process activity instance id
--   funcmode  - execution mode
-- OUT
--   comparison result (WFSTD_COMPARISON lookup code)
--   GT LT EQ NULL
-- ACTIVITY ATTRIBUTES REFERENCED
--   EVENT     - Event whose property is to be compared
--   PROPERTY  - Event Property Reference (Based on the lookup of EVENTPROPERTY
--   PARAMETER - Parameter Name if Lookup type = Parameter
--   VALUE     - Constant value of correct type
PROCEDURE SetUpAgents(itemtype   IN      VARCHAR2,
                      itemkey    IN      VARCHAR2,
                      actid      IN      NUMBER,
                      funcmode   IN      VARCHAR2,
                      resultout  IN OUT  VARCHAR2)

IS

  localSystem  VARCHAR2(2000);
  agentName    VARCHAR2(2000);

BEGIN

    -- Retrieve the agent name
    SELECT name INTO localSystem
    FROM wf_systems
    WHERE guid = wf_core.translate('WF_SYSTEM_GUID');
    agentName := 'ECM_IN@' || localSystem;

    -- Set ECMINQUEUE workflow attribute
    wf_engine.setItemAttrText(itemtype, 
                              itemkey, 
                              'ECMINQUEUE', 
                              agentName);

    -- Set result string
    resultout := wf_engine.eng_completed || ':' || wf_engine.eng_null;

EXCEPTION

  WHEN OTHERS THEN
    Wf_Core.Context('Wf_Standard', 
                    'SetUpAgents', 
                    itemtype,
                    itemkey, 
                    to_char(actid), 
                    funcmode);
    RAISE;

END SetUpAgents;


-- VoteForResultType
--   Standard Voting function
-- IN
--   itemtype  - A valid item type from (WF_ITEM_TYPES table).
--   itemkey   - A string generated from the application object's primary key.
--   actid     - The process activity(instance id).
--   funcmode  - Run/Cancel
-- OUT
--   comparison result (WFSTD_COMPARISON lookup code)
--
-- ACTIVITY ATTRIBUTES REFERENCED
--      VOTING_OPTION
--          - WAIT_FOR_ALL_VOTES  - Evaluate voting after all votes are cast
--                                - or a Timeout condition closes the voting
--                                - polls.  When a Timeout occurs the
--                                - voting percentages are calculated as a
--                                - percentage ofvotes cast.
--
--          - REQUIRE_ALL_VOTES   - Evaluate voting after all votes are cast.
--                                - If a Timeout occurs and all votes have not
--                                - been cast then the standard timeout
--                                - transition is taken.  Votes are calculated
--                                - as a percenatage of users notified to vote.
--
--          - TALLY_ON_EVERY_VOTE - Evaluate voting after every vote or a
--                                - Timeout condition closes the voting polls.
--                                - After every vote voting percentages are
--                                - calculated as a percentage of user notified
--                                - to vote.  After a timeout voting
--                                - percentages are calculated as a percentage
--                                - of votes cast.
--
--      "One attribute for each of the activities result type codes"
--
--          - The standard Activity VOTEFORRESULTTYPE has the WFSTD_YES_NO
--          - result type assigned.
--          - Thefore activity has two activity attributes.
--
--                  Y       - Percenatage required for Yes transition
--                  N       - Percentage required for No transition
--
PROCEDURE VoteForResultType(itemtype   IN      VARCHAR2,
                            itemkey    IN      VARCHAR2,
                            actid      IN      NUMBER,
                            funcmode   IN      VARCHAR2,
                            resultout  IN OUT  VARCHAR2)

IS

  -- Select all lookup codes for an activities result type
  CURSOR result_codes IS
  SELECT  wfl.lookup_code result_code
  FROM    wf_lookups wfl,
          wf_activities wfa,
          wf_process_activities wfpa,
          wf_items wfi
  WHERE   wfl.lookup_type         = wfa.result_type
  AND     wfa.name                = wfpa.activity_name
  AND     wfi.begin_date          >= wfa.begin_date
  AND     wfi.begin_date          < nvl(wfa.end_date,wfi.begin_date+1)
  AND     wfpa.activity_item_type = wfa.item_type
  AND     wfpa.instance_id        = actid
  AND     wfi.item_key            = itemkey
  AND     wfi.item_type           = itemtype;

  wf_invalid_command        EXCEPTION;
  responseMessage           wf_event_t;
  outAgent                  wf_agent_t;
  notification_group_id     PLS_INTEGER;
  vote_number_cast          PLS_INTEGER;
  vote_percentage_max       PLS_INTEGER := 0;
  notid                     NUMBER;
  vote_percentage           NUMBER;
  vote_percentage_current   NUMBER;
  vote_percentage_total     NUMBER;
  vote_percentage_required  NUMBER;
  voting_option             VARCHAR2(2000);
  notification_user         VARCHAR2(2000);
  setting                   VARCHAR2(2000);  
  l_responder               VARCHAR2(2000);
  comments                  VARCHAR2(2000);
  resultstring              VARCHAR2(2000);
  localSystem               VARCHAR2(2000);
  desired_result_code       VARCHAR2(2000) := '';
  default_result_code       VARCHAR2(2000) := '';
BEGIN

  -- Setup the user response message
  IF (funcmode = 'RESPOND') THEN

    -- Retrieve notification id and responder
    notid := wf_engine.context_nid;


    -- Retrieve the responder name.
    --  In case of e-mail approvals the context_text will not
    --  contain the user name.

    SELECT recipient_role INTO l_responder
    FROM  wf_notifications n
    WHERE n.notification_id = notid;

--    l_responder := wf_engine.context_text;

    -- Retrieve responder comments
    SELECT text_value INTO comments
    FROM   wf_notifications n, wf_notification_attributes na
    WHERE  n.notification_id = na.notification_id
    AND    n.notification_id = notid
    AND    na.name = 'IFS_ECM_WORKFLOW_USERCOMMENTS';

    -- Default value for comments
    IF(comments = NULL) THEN

       comments := '-';

    END IF;

    -- Retrieve result string
    SELECT text_value INTO resultstring
    FROM   wf_notifications n, wf_notification_attributes na
    WHERE  n.notification_id = na.notification_id
    AND    n.notification_id = notid
    AND    na.name = 'RESULT';

    -- Compose the response message
    wf_event_t.initialize(responseMessage);
    responseMessage.setEventName('IFS_ECM_WORKFLOW_MSG_RESPONSE');
    responseMessage.addParameterToList('IFS_ECM_WORKFLOW_PROCESSID', 
                                       itemkey);
    responseMessage.addParameterToList('IFS_ECM_WORKFLOW_RESPONDER', 
                                       l_responder);
    responseMessage.addParameterToList('IFS_ECM_WORKFLOW_COMMENT', 
                                       comments);
    responseMessage.addParameterToList('IFS_ECM_WORKFLOW_RESULT', 
                                       resultString);

    -- Retrieve the agent name
    SELECT name INTO localSystem
    FROM wf_systems
    WHERE guid = wf_core.translate('WF_SYSTEM_GUID');
    outAgent := wf_agent_t('ECM_IN', localSystem);

    -- Set agent name in response message
    responseMessage.setToAgent(outAgent);

    -- Send the user response message
    wf_event.send(responseMessage);

  END IF;

  -- Setup the escalation response message
  IF (funcmode = wf_engine.eng_timeout) THEN

    -- Retrieve the responder name.
    --  In case of e-mail approvals the context_text will not
    --  contain the user name.

    SELECT recipient_role INTO l_responder
    FROM  wf_notifications n
    WHERE n.notification_id = notid;

    -- l_responder := wf_engine.context_text;

    -- Compose the response message
    wf_event_t.initialize(responseMessage);
    responseMessage.setEventName('IFS_ECM_ESCALATION_RESPONSE');
    responseMessage.addParameterToList('IFS_ECM_WORKFLOW_PROCESSID',
                                       itemkey);
    responseMessage.addParameterToList('IFS_ECM_WORKFLOW_RESPONDER',
                                       l_responder);    

    -- Retrieve the agent name
    SELECT name INTO localSystem
    FROM wf_systems
    WHERE guid = wf_core.translate('WF_SYSTEM_GUID');
    outAgent := wf_agent_t('ECM_IN', localSystem);

    -- Set agent name in response message
    responseMessage.setToAgent(outAgent);

    -- Send the escalation response message
    wf_event.send(responseMessage);

  END IF;

  -- Return null if not in RUN or TIMEOUT mode
  IF  (funcmode <> wf_engine.eng_run)     AND 
      (funcmode <> wf_engine.eng_timeout) THEN

    resultout := wf_engine.eng_null;
    RETURN;

  END IF;  

  -- WF Sync mode is not allowed
  IF (itemkey = wf_engine.eng_synch) THEN

    Wf_Core.Token('OPERATION', 'Wf_Standard.VotForResultType');
    Wf_Core.Raise('WFENG_SYNCH_DISABLED');

  END IF;

  -- Retrieve notification group id
  -- Used for checking if there are any open notifications
  Wf_Item_Activity_Status.Notification_Status(itemtype, 
                                              itemkey, 
                                              actid, 
                                              notification_group_id, 
                                              notification_user);

  
  -- Raise error if the voting option is selected incorrectly
  voting_option := Wf_Engine.GetActivityAttrText(itemtype, 
                                                 itemkey, 
                                                 actid, 
                                                 'VOTING_OPTION');
  IF (voting_option NOT IN ('REQUIRE_ALL_VOTES', 
                            'WAIT_FOR_ALL_VOTES',
                            'TALLY_ON_EVERY_VOTE')) THEN

    RAISE wf_invalid_command;

  END IF;

  
  -- If the mode is REQUIRE_ALL_VOTES and
  -- there are open notifications, then
  -- return WAITING to continue voting
  IF (voting_option = 'REQUIRE_ALL_VOTES')                           AND 
     (wf_notification.OpenNotificationsExist(notification_group_id)) THEN

    resultout := wf_engine.eng_waiting;
    RETURN;

  END IF;

  
  -- If the mode is WAIT_FOR_ALL_VOTES and
  -- no timeout has occured and
  -- there are open notifications, then
  -- return WAITING to continue voting
  IF (voting_option = 'WAIT_FOR_ALL_VOTES')                          AND 
     (funcmode = wf_engine.eng_run)                                  AND 
     (wf_notification.OpenNotificationsExist(notification_group_id)) THEN

    resultout := wf_engine.eng_waiting;
    RETURN;

  END IF;
  
  -- If here, then the mode is one of:
  --   a. TALLY_ON_ALL_VOTES
  --   b. WAIT_FOR_ALL_VOTES and timeout has occurred
  --   c. WAIT_FOR_ALL_VOTES and all votes are cast
  --   d. REQUIRE_ALL_VOTES and all votes are cast
  -- Cycle through the result types 
  FOR result_rec IN result_codes LOOP
    
    -- Count the votes that are cast for this result type
    -- vote_percentage_cast - Number of responses for this result type
    -- vote_percentage_total -  % ResultType ( As a % of total population )
    -- vote_percentage_current - % ResultType ( As a % of votes cast )
    Wf_Notification.VoteCount(notification_group_id, 
                              result_rec.result_code, 
                              vote_number_cast, 
                              vote_percentage_total,
                              vote_percentage_current);


    -- Use the % of total possible votes
    vote_percentage := vote_percentage_total;

    -- Round to 4 digits
    vote_percentage := round(vote_percentage, 4);
    
    -- Get the required voting percentage for this result type
    vote_percentage_required := Wf_Engine.GetActivityAttrNumber(
                                                       itemtype, 
                                                       itemkey,
                                                       actid,
                                                       result_rec.result_code);
    
  
    -- If the required voting percentage has been specified, then
    -- set the desired result code
    IF (vote_percentage_required IS NOT NULL) THEN

      -- If at least one vote has been cast and
      -- Voting percentage >= Required voting percentage or 
      -- All votes have been cast
      IF (vote_number_cast > 0)                         AND 
         ((vote_percentage >= vote_percentage_required) OR 
          (vote_percentage = 100))                      THEN

        -- If desired result code has not been stored, then
        -- save the current result code
        IF (desired_result_code IS NULL) THEN

          desired_result_code := result_rec.result_code;

        -- Tie has occured since desired result code is already stored
        ELSE

          resultout := wf_engine.eng_completed || ':' || wf_engine.eng_tie;
          RETURN;

        END IF;  

      END IF;

    -- Use the result code that has the maximum number of votes  
    ELSE

      -- If the current voting percentage is greater than the highest recorded,
      -- then use this result code as the default
      IF (vote_percentage > vote_percentage_max) THEN

        vote_percentage_max := vote_percentage;
        default_result_code := result_rec.result_code;

      -- If the current voting percentage is equal to the highest recorded,
      -- then set TIE result code as the default
      ELSIF (vote_percentage = vote_percentage_max) THEN

        default_result_code := wf_engine.eng_tie;

      END IF;

    END IF;

  END LOOP;
  
  -- Use desired result code if one is found
  IF (desired_result_code IS NOT NULL) THEN

    resultout := wf_engine.eng_completed || ':' || desired_result_code;

  -- Desired result code is not determined
  ELSE

    -- If timeout has not occured and
    -- there are open notifications, then
    -- return WAITING to continue voting
    IF (funcmode = wf_engine.eng_run)                                  AND 
       (wf_notification.OpenNotificationsExist(notification_group_id)) THEN

      resultout := wf_engine.eng_waiting;

    -- Use the default result if one is found
    ELSIF (default_result_code IS NOT NULL) THEN

      resultout := wf_engine.eng_completed || ':' || default_result_code;

    -- If timeout has occured, 
    -- then return TIMEOUT
    ELSIF (funcmode =  wf_engine.eng_timeout) THEN

      resultout := wf_engine.eng_completed || ':' || wf_engine.eng_timedout;

    -- Return NOMATCH
    ELSE

      resultout := wf_engine.eng_completed || ':' || wf_engine.eng_nomatch;

    END IF;

  END IF;

  RETURN;

EXCEPTION

  WHEN wf_invalid_command THEN
    Wf_Core.Context('Wf_Standard', 
                    'VoteForResultType', 
                    itemtype, 
                    itemkey, 
                    to_char(actid), 
                    funcmode);
    Wf_Core.Token('COMMAND', 
                  voting_option);
    Wf_Core.Raise('WFSQL_COMMAND');

  WHEN OTHERS THEN
    Wf_Core.Context('Wf_Standard', 
                    'VoteForResultType',
                    itemtype, 
                    itemkey, 
                    to_char(actid), 
                    funcmode);
    RAISE;

END VoteForResultType;


-- GetNextApprover
--   Compare a property on an event
-- IN
--   itemtype  - item type
--   itemkey   - item key
--   actid     - process activity instance id
--   funcmode  - execution mode
-- OUT
--   comparison result (WFSTD_COMPARISON lookup code)
--   GT LT EQ NULL
-- ACTIVITY ATTRIBUTES REFERENCED
--   EVENT     - Event whose property is to be compared
--   PROPERTY  - Event Property Reference (Based on the lookup of EVENTPROPERTY
--   PARAMETER - Parameter Name if Lookup type = Parameter
--   VALUE     - Constant value of correct type
PROCEDURE GetNextApprover(itemtype   IN      VARCHAR2,
                          itemkey    IN      VARCHAR2,
                          actid      IN      NUMBER,
                          funcmode   IN      VARCHAR2,
                          resultout  IN OUT  VARCHAR2)

IS

  ApproverNumber NUMBER;
  StartPosition  NUMBER;
  EndPosition    NUMBER;
  delim          VARCHAR2(2000);
  NextApprover   VARCHAR2(2000);
  rdname         VARCHAR2(2000);
  rname          VARCHAR2(2000);
  Approvers      VARCHAR2(2000);

BEGIN

  -- Retrieve the list of responders
  Approvers := wf_engine.getItemAttrText(itemtype, 
                                         itemkey, 
                                         'IFS_ECM_WORKFLOW_RESPONDERS');
  Approvers := trim(Approvers);

  -- Retrieve the current approver number
  ApproverNumber := wf_engine.getItemAttrNumber(itemtype, 
                                                itemkey, 
                                                'APPROVERNUMBER');
  -- Default value for next approver
  NextApprover := 'NULLUSER';
 
  -- Delimiter used by workflow
  delim := ' ';
 
  -- At least one approver is required
  IF (ApproverNumber >= 1) THEN

    -- Determine the start position
    IF (ApproverNumber = 1) THEN

      StartPosition := 0;

    ELSE

      StartPosition := instr(Approvers, delim, 1, ApproverNumber - 1);

    END IF;
     
    -- Determine the next approver
    IF (ApproverNumber != 1 AND StartPosition = 0)  THEN

      NULL;

    ELSE

      EndPosition := instr(Approvers, delim, 1, ApproverNumber);
      IF (EndPosition = 0) THEN

        NextApprover := substr(Approvers, 
                               StartPosition+1);

      ELSE

        NextApprover := substr(Approvers,
                               StartPosition+1, 
                               EndPosition - StartPosition - 1);

      END IF;

    END IF;

  END IF;

  -- Replace ';' in the usernames with spaces
  NextApprover := replace(NextApprover, ';', ' ');

  -- Increment approver number
  ApproverNumber := ApproverNumber + 1;
  
  -- Set NEXTAPPROVER workflow attribute 
  wf_engine.setItemAttrText(itemtype, 
                            itemkey, 
                            'NEXTAPPROVER', 
                            NextApprover);

  -- Set APPROVERNUMBER workflow attribute
  wf_engine.setItemAttrNumber(itemtype, 
                              itemkey, 
                              'APPROVERNUMBER', 
                              ApproverNumber);

  -- Set result string
  resultout := wf_engine.eng_completed || ':' || wf_engine.eng_null;

EXCEPTION

  WHEN OTHERS THEN
    Wf_Core.Context('Wf_Standard', 
                    'GetNextApprover', 
                    itemtype,
                    itemkey, 
                    to_char(actid), 
                    funcmode);
    RAISE;

END GetNextApprover;

END ECM_FA;
/

show errors;

exit;

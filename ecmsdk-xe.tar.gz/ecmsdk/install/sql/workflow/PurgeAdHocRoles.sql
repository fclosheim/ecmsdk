set serveroutput on;

begin
wf_purge.AdHocDirectory();
end;
/

commit;
exit;


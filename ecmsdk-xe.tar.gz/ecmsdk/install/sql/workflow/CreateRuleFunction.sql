set autocommit off;
set echo on;

create or replace package ECM_RF as
		FUNCTION AbortFunction(p_subscription_guid in     raw,
       			               p_event             in out wf_event_t) return varchar2;
		FUNCTION SendNotificationID(p_subscription_guid in     raw,
                		            p_event             in out wf_event_t) return varchar2;
end ECM_RF;
/

show errors;


create or replace package body ECM_RF as

FUNCTION AbortFunction(p_subscription_guid in     raw,
                      p_event             in out wf_event_t) return varchar2
is
  out_guid  raw(16);
  to_guid   raw(16);
  wftype    varchar2(30);
  wfname    varchar2(30);
  res       varchar2(30);
  pri       number;
  ikey      varchar2(240);
  eventName  varchar2(30);
  eventKey   varchar2(30);
  coId       varchar2(30);
  returnValue varchar2(30);
begin

  select wf_process_type, wf_process_name
  into   wftype, wfname
  from   wf_event_subscriptions
  where  guid = p_subscription_guid;

  eventName := p_event.getEventName();
  eventKey := p_event.getEventKey();
  coId := p_event.getCorrelationId();

  wf_engine.AbortProcess(
       itemtype      => wftype, 
       itemkey       => coId,                       
       process  => wfname, 
       result => returnValue);

  return returnValue;
exception
  when others then
    wf_core.context('Wf_Rule', 'Default_Rule', p_event.getEventName(),
                                                p_subscription_guid);
    wf_event.setErrorInfo(p_event, 'ERROR');
    return 'ERROR';
end;

FUNCTION SendNotificationID(p_subscription_guid in     raw,
                            p_event             in out wf_event_t) return varchar2

is
  l_parameter_list wf_parameter_list_t;
  notification_id number;
  pos number := 1;
  request_id varchar2(100);
  eventdata wf_event_t;
  responseMesECM wf_event_t;
  l_responder varchar2(1000);
  outAgent             wf_agent_t;
  localSystem          varchar2(40);

begin

  l_parameter_list:= p_event.getParameterList();

  -- Get the  arguments
  pos := l_parameter_list.LAST;
  while(pos is not null) loop
    if (l_parameter_list(pos).getName() = 'NOTIFICATION_ID') then
     notification_id  := to_number(l_parameter_list(pos).getValue());
    elsif (l_parameter_list(pos).getName() = 'ROLE') then
     l_responder := l_parameter_list(pos).getValue();
    end if;

    pos := l_parameter_list.PRIOR(pos);

  end loop;

  begin
    eventdata := wf_notification_util.GetAttrEvent(notification_id,'EVENT');
    exception
     when others then
     return 'SUCCESS';
  end;

  if (eventdata is not null) then
    wf_event_t.initialize(responseMesECM);
    responseMesECM.setEventName('IFS_ECM_WORKFLOW_NID');
    responseMesECM.addParameterToList('IFS_ECM_WORKFLOW_PROCESSID', eventdata.getcorrelationid());
    responseMesECM.addParameterToList('IFS_ECM_WORKFLOW_RESPONDER',l_responder);
    responseMesECM.addParameterToList('IFS_ECM_WORKFLOW_NID',to_char(notification_id));
    select name into localSystem
        from wf_systems
            where guid = wf_core.translate('WF_SYSTEM_GUID');
    outAgent := wf_agent_t('ECM_IN', localSystem);
    responseMesECM.setToAgent(outAgent);
    wf_event.send(responseMesECM);

  end if;
   return 'SUCCESS';
   exception
   when others then
    wf_core.context('Wf_Rule', 'Default_Rule', p_event.getEventName(),
                                                p_subscription_guid);

  wf_event.setErrorInfo(p_event, 'ERROR');
    return 'ERROR';
 
end;

END ECM_RF;
/
show errors;

exit;


declare
    job binary_integer;
begin
    dbms_job.submit(job, 'wf_event.listen(''ECM_OUT'');');

    dbms_job.Interval( job=>job,
    interval=>'Wf_Setup.JobNextRunDate('||to_char(job)||','||
              to_char(0)||','||
              to_char(0)||','||
              to_char(0)||','||
              to_char(&1)||')'
  );

end;
/
exit;


    


Rem Copyright (c) 2004, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    SetupLykeSyncJobs.sql - Setup DBMS jobs to sync lyke index. 
Rem  USAGE
Rem    sqlplus <ifs-schema-name>/<password> @SetupLykeSyncJobs <ifs-schema-name>
Rem
Rem  History:
Rem    25-mar-04 (vdevadha)
Rem       Created. 
Rem    14-jul-04 (vdevadha)
Rem       fixed typo. 

declare
    job binary_integer;
begin
    dbms_job.submit(job=>job, 
      what=>'ctx_substr.indexsync(''&1'', ''IFS_LYKE'', 64, 0, 0);',
    next_date=>trunc(SYSDATE, 'HH') +(1/24),
    interval=>'SYSDATE +((1/24) * (1/6))');
end;
/
exit;



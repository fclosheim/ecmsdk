REM Copyright (c) 2004, 2008, Oracle. All rights reserved.  
REM
REM    NAME
REM      Upgrade10gRevokeConnectOnDrSchema.sql - upgrade to provide additional
REM      priviledges now omitted by 10g R2.
REM
REM   History
REM     08-sep-04 (pyoung)
REM        created.
REM     31-may-05 (sgarg)
REM        removed references to $dr schema

whenever sqlerror exit sql.sqlcode;
set serveroutput on

prompt Revoking Connect role from CM SDK schema

REM REVOKE CONNECT FROM &1$dr;

whenever sqlerror exit 0;

exit;



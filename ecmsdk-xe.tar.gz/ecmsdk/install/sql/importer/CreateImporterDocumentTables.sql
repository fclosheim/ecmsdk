Rem Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
Rem All rights reserved. 
Rem
Rem  NAME
Rem    CreateImporterDocumentTables.sql - create tables related to 
Rem    documents, content, and version families in the importer schema.
Rem
Rem History:
Rem     05-feb-07 (dlong)
Rem         Created.
Rem     09-jul-07 (dlong)
Rem         Added 3 columns for retention & lifecycle specification.
Rem     19-feb-08 (dlong)
Rem         Added autofolderingpolicy column.
Rem     01-apr-08 (dlong)
Rem         Added cdb_lifecyclepolicy table.
Rem     03-apr-08 (dlong)
Rem         Added cdb_document_idmap table.
Rem     25-apr-08 (dlong)
Rem         ID declared as not null.
Rem     09-may-08 (dlong)
Rem         called with schema arg.
Rem     13-jan-09 (dlong)
Rem         add status and errorcount columns to cdb_document.
Rem     22-apr-09 (dlong)
Rem         add cdb_lifecyclepolicyentry.


whenever sqlerror exit sql.sqlcode

Prompt create Document tables and indexes
CREATE TABLE &1..cdb_document
(
    seq             NUMBER(20)      PRIMARY KEY
  , exid            VARCHAR2(2000)  NOT NULL
  , id              NUMBER(20)      DEFAULT 0 NOT NULL
  , name            VARCHAR2(700)
  , description     VARCHAR2(2000)
  , createdate      NUMBER(20) 
  , creator         VARCHAR2(256) 
  , lastmodifydate  NUMBER(20) 
  , lastmodifier    VARCHAR2(256) 
  , lifecyclepolicy VARCHAR2(700)
  , retentionpolicy VARCHAR2(700)
  , lifecycledate   NUMBER(20)
  , autofolderingpolicy VARCHAR2(700)
  , parentexid      VARCHAR2(2000)
  , familyexid      VARCHAR2(2000)
  , securityexid    VARCHAR2(2000)
  , contentexid     VARCHAR2(2000)  NOT NULL
  , versionnumber   NUMBER(20) 
  , versionlabel    VARCHAR2(700) 
  , checkincomments VARCHAR2(2000) 
  , status          NUMBER(10)
  , errorcount      NUMBER(10)
);

CREATE UNIQUE INDEX &1..cdbi_document_exid_uni ON &1..cdb_document
(
    exid
);

CREATE INDEX &1..cdbi_document_id ON &1..cdb_document
(
    id
);

CREATE INDEX &1..cdbi_document_content ON &1..cdb_document
(
    contentexid
);

CREATE INDEX &1..cdbi_document_family ON &1..cdb_document
(
    familyexid
);

CREATE INDEX &1..cdbi_document_parent ON &1..cdb_document
(
    parentexid
);

Prompt create table used as an ID map for cdb_document
CREATE TABLE &1..cdb_document_idmap
(
    exid            VARCHAR2(2000)  PRIMARY KEY
  , id              NUMBER(20)      NOT NULL
);

CREATE UNIQUE INDEX &1..cdb_document_idmap_id_uni ON &1..cdb_document_idmap
(
    id
);

Prompt create Content tables and indexes
CREATE TABLE &1..cdb_content
(
    seq              NUMBER(20)      PRIMARY KEY
  , exid             VARCHAR2(2000)  NOT NULL
  , id               NUMBER(20)      DEFAULT 0 NOT NULL
  , formatname       VARCHAR2(700)
  , contentsize      NUMBER(20) 
  , bfilelocation    VARCHAR2(2000)
  , midtierlocation  VARCHAR2(2000)
  , characterset     VARCHAR2(40)
  , language         VARCHAR2(40)
);

CREATE UNIQUE INDEX &1..cdbi_content_exid_uni ON &1..cdb_content
(
    exid
);

CREATE INDEX &1..cdbi_content_id ON &1..cdb_content
(
    id
);

Prompt create VersionSeries (family) tables and indexes
CREATE TABLE &1..cdb_versionfamily
(
    seq             NUMBER(20)      PRIMARY KEY
  , exid            VARCHAR2(2000)  NOT NULL
  , id              NUMBER(20)      DEFAULT 0 NOT NULL
  , name            VARCHAR2(700)
  , description     VARCHAR2(2000)
  , createdate      NUMBER(20) 
  , creator         VARCHAR2(256) 
  , lastmodifydate  NUMBER(20) 
  , lastmodifier    VARCHAR2(256) 
  , parentexid      VARCHAR2(2000)
  , securityexid    VARCHAR2(2000)
  , versionlimit    NUMBER(20)
);

CREATE UNIQUE INDEX &1..cdbi_versionfamily_exid_uni ON &1..cdb_versionfamily
(
    exid
);

CREATE INDEX &1..cdbi_versionfamily_id ON &1..cdb_versionfamily
(
    id
);

CREATE INDEX &1..cdbi_versionfamily_parent ON &1..cdb_versionfamily
(
    parentexid
);

Prompt create LifecyclePolicy tables and indexes
CREATE TABLE &1..cdb_lifecyclepolicy
(
    seq             NUMBER(20)      PRIMARY KEY
  , id              NUMBER(20)      DEFAULT 0 NOT NULL
  , name            VARCHAR2(700)   NOT NULL
  , description     VARCHAR2(2000)
  , lockimplied     NUMBER(1)       DEFAULT 0
  , action1         VARCHAR2(700)
  , action2         VARCHAR2(700)
  , action3         VARCHAR2(700)
  , action4         VARCHAR2(700)
  , timeperiod1     VARCHAR2(32)
  , timeperiod2     VARCHAR2(32)
  , timeperiod3     VARCHAR2(32)
  , timeperiod4     VARCHAR2(32)
);

CREATE UNIQUE INDEX &1..cdbi_lifecyclepolicy_name ON &1..cdb_lifecyclepolicy
(
    name
);

CREATE TABLE &1..cdb_lifecyclepolicyentry
(
  policyname            VARCHAR2(700)   NOT NULL
  , name                VARCHAR2(700)
  , description         VARCHAR2(2000)
  , lifecyclesequence   NUMBER(10)
  , enabled             NUMBER(1)
  , frozen              NUMBER(1)
  , action              VARCHAR2(700)
  , timeperiod          VARCHAR2(32)
);

commit;


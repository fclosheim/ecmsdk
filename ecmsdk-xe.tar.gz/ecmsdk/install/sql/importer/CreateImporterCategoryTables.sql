Rem Copyright (c) 2006, 2008, Oracle. All rights reserved.
Rem
Rem  NAME
Rem    CreateImporterCategoryTables.sql - create tables related to
Rem    categories in the importer schema.
Rem
Rem History:
Rem     22-feb-07 (dlong)
Rem         Created.
Rem     25-apr-08 (dlong)
Rem         ID declared as not null.
Rem     09-may-08 (dlong)
Rem         called with schema arg.

whenever sqlerror exit sql.sqlcode

Prompt create Category tables and indexes
CREATE TABLE &1..cdb_category
(
    seq             NUMBER(20)      PRIMARY KEY
  , catname         VARCHAR2(700)   NOT NULL
  , id              NUMBER(20)      DEFAULT 0 NOT NULL
  , name            VARCHAR2(700)
  , description     VARCHAR2(2000)
  , assocdocexid    VARCHAR2(2000)
  , assocfolderexid VARCHAR2(2000)
  , assoclinkexid   VARCHAR2(2000)
);

Prompt Note: for each distinct category referenced, there must
Prompt exist a table in the importer schema to match
Prompt The name of the table and the attributes are mapped 
Prompt in the cdb_categoryclass and cdb_categoryattribute tables

CREATE INDEX &1..cdbi_cat_docid_uni ON &1..cdb_category
(
    assocdocexid
);

CREATE INDEX &1..cdbi_cat_folderid_uni ON &1..cdb_category
(
    assocfolderexid
);

CREATE INDEX &1..cdbi_cat_linkid_uni ON &1..cdb_category
(
    assoclinkexid
);

Prompt create Category class and attribute mapping tables
CREATE TABLE &1..cdb_categoryclass
(
    catname         VARCHAR2(700)   PRIMARY KEY
  , tablename       VARCHAR2(30)    NOT NULL
);

CREATE TABLE &1..cdb_categoryattribute
(
    catname         VARCHAR2(700)   NOT NULL
  , attrname        VARCHAR2(700)   NOT NULL
  , columnname      VARCHAR2(30)    NOT NULL
);

commit;


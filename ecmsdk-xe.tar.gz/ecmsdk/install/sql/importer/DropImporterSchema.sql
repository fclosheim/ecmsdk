Rem Copyright (c) 2006, 2008, Oracle. All rights reserved.
Rem
Rem  NAME
Rem    DropImporterSchema.sql - drop the 
Rem    importer schema used to populate a Content DB instance.
Rem
Rem History:
Rem     07-jan-07 (dlong)
Rem         Created.
Rem     09-feb-07 (dlong)
Rem         Added documents
Rem     17-feb-07 (dlong)
Rem         Added links
Rem     22-feb-07 (dlong)
Rem         Added categories
Rem     15-may-07 (dlong)
Rem         Added parameter table

whenever sqlerror continue

DROP SEQUENCE cdb_id_seq;

@DropImporterUserTables.sql
@DropImporterGroupTables.sql
@DropImporterFolderTables.sql
@DropImporterSecurityTables.sql
@DropImporterDocumentTables.sql
@DropImporterLinkTables.sql
@DropImporterCategoryTables.sql
@DropImporterParameterTables.sql

commit;
exit;


Rem Copyright (c) 2006, 2009, Oracle and/or its affiliates.
Rem All rights reserved. 
Rem
Rem  NAME
Rem    CreateImporterFolderTables.sql - create tables related to folders
Rem    in the importer schema.
Rem
Rem History:
Rem     16-jan-07 (dlong)
Rem         Created.
Rem     03-apr-07 (dlong)
Rem         Added deletepending column.
Rem     25-apr-08 (dlong)
Rem         ID declared as not null.
Rem     09-may-08 (dlong)
Rem         called with schema arg.
Rem     13-feb-09 (dlong)
Rem         remove index on {idgroup, id, exid}

whenever sqlerror exit sql.sqlcode

Prompt create Folder tables and indexes
CREATE TABLE &1..cdb_folder
(
    seq             NUMBER(20)      PRIMARY KEY
  , exid            VARCHAR2(2000)  NOT NULL
  , id              NUMBER(20)      DEFAULT 0 NOT NULL
  , name            VARCHAR2(700)
  , description     VARCHAR2(2000)
  , createdate      NUMBER(20) 
  , creator         VARCHAR2(256) 
  , lastmodifydate  NUMBER(20) 
  , lastmodifier    VARCHAR2(256) 
  , parentexid      VARCHAR2(2000)
  , securityexid    VARCHAR2(2000)
  , iscontainer     NUMBER(1)
  , isworkspace     NUMBER(1)
  , pwuserexid      VARCHAR2(256)
  , deletepending   NUMBER(1)
  , idgroup         NUMBER(10) 
);

CREATE UNIQUE INDEX &1..cdbi_folder_exid_uni ON &1..cdb_folder
(
    exid
);

CREATE INDEX &1..cdbi_folder_id ON &1..cdb_folder
(
    id
);

CREATE INDEX &1..cdbi_folder_pexid ON &1..cdb_folder
(
    parentexid
);

commit;


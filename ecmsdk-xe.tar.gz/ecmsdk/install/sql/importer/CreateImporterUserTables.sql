Rem Copyright (c) 2006, 2008, Oracle. All rights reserved.
Rem
Rem  NAME
Rem    CreateImporterUserTables.sql - create tables related to users
Rem    in the importer schema.
Rem
Rem History:
Rem     15-jan-07 (dlong)
Rem         Created.
Rem     25-apr-08 (dlong)
Rem         ID declared as not null.
Rem     09-may-08 (dlong)
Rem         called with schema arg.

whenever sqlerror exit sql.sqlcode

Prompt create User tables and indexes
CREATE TABLE &1..cdb_user
(
    seq        NUMBER(20)      PRIMARY KEY
  , exid       VARCHAR2(256)   NOT NULL
  , id         NUMBER(20)      DEFAULT 0 NOT NULL
  , name       VARCHAR2(700)
  , dn         VARCHAR2(700)
);

INSERT into &1..cdb_user (seq, exid, id, name, dn) 
       values (&1..cdb_id_seq.nextval, 'ECM.SystemUser', 96, null, null);

CREATE UNIQUE INDEX &1..cdbi_user_exid_uni ON &1..cdb_user
(
    exid
);

CREATE INDEX &1..cdbi_user_id ON &1..cdb_user
(
    id
);

commit;


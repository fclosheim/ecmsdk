Rem Copyright (c) 2006, 2008, Oracle. All rights reserved.
Rem
Rem  NAME
Rem    DropImporterDocumentTables.sql - drop tables related to 
Rem    documents, content, and version families from the importer schema.
Rem
Rem History:
Rem     09-feb-07 (dlong)
Rem         Created.
Rem     01-apr-08 (dlong)
Rem         Drop lifecycle policy table
Rem     03-apr-08 (dlong)
Rem         Drop cdb_document_idmap table

whenever sqlerror continue

Prompt drop document, family, and content tables
DROP TABLE cdb_document;
DROP TABLE cdb_document_idmap;
DROP TABLE cdb_content;
DROP TABLE cdb_versionfamily;
DROP TABLE cdb_lifecyclepolicy;

commit;


Rem Copyright (c) 2006, 2008, Oracle. All rights reserved.
Rem
Rem  NAME
Rem    DropImporterParameterTables.sql - drop tables related to 
Rem    importer schema parameters.
Rem
Rem History:
Rem     15-may-07 (dlong)
Rem         Created.
Rem     09-jun-07 (dlong)
Rem         Added handler registration table
Rem     01-apr-08 (dlong)
Rem         Drop notification and directive tables

whenever sqlerror continue

Prompt drop parameter tables
DROP TABLE cdb_parameter;
DROP TABLE cdb_notification;
DROP TABLE cdb_directive;
DROP TABLE cdb_handler;
DROP PROCEDURE NotifyAllHandlers;
DROP PROCEDURE NotifyDocumentHandlers;
DROP PROCEDURE NotifyNonDocumentHandlers;

commit;


Rem Copyright (c) 2006, 2008, Oracle. All rights reserved.
Rem
Rem  NAME
Rem    DropImporterCategoryTables.sql - drop tables related to 
Rem    categories from the importer schema.
Rem
Rem History:
Rem     22-feb-07 (dlong)
Rem         Created.

whenever sqlerror continue

Prompt drop category tables
DROP TABLE cdb_category;
DROP TABLE cdb_categoryclass;
DROP TABLE cdb_categoryattribute;

commit;


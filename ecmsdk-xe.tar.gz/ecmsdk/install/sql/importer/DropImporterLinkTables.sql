Rem Copyright (c) 2006, 2008, Oracle. All rights reserved.
Rem
Rem  NAME
Rem    DropImporterLinkTables.sql - drop tables related to 
Rem    links from the importer schema.
Rem
Rem History:
Rem     22-feb-07 (dlong)
Rem         Created.

whenever sqlerror continue

Prompt drop link tables
DROP TABLE cdb_link;

commit;


Rem Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
Rem All rights reserved. 
Rem
Rem  NAME
Rem    CreateImporterSequences.sql - create sequences in the importer schema.
Rem
Rem History:
Rem     06-jul-09 (dlong)
Rem         Created.
Rem     15-oct-09 (dlong)
Rem         Add cdb_docid_seq.

whenever sqlerror exit sql.sqlcode

Prompt create cdb_id_seq sequence
CREATE SEQUENCE &1..cdb_id_seq
                START WITH      1000
                INCREMENT BY    1
                NOMAXVALUE
                NOCYCLE
                CACHE           200;

Prompt create cdb_docid_seq sequence
CREATE SEQUENCE &1..cdb_docid_seq
                START WITH      1000
                INCREMENT BY    1
                NOMAXVALUE
                NOCYCLE
                CACHE           200;





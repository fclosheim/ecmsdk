Rem Copyright (c) 2006, 2008, Oracle. All rights reserved.
Rem
Rem  NAME
Rem    CreateImporterLinkTables.sql - create tables related to links
Rem    in the importer schema.
Rem
Rem History:
Rem     17-feb-07 (dlong)
Rem         Created.
Rem     25-apr-08 (dlong)
Rem         ID declared as not null.
Rem     09-may-08 (dlong)
Rem         called with schema arg.

whenever sqlerror exit sql.sqlcode

Prompt create Link tables and indexes
CREATE TABLE &1..cdb_link
(
    seq             NUMBER(20)      PRIMARY KEY
  , exid            VARCHAR2(2000)  NOT NULL
  , id              NUMBER(20)      DEFAULT 0 NOT NULL
  , name            VARCHAR2(700)
  , description     VARCHAR2(2000)
  , createdate      NUMBER(20) 
  , creator         VARCHAR2(256) 
  , lastmodifydate  NUMBER(20) 
  , lastmodifier    VARCHAR2(256) 
  , parentexid      VARCHAR2(2000)
  , securityexid    VARCHAR2(2000)
  , folderexid      VARCHAR2(2000)
  , documentexid    VARCHAR2(2000)
  , familyexid      VARCHAR2(2000)
);

CREATE UNIQUE INDEX &1..cdbi_link_exid_uni ON &1..cdb_link
(
    exid
);

CREATE INDEX &1..cdbi_link_id ON &1..cdb_link
(
    id
);

commit;


Rem Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
Rem All rights reserved. 
Rem
Rem  NAME
Rem    CreateImporterParameterTables.sql - create tables related to
Rem    importer schema parameters.
Rem
Rem History:
Rem     15-may-07 (dlong)
Rem         Created.
Rem     09-jun-07 (dlong)
Rem         Added handler registration table

whenever sqlerror exit sql.sqlcode

Prompt create handler procedures
create or replace procedure &1..NotifyAllHandlers
is
	CURSOR c1 is
		select schemaname, auditspecid, auditspecclassid from cdb_handler;
	  auditspecid number(20);
    auditspecclassid number(20);
    schemaname varchar(30);
begin
	for cIdx in c1 loop
		begin
			schemaname := cIdx.schemaname;
			auditspecid := cIdx.auditspecid;
			auditspecclassid := cIdx.auditspecclassid;
			execute immediate 'insert into ' || schemaname 
			  || '.odmz_event (eventid, id, classid, sessionid, serviceid, eventtype, eventsubtype, eventstatus, longpayload)'
        || ' values (' || schemaname || '.odmz_event_seq.nextval, '
        || auditspecid || ', ' || auditspecclassid || ', 16, 80, 4, 5, 2, 0)';
		end;
	end loop;

end NotifyAllHandlers;
/
show errors;

create or replace procedure &1..NotifyDocumentHandlers
is
	CURSOR c1 is
		select schemaname, auditspecid, auditspecclassid from cdb_handler where processesdocuments > 0;
	  auditspecid number(20);
    auditspecclassid number(20);
    schemaname varchar(30);
begin
	for cIdx in c1 loop
		begin
			schemaname := cIdx.schemaname;
			auditspecid := cIdx.auditspecid;
			auditspecclassid := cIdx.auditspecclassid;
			execute immediate 'insert into ' || schemaname 
			  || '.odmz_event (eventid, id, classid, sessionid, serviceid, eventtype, eventsubtype, eventstatus, longpayload)'
        || ' values (' || schemaname || '.odmz_event_seq.nextval, '
        || auditspecid || ', ' || auditspecclassid || ', 16, 80, 4, 5, 2, 0)';
		end;
	end loop;

end NotifyDocumentHandlers;
/

show errors;

create or replace procedure &1..NotifyNonDocumentHandlers
is
	CURSOR c1 is
		select schemaname, auditspecid, auditspecclassid from cdb_handler where processesdocuments = 0;
	  auditspecid number(20);
    auditspecclassid number(20);
    schemaname varchar(30);
begin
	for cIdx in c1 loop
		begin
			schemaname := cIdx.schemaname;
			auditspecid := cIdx.auditspecid;
			auditspecclassid := cIdx.auditspecclassid;
			execute immediate 'insert into ' || schemaname 
			  || '.odmz_event (eventid, id, classid, sessionid, serviceid, eventtype, eventsubtype, eventstatus, longpayload)'
        || ' values (' || schemaname || '.odmz_event_seq.nextval, '
        || auditspecid || ', ' || auditspecclassid || ', 16, 80, 4, 5, 2, 0)';
		end;
	end loop;

end NotifyNonDocumentHandlers;
/

create or replace procedure &1..CreateTableForCategory(
  tblname varchar2, createstmt varchar2, cdbschema varchar2,
  migschema varchar2)
is
begin
	execute immediate createstmt;
  
  IF UPPER(cdbschema) != UPPER(migschema) THEN
    execute immediate 'GRANT ALL PRIVILEGES on ' || 
      tblname || ' to ' || cdbschema;
  END IF;

end CreateTableForCategory;
/

create or replace procedure &1..CreateViewForCategory(
  viewname varchar2, createstmt varchar2, cdbschema varchar2,
  migschema varchar2)
is
begin
	execute immediate createstmt;
  
  IF UPPER(cdbschema) != UPPER(migschema) THEN
    execute immediate 'GRANT ALL PRIVILEGES on ' || 
      viewname || ' to ' || cdbschema;
  END IF;

end CreateViewForCategory;
/

create or replace procedure &1..DropTableForCategory(tblname varchar2)
is
begin
  execute immediate 'DROP TABLE ' || tblname;

end DropTableForCategory;
/

create or replace procedure &1..DropViewForCategory(viewname varchar2)
is
begin
  execute immediate 'DROP VIEW ' || tblname;

end DropTableForCategory;
/

show errors;

commit;

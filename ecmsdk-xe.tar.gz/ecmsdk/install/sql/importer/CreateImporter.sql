Rem Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
Rem All rights reserved. 
Rem
Rem  NAME
Rem    CreateImporter.sql - Create importer schema.
Rem
Rem History:
Rem     08-may-08 (dlong)
Rem         Created.
Rem     06-jul-09 (dlong)
Rem         Create sequence in separate file

whenever sqlerror exit sql.sqlcode

Prompt create the database user
@CreateImporterUser.sql &1 &2 &3

@CreateImporterSequences.sql &1
@CreateImporterUserTables.sql &1
@CreateImporterGroupTables.sql &1
@CreateImporterFolderTables.sql &1
@CreateImporterSecurityTables.sql &1
@CreateImporterDocumentTables.sql &1
@CreateImporterLinkTables.sql &1
@CreateImporterCategoryTables.sql &1
@CreateImporterParameterTables.sql &1

@GrantToContentSchema.sql &1 &3

quit;



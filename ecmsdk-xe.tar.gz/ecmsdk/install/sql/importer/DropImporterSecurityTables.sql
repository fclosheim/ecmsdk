Rem Copyright (c) 2006, 2008, Oracle. All rights reserved.
Rem
Rem  NAME
Rem    DropImporterSecurityTables.sql - drop the tables related
Rem    to security from the importer schema.
Rem
Rem History:
Rem     03-feb-07 (dlong)
Rem         Created.

whenever sqlerror continue

Prompt drop security tables
DROP TABLE cdb_securitydefinition;
DROP TABLE cdb_securitydefinition_grant;

commit;


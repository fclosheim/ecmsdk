Rem Copyright (c) 2006, 2008, Oracle. All rights reserved.
Rem
Rem  NAME
Rem    DropImporterUserTables.sql - drop the tables related
Rem    to users from the importer schema.
Rem
Rem History:
Rem     15-jan-07 (dlong)
Rem         Created.

whenever sqlerror continue

Prompt drop user tables
DROP TABLE cdb_user;

commit;


Rem Copyright (c) 2006, 2008, Oracle. All rights reserved.
Rem
Rem  NAME
Rem    CreateImporterGroupTables.sql - create tables related to groups
Rem    in the importer schema.
Rem
Rem History:
Rem     15-jan-07 (dlong)
Rem         Created.
Rem     23-feb-07 (dlong)
Rem         Add WORLD group.
Rem     25-apr-08 (dlong)
Rem         ID declared as not null.
Rem     09-may-08 (dlong)
Rem         called with schema arg.

whenever sqlerror exit sql.sqlcode

Prompt create Group tables and indexes
CREATE TABLE &1..cdb_group
(
    seq             NUMBER(20)      PRIMARY KEY
  , exid            VARCHAR2(256)   NOT NULL
  , id              NUMBER(20)      DEFAULT 0 NOT NULL
  , name            VARCHAR2(700)
  , description     VARCHAR2(2000)
  , createdate      NUMBER(20) 
  , creator         VARCHAR2(256) 
  , lastmodifydate  NUMBER(20) 
  , lastmodifier    VARCHAR2(256) 
  , visibility      NUMBER(10)
);

CREATE UNIQUE INDEX &1..cdbi_group_exid_uni ON &1..cdb_group
(
    exid
);

CREATE INDEX &1..cdbi_group_id ON &1..cdb_group
(
    id
);

CREATE TABLE &1..cdb_group_member
(
    groupexid       VARCHAR2(256)   NOT NULL
  , id              NUMBER(20)      DEFAULT 0 NOT NULL
  , usermemberexid  VARCHAR2(256)
  , groupmemberexid VARCHAR2(256)
  , manager         NUMBER(1)
);
commit;


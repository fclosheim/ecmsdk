Rem Copyright (c) 2006, 2008, Oracle. All rights reserved.
Rem
Rem  NAME
Rem    CreateImporterUser.sql - create importer user and perform grants.
Rem
Rem History:
Rem     13-aug-07 (dlong)
Rem         Created.
Rem     25-apr-08 (dlong)
Rem         Schema password is specified as the 2nd parameter.
Rem     09-may-08 (dlong)
Rem         called now from CreateImporter.sql

whenever sqlerror exit sql.sqlcode

Prompt create Category tables and indexes
CREATE USER &1 IDENTIFIED BY &2;

GRANT create session TO &1;
GRANT create TABLE TO &1;
GRANT create VIEW TO &1;
GRANT RESOURCE TO &1;

GRANT SELECT on &3..odmz_event to &1;
GRANT INSERT on &3..odmz_event to &1;
GRANT SELECT on &3..odmz_event_seq to &1;





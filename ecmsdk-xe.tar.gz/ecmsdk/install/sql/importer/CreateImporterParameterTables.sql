Rem Copyright (c) 2006, 2009, Oracle and/or its affiliates. 
Rem All rights reserved. 
Rem
Rem  NAME
Rem    CreateImporterParameterTables.sql - create tables related to
Rem    importer schema parameters.
Rem
Rem History:
Rem     15-may-07 (dlong)
Rem         Created.
Rem     09-jun-07 (dlong)
Rem         Added handler registration table
Rem     01-apr-08 (dlong)
Rem         Added notification and directive tables
Rem     12-apr-08 (dlong)
Rem         Expand payload of cdb_notification and cdb_directive.
Rem     09-may-08 (dlong)
Rem         called with schema arg.
Rem     18-apr-09 (dlong)
Rem         add procedures for create/drop views.
Rem     06-oct-09 (dlong)
Rem         add DELETE_PROCESSED_DOCUMENT_ENTRIES.
Rem     15-oct-09 (dlong)
Rem         change initial value of DELETE_PROCESSED_DOCUMENT_ENTRIES to true.

whenever sqlerror exit sql.sqlcode

Prompt create Parameter tables and indexes
CREATE TABLE &1..cdb_parameter
(
    key        VARCHAR2(256)   PRIMARY KEY
  , value      VARCHAR2(2000)
);

Prompt table is initially populated with all valid parameters, along
Prompt with default values. The values can be updated, but the rows should not
Prompt be deleted.

INSERT into &1..cdb_parameter (key, value) 
       values ('FOLDER_ID_GROUP_COUNT', 12);

INSERT into &1..cdb_parameter (key, value) 
       values ('CONTENT_MIDTIER_ROOT_DIRECTORY', null);

INSERT into &1..cdb_parameter (key, value) 
       values ('CONTENT_BFILE_ROOT_DIRECTORY', null);

INSERT into &1..cdb_parameter (key, value) 
       values ('MISC_EXTERNALID_CACHE_TARGET_SIZE', 4000);

INSERT into &1..cdb_parameter (key, value) 
       values ('USER_BATCH_SIZE', 500);

INSERT into &1..cdb_parameter (key, value) 
       values ('GROUP_BATCH_SIZE', 500);

INSERT into &1..cdb_parameter (key, value) 
       values ('FOLDER_BATCH_SIZE', 500);

INSERT into &1..cdb_parameter (key, value) 
       values ('DOCUMENT_BATCH_SIZE', 500);

INSERT into &1..cdb_parameter (key, value) 
       values ('LINK_BATCH_SIZE', 500);

INSERT into &1..cdb_parameter (key, value) 
       values ('DELETE_PROCESSED_DOCUMENT_ENTRIES', 1);

commit;

Prompt create notification and directive tables
CREATE TABLE &1..cdb_notification
(
    seq             NUMBER(20)      PRIMARY KEY
  , operationtype   NUMBER(10)
  , id              NUMBER(20)
  , status          NUMBER(10)
  , auxnumber1      NUMBER(20)
  , auxnumber2      NUMBER(20)
  , auxnumber3      NUMBER(20)
  , exid            VARCHAR2(2000)
  , auxstring1      VARCHAR2(700)
  , auxstring2      VARCHAR2(700)
  , auxstring3      VARCHAR2(2000)
);

CREATE TABLE &1..cdb_directive
(
    seq             NUMBER(20)      PRIMARY KEY
  , directivetype   NUMBER(10)
  , id              NUMBER(20)
  , status          NUMBER(10)
  , auxnumber1      NUMBER(20)
  , auxnumber2      NUMBER(20)
  , auxnumber3      NUMBER(20)
  , exid            VARCHAR2(2000)
  , auxstring1      VARCHAR2(700)
  , auxstring2      VARCHAR2(700)
  , auxstring3      VARCHAR2(2000)
);

Prompt create handler registration table
CREATE TABLE &1..cdb_handler
(
    schemaname          VARCHAR2(30)
  , auditspecid         NUMBER(20)
  , auditspecclassid    NUMBER(20)
  , processesdocuments  NUMBER(1)
);

Prompt create handler procedures
create or replace procedure &1..NotifyAllHandlers
is
	CURSOR c1 is
		select schemaname, auditspecid, auditspecclassid from cdb_handler;
	  auditspecid number(20);
    auditspecclassid number(20);
    schemaname varchar(30);
begin
	for cIdx in c1 loop
		begin
			schemaname := cIdx.schemaname;
			auditspecid := cIdx.auditspecid;
			auditspecclassid := cIdx.auditspecclassid;
			execute immediate 'insert into ' || schemaname 
			  || '.odmz_event (eventid, id, classid, sessionid, serviceid, eventtype, eventsubtype, eventstatus, longpayload)'
        || ' values (' || schemaname || '.odmz_event_seq.nextval, '
        || auditspecid || ', ' || auditspecclassid || ', 16, 80, 4, 5, 2, 0)';
		end;
	end loop;

end NotifyAllHandlers;
/
show errors;

create or replace procedure &1..NotifyDocumentHandlers
is
	CURSOR c1 is
		select schemaname, auditspecid, auditspecclassid from cdb_handler where processesdocuments > 0;
	  auditspecid number(20);
    auditspecclassid number(20);
    schemaname varchar(30);
begin
	for cIdx in c1 loop
		begin
			schemaname := cIdx.schemaname;
			auditspecid := cIdx.auditspecid;
			auditspecclassid := cIdx.auditspecclassid;
			execute immediate 'insert into ' || schemaname 
			  || '.odmz_event (eventid, id, classid, sessionid, serviceid, eventtype, eventsubtype, eventstatus, longpayload)'
        || ' values (' || schemaname || '.odmz_event_seq.nextval, '
        || auditspecid || ', ' || auditspecclassid || ', 16, 80, 4, 5, 2, 0)';
		end;
	end loop;

end NotifyDocumentHandlers;
/

show errors;

create or replace procedure &1..NotifyNonDocumentHandlers
is
	CURSOR c1 is
		select schemaname, auditspecid, auditspecclassid from cdb_handler where processesdocuments = 0;
	  auditspecid number(20);
    auditspecclassid number(20);
    schemaname varchar(30);
begin
	for cIdx in c1 loop
		begin
			schemaname := cIdx.schemaname;
			auditspecid := cIdx.auditspecid;
			auditspecclassid := cIdx.auditspecclassid;
			execute immediate 'insert into ' || schemaname 
			  || '.odmz_event (eventid, id, classid, sessionid, serviceid, eventtype, eventsubtype, eventstatus, longpayload)'
        || ' values (' || schemaname || '.odmz_event_seq.nextval, '
        || auditspecid || ', ' || auditspecclassid || ', 16, 80, 4, 5, 2, 0)';
		end;
	end loop;

end NotifyNonDocumentHandlers;
/

create or replace procedure &1..CreateTableForCategory(
  tblname varchar2, createstmt varchar2, cdbschema varchar2,
  migschema varchar2)
is
begin
	execute immediate createstmt;
  
  IF UPPER(cdbschema) != UPPER(migschema) THEN
    execute immediate 'GRANT ALL PRIVILEGES on ' || 
      tblname || ' to ' || cdbschema;
  END IF;

end CreateTableForCategory;
/

create or replace procedure &1..CreateViewForCategory(
  viewname varchar2, createstmt varchar2, cdbschema varchar2,
  migschema varchar2)
is
begin
	execute immediate createstmt;
  
  IF UPPER(cdbschema) != UPPER(migschema) THEN
    execute immediate 'GRANT ALL PRIVILEGES on ' || 
      viewname || ' to ' || cdbschema;
  END IF;

end CreateViewForCategory;
/

create or replace procedure &1..DropTableForCategory(tblname varchar2)
is
begin
  execute immediate 'DROP TABLE ' || tblname;

end DropTableForCategory;
/

create or replace procedure &1..DropViewForCategory(viewname varchar2)
is
begin
  execute immediate 'DROP VIEW ' || viewname;

end DropViewForCategory;
/

show errors;

commit;


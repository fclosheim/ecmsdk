Rem Copyright (c) 2006, 2008, Oracle. All rights reserved.
Rem
Rem  NAME
Rem    CreateImporterSecurityTables.sql - create tables related to 
Rem    security in the importer schema.
Rem
Rem History:
Rem     03-feb-07 (dlong)
Rem         Created.
Rem     25-apr-08 (dlong)
Rem         ID declared as not null.
Rem     09-may-08 (dlong)
Rem         called with schema arg.

whenever sqlerror exit sql.sqlcode

Prompt create Security tables and indexes
CREATE TABLE &1..cdb_securitydefinition
(
    seq             NUMBER(20)      PRIMARY KEY
  , exid            VARCHAR2(2000)  NOT NULL
  , id              NUMBER(20)      DEFAULT 0 NOT NULL
);

CREATE UNIQUE INDEX &1..cdbi_securitydef_exid_uni ON &1..cdb_securitydefinition
(
    exid
);

CREATE INDEX &1..cdbi_securitydef_id ON &1..cdb_securitydefinition
(
    id
);

CREATE TABLE &1..cdb_securitydefinition_grant
(
    securityexid    VARCHAR2(2000)   NOT NULL
  , userexid        VARCHAR2(256)
  , groupexid       VARCHAR2(256)
  , rolename        VARCHAR2(700)   NOT NULL
  , propagates      NUMBER(1)
);
commit;


Rem Copyright (c) 2006, 2008, Oracle. All rights reserved.
Rem
Rem  NAME
Rem    DropImporterFolderTables.sql - drop the tables related
Rem    to folders from the importer schema.
Rem
Rem History:
Rem     15-jan-07 (dlong)
Rem         Created.

whenever sqlerror continue

Prompt drop folder tables
DROP TABLE cdb_folder;

commit;


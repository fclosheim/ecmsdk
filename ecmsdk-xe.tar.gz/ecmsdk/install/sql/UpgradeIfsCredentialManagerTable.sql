Rem Copyright (c) 2001, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    UpgradeIfsCredentialManagerTable.sql - Used for upgrade. 
Rem
Rem  History:
Rem    30-sep-05 (vdevadha)
Rem      Created.

whenever sqlerror exit sql.sqlcode

alter table IfsCredentialManager add(subscriber varchar2(512));

exit;




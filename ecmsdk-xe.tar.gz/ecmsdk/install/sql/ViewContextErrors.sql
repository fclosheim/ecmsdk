Rem Copyright (c) 2001, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    ViewContextErrors.sql 
Rem
Rem    View which documents caused Oracle Text errors.
Rem
Rem  History:
Rem    27-jun-01 (awiersba)
Rem      Created
Rem    09-jul-01 (awiersba)
Rem      Adjusted decriptions.
Rem    22-oct-07 (dpitfiel)
Rem      ID column of odmz_context_router is now the ContentObject id.


whenever sqlerror exit sql.sqlcode

Rem Run as the Oracle 9iFS schema user, for example, ifssys
Rem Run this in SQLPLUS for 80-column formatting

column name format a28
column uniquename format a19 heading 'OWNER'
column Error format a11
column filebytes format 999999999

select to_char(ce.err_timestamp,'HH24:MI') TIME, 
du.uniquename, vd.name, co.contentsize filebytes,
/* The status codes are operating system specific */
decode(substr(ce.err_text,1,9),
       'DRG-11207', 'Status' || 
       substr(ce.err_text,
              instr(ce.err_text,' ',-1)),
       substr(ce.err_text,1,9)) Error
from odmv_document vd, 
odm_contentobject co, 
odm_document od, 
odm_directoryuser du, 
ctx_user_index_errors ce, 
odmz_context_router oc 
where vd.id = od.id 
and od.contentobject = co.id 
and du.id = vd.owner 
and co.id = oc.id 
and oc.rowid =  ce.err_textkey 
order by ce.err_timestamp desc
/

exit


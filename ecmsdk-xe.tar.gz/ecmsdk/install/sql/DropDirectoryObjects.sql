Rem Copyright (c) 2008, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    DropDirectoryObjects.sql - Drops DIRECTORYs created by this schema
Rem
Rem  History:
Rem   2008-01-22  dpitfiel  Created.
Rem

WHENEVER SQLERROR EXIT SQL.SQLCODE

CREATE OR REPLACE PROCEDURE dropdirectoryobjects
  AS LANGUAGE JAVA NAME 'oracle.ifs.server.S_MediaBfileServer.dropDirectoryObjects()';
/
SHOW ERRORS;

BEGIN
dropdirectoryobjects;
END;
/
SHOW ERRORS;

DROP PROCEDURE dropdirectoryobjects;

EXIT;

REM
REM EOF
REM

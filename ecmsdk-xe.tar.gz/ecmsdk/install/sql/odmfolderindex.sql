Rem Copyright (c) 2001, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    odmfolderindex.sql - initial population of iFS Folder index tables
Rem
Rem	History:
Rem		13-apr-01 (dlong)
Rem			Created.
Rem		16-may-01 (vdevadha)
Rem			Added internal use views.
Rem		17-may-01 (vdevadha)
Rem			Renamed views. Added indexes for odmz_folder_index.


whenever sqlerror exit sql.sqlcode

Prompt creating odmz_folderindex
CREATE TABLE odmz_folderindex
(
		lev NUMBER(9)
		, leftid NUMBER(20)
		, rightid NUMBER(20)
		, leftsource NUMBER(20)
);

Prompt Creating index odmi_folderindex_left
CREATE INDEX odmi_folderindex_left ON odmz_folderindex (lev, leftid); 

Prompt Creating index odmi_folderindex_right
CREATE INDEX odmi_folderindex_right ON odmz_folderindex (lev, rightid);

Prompt Creating index odmi_folderindex_leftsrc
CREATE INDEX odmi_folderindex_leftsrc ON odmz_folderindex (lev, leftsource);

Prompt creating odmz_folderindex_parameters
CREATE TABLE odmz_folderindex_parameters
(
	key NUMBER(20) PRIMARY KEY
	, value NUMBER(20)
) CACHE;

Prompt creating odmz_folderindex_updates
CREATE TABLE odmz_folderindex_updates
(
	id NUMBER(20) PRIMARY KEY
	, operationtype NUMBER(9)
	, leftid NUMBER(20)
	, rightid NUMBER(20)
	, lev NUMBER(9)
);

Prompt set max level to 2
INSERT INTO odmz_folderindex_parameters
	(key, value) VALUES (1, 2);

Prompt set map update mode to synchronous
INSERT INTO odmz_folderindex_parameters
	(key, value) VALUES (3, 1);

Prompt creating view odmzv_folderindex_folderdef 
CREATE OR REPLACE VIEW odmzv_folderindex_folderdef as 
 SELECT lev, leftid fid 
 FROM odmz_folderindex where leftid=rightid and leftid = leftsource; 

Prompt creating view odmzv_folderindex_parentcount 
CREATE OR REPLACE VIEW odmzv_folderindex_parentcount as 
 SELECT i.rightid, i.lev, count(*) pcount 
 FROM odmz_folderindex i, odmzv_folderindex_folderdef def where 
 i.rightid = def.fid and i.lev=def.lev 
 and i.rightid != i.leftid and i.leftid = i.leftsource group by i.rightid, i.lev; 

commit;
exit;


Rem Copyright (c) 2002, 2008, Oracle. All rights reserved.  
Rem
Rem  History:
Rem    2002-05-14  spinto    Created.
Rem

set serveroutput on;

grant execute on IfsQueueMessage to &1;
grant execute on IfsQueueMessageParameter    to &1;
grant execute on Parameters    to &1;

begin
dbms_aqadm.grant_queue_privilege(
    privilege => 'DEQUEUE',
	queue_name => 'ifs_out',
	grantee => '&1',
	grant_option => TRUE);
    dbms_output.put_line ('Granted dequeue privilege on ifs_out to &1');
end;
/

begin
dbms_aqadm.grant_queue_privilege(
    privilege => 'ENQUEUE',
	queue_name => 'ifs_in',
	grantee => '&1',
	grant_option => TRUE);
    dbms_output.put_line ('Granted enqueue privilege on ifs_in to &1');
end;
/

declare
    subscriber sys.aq$_agent;
    err_num number;
begin
    subscriber := sys.aq$_agent('wf', NULL, NULL);
    dbms_aqadm.add_subscriber(
        queue_name => 'ifs_out',
        subscriber => subscriber);
    dbms_output.put_line ('Added subscriber wf to ifs_out.');
exception
    when others then
        err_num := SQLCODE;
        if( err_num = -24034 ) then
    		dbms_output.put_line ('Subscriber already exists. Continue ...');
        else
            raise;
        end if;

end;
/

commit;
exit;


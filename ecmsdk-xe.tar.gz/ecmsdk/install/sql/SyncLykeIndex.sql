Rem Copyright (c) 2004, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
REM    SyncLykeIndex.sql - sql script used to sync lyke index manually.
Rem
REM    This script is not used in the install environment since we use
REM    a DBMS job to sync LYKE index.  If ever a manual syncing is required,
REM    then use this script.
REM
Rem  History:
Rem    25-mar-04 (vdevadha)
Rem      Created.
REM
REM  USAGE
REM    sqlplus <ifs-schema-name>/<ifs-schema-password> @SyncLykeIndex <ifs-schema-name>
REM
REM    Parameters being passed to indexsync call below are 
REM
REM    1. Name of the schema owning the substring index
REM    2. Name of the index
REM    3. Batch size - # of rows from pending queue per commit 
REM    4. MaxTime - in seconds to be allocated to the sync, 0 means infinite
REM    5. LogLevel - if set to a non zero number, entries are created in $L table
REM    

begin
    ctx_substr.indexsync('&1', 'IFS_LYKE', 64, 0, 0);
end;
/

exit;


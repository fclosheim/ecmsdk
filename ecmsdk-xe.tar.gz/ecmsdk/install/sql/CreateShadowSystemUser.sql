Rem Copyright (c) 2015, inxire GmbH and/or its affiliates.
Rem All rights reserved. 
Rem
Rem  NAME
Rem    CreateShadowSystemUser.sql - Create a user with enough privileges
Rem                                 to be able to create an ECMSDK schema
Rem 
Rem  Usage:
Rem    @CreateShadowSystemUser {ALT_SYSTEM_USER} {ALT_SYSTEM_USER_PASSWORD}
Rem                            {TBS_NAME} {TEMP_TBS_NAME}
Rem
Rem History:
Rem     22-dec-15 (dscholle)
Rem         Created.

SET VERIFY OFF

Prompt Drop User
DROP USER &1;

whenever sqlerror exit sql.sqlcode

Prompt Create User
CREATE USER &1 IDENTIFIED BY &2
DEFAULT TABLESPACE &3
TEMPORARY TABLESPACE &4;

Prompt Grant Privileges
GRANT CONNECT                 TO &1 WITH ADMIN OPTION;
GRANT RESOURCE                TO &1 WITH ADMIN OPTION;
GRANT UNLIMITED TABLESPACE    TO &1 WITH ADMIN OPTION;
GRANT ALTER SESSION           TO &1 WITH ADMIN OPTION;
GRANT CREATE CLUSTER          TO &1 WITH ADMIN OPTION;
GRANT CREATE DATABASE LINK    TO &1 WITH ADMIN OPTION;
GRANT CREATE SEQUENCE         TO &1 WITH ADMIN OPTION;
GRANT CREATE SESSION          TO &1 WITH ADMIN OPTION;
GRANT CREATE SYNONYM          TO &1 WITH ADMIN OPTION;
GRANT CREATE TABLE            TO &1 WITH ADMIN OPTION;
GRANT CREATE VIEW             TO &1 WITH ADMIN OPTION;
GRANT QUERY REWRITE           TO &1 WITH ADMIN OPTION;
GRANT CREATE ANY SEQUENCE     TO &1 WITH ADMIN OPTION;

GRANT DROP USER               TO &1;
GRANT CREATE USER             TO &1;
GRANT DROP ANY SEQUENCE       TO &1;
GRANT CREATE ANY SYNONYM      TO &1;
GRANT DROP ANY DIRECTORY      TO &1 WITH ADMIN OPTION;
GRANT CREATE ANY DIRECTORY    TO &1 WITH ADMIN OPTION;
GRANT CREATE ANY PROCEDURE    TO &1;
GRANT DROP ANY PROCEDURE      TO &1;
GRANT EXECUTE ANY PROCEDURE   TO &1;

CALL dbms_java.grant_policy_permission(upper('&1'), 'SYS', 'java.io.FilePermission', '*');
GRANT aq_administrator_role   TO &1 WITH ADMIN OPTION;
GRANT ctxapp                  TO &1 WITH ADMIN OPTION;
GRANT select_catalog_role     TO &1;


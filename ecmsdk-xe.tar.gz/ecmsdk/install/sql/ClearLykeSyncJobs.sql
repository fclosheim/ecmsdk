Rem Copyright (c) 2004, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    ClearLykeSyncJobs.sql - Clears q jos used for lyke sync. 
Rem
Rem  History:
Rem    25-mar-04 (vdevadha)
Rem       Created. 
Rem    25-mar-04 (vdevadha)
Rem       Removed redundant code. 

declare
    jobid binary_integer;
    err_num number;
	CURSOR c1  is
		select job from user_jobs where what like 'ctx_substr%';
begin
	for cIdx in c1 loop
        dbms_output.put_line('Removing DBMS Job : ' || cIdx.job);
        dbms_job.remove( job=>cIdx.job);
    end loop;
end;
/

exit;


Rem Copyright (c) 2001, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    GrantContextToIfs.sql - Setup Context Schema for 9iFS
Rem
Rem  History:
Rem    20-jul-98 (hbutani)
Rem      Created
Rem    23-sep-98 (aalavi)
Rem      Create Context themes/summaries results tables
Rem    16-oct-98 (aalavi)
Rem      Increase 'default' and 'max' indexing memory size  
Rem    29-oct-98 (aalavi)
Rem      Add DM_DEF_STOPLIST preference.  
Rem    02-nov-98 (hbutani)
Rem      Removed create tablespace statement from this script
Rem    18-nov-98 (hbutani)
Rem      Added default URL preference
Rem    05-mar-99 (dtom)
Rem      Split into contextsetup.sql into two files
Rem    10-mar-99 (aalavi)
Rem      Change default and max indexing memory size
Rem    17-mar-99 (aalavi)
Rem      Change max indexing memory size from 2G to 2147483647
Rem    06-dec-99 (basubram)
Rem      Added exit on sql error
Rem    11-dec-00 (lmatter)
Rem      renamed script, moved memsize setting to CreateContextPrefs.sql
Rem      also creates funneling procedure wrapper (which is owned by ctxsys)
Rem    10-may-01 (lmatter)
Rem      Modified to run as SYS instead of CTXSYS.
Rem    16-may-01 (lmatter)
Rem      Changed name of wrapper procedure to <schema_name>_WP
Rem    27-aug-03 (tseto)
Rem      Bug 3089263 - create duplicate wrapper procedure in iFS
Rem      schema for 10g Text compatibility.

whenever sqlerror exit sql.sqlcode

Prompt Granting privileges to &1
grant ctxapp to &1;

Prompt Setting up Indexing memory size(default=16M, max=2G)
create or replace procedure ctxsys.ifsadmin(param in varchar2, val in varchar2) is
begin ctx_adm.set_parameter(param, val);
end;
/
exec ctxsys.ifsadmin('max_index_memory', '2147483647');
exec ctxsys.ifsadmin('default_index_memory', '16000000');
drop procedure ctxsys.ifsadmin;

Prompt granting ctx packages to &1
create or replace procedure ctxsys.ifsgrant(pkg in varchar2) is
begin execute immediate 'grant execute on '||pkg||' to &1';
end;
/

exec ctxsys.ifsgrant('ctx_adm');
exec ctxsys.ifsgrant('ctx_ddl');
exec ctxsys.ifsgrant('ctx_thes');
exec ctxsys.ifsgrant('ctx_query');

Rem
Rem create funneling procedure wrapper.  Embed ifs schema name in procname
Rem to avoid namespace collision. Call twin wrapper procedure in iFS schema.
Rem
Prompt Creating Indexing Procedure wrapper in ctxsys schema 
create or replace procedure ctxsys.&1._WP(rid in rowid,
                                          tlob in out nocopy blob) is
begin &1..&1._WP(rid, tlob);
end;
/

show errors

exec ctxsys.ifsgrant('&1._WP');


drop procedure ctxsys.ifsgrant;

commit;
exit;



Rem Copyright (c) 2003, 2008, Oracle. All rights reserved.
Rem
Rem  NAME
Rem    CreateTextIndexView.sql - Creates a view that gives access to the 
Rem    text index using SQL. 
Rem
Rem  History:
Rem    06-mar-03 (vdevadha)
Rem      Created
Rem    22-oct-07 (dpitfiel)
Rem      ID column of odmz_context_router is now the ContentObject id.
Rem    05-sep-08 (dpitfiel)
Rem      Renamed CONTENTPROCEDURE to CONTENTINDEX in odmz_context_router.

whenever sqlerror exit sql.sqlcode

Rem Creating view to expose the text index 

CREATE or REPLACE view odmzv_textindexview as
SELECT doc.id document_id,
       co.id contentobject_id,
       cr.contentindex content
FROM   odm_document doc,
       odm_contentobject co,
       odmz_context_router cr
WHERE  doc.contentobject = co.id AND
       co.id = cr.id
with   READ ONLY;

exit;



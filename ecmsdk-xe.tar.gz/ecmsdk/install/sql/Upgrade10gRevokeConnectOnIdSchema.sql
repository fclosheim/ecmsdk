REM Copyright (c) 2004, 2008, Oracle. All rights reserved.  
REM
REM    NAME
REM      Upgrade10gRevokeConnectOnIdSchema.sql - upgrade to provide additional
REM      priviledges now omitted by 10g R2.
REM
REM   History
REM     08-sep-04 (pyoung)
REM        created.

whenever sqlerror exit sql.sqlcode;
set serveroutput on

prompt Revoking Connect role from CM SDK schema

REVOKE CONNECT FROM &1$id;

whenever sqlerror exit 0;

exit;



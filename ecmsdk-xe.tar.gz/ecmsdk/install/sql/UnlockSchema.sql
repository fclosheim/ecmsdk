Rem Copyright (c) 2005, 2008, Oracle. All rights reserved.  
Rem
Rem NAME
Rem     UnlockSchema.sql
Rem         Unlocks the ifs Schema
Rem
Rem PARAMETERS
Rem     &1  ifs schema name
Rem     &2  ifs schema password
Rem     &3  DBA name
Rem     &4  DBA password
Rem
Rem History:
Rem     18-apr-05 (aknatara)
Rem         created
Rem

WHENEVER SQLERROR EXIT SQL.SQLCODE 

set serveroutput on size 10000;  
CONNECT &3/&4 as sysdba;  

DECLARE
   sql_stmt  varchar2(2000);
BEGIN
   sql_stmt := 'alter user &1 identified by &2 account unlock' ;
   execute immediate  sql_stmt;
      
END;
/
EXIT;  



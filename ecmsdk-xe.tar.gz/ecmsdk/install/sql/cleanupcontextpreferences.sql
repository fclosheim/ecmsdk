Rem Copyright (c) 2001, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME: cleanupcontextpreferences.sql
Rem    Calls CTX_ADM.recover method.
Rem
Rem
Rem  History:
Rem    09-aug-00 (vdevadha)
Rem      Moved this functionality from dropcontextindexes.sql so
Rem      that the installer can call this separately.
Rem    08-jan-01 (lmatter)
Rem      Now drops "funneling" procedure wrapper.

whenever sqlerror continue;

set serveroutput on

drop procedure ctxsys.&1._WP;
exit;



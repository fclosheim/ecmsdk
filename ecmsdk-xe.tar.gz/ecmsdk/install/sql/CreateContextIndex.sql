Rem Copyright (c) 2001, 2008, Oracle. All rights reserved.
Rem
Rem  NAME
Rem    contextsetup2.sql - Setup Context Schema for DM
Rem
Rem  History:
Rem    14-dec-00 (lmatter)
Rem      Created
Rem    07-mar-01 (lmatter)
Rem      moved creation of ODMZ_CONTEXT_ROUTER to omdmain.sql. 
Rem    10-may-01 (lmatter)
Rem      moved creation of funneling procedure to seperate file
Rem      to support context install without unlocking ctxsys user
Rem    31-mar-04 (sayyagar)
Rem      move creation of filter preference to this file
Rem      to support Fast filter   
Rem    05-sep-08 (dpitfiel)
Rem       Renamed CONTENTPROCEDURE to CONTENTINDEX in odmz_context_router.


whenever sqlerror exit sql.sqlcode

Rem Connect as the schema user with schema password
connect &1/&2;

Rem create default filter preference. 
exec ctx_ddl.create_preference('IFS_DEF_FILTER', 'INSO_FILTER');
exec ctx_ddl.set_attribute('IFS_DEF_FILTER', 'TIMEOUT', '120');

Rem Creating index on routing table.
create index IFS_TEXT on ODMZ_CONTEXT_ROUTER(contentindex)
	indextype is ctxsys.CONTEXT
	parameters ( 'storage IFS_DEF_STORAGE datastore IFS_USER_DATASTORE lexer IFS_GLOBAL_LEXER language column language FILTER IFS_DEF_FILTER format column FORMAT charset column CHARACTERSET wordlist IFS_DEF_WORDLIST memory 32000000 stoplist CTXSYS.DEFAULT_STOPLIST section group IFS_SECTION_GROUP');

commit;
exit;



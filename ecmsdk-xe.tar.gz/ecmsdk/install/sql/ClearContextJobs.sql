Rem Copyright (c) 2003, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    ClearContextJobs.sql - Clears DBMS jobs used for context sync & optimize. 
Rem
Rem  History:
Rem    09-apr-03 (vdevadha)
Rem       Created. 

declare
    jobid binary_integer;
    err_num number;
	CURSOR c1  is
		select job from user_jobs where what = 'ctx_ddl.sync_index(''IFS_TEXT'');';
begin
	for cIdx in c1 loop
        dbms_output.put_line('Removing DBMS Job : ' || cIdx.job);
        dbms_job.remove( job=>cIdx.job);
    end loop;
end;
/

declare
    jobid binary_integer;
    err_num number;
	CURSOR c1  is
		select job from user_jobs 
		where what like 'ctx_ddl.optimize_index(idx_name=>''IFS_TEXT''%' ;
begin
	for cIdx in c1 loop
        dbms_output.put_line('Removing DBMS Job : ' || cIdx.job);
        dbms_job.remove( job=>cIdx.job);
    end loop;
end;
/

exit;


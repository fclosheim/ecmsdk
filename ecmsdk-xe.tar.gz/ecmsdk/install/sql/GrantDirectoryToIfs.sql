Rem Copyright (c) 2002, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    GrantDirectoryToIfs.sql - Setup Directory privileges for 9iFS
Rem
Rem  History:
Rem    17-jan-02 (kgillett)
Rem        Created.

whenever sqlerror exit sql.sqlcode

Prompt Granting privileges to &1

grant DROP ANY DIRECTORY TO &1;
grant CREATE ANY DIRECTORY TO &1;

commit;
exit;


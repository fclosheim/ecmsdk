Rem Copyright (c) 2001, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    CreateIfsQueueMessageType.sql - Create the IfsQueueMessage type for queues. 
Rem
Rem  History:
Rem    18-oct-01 (vdevadha)
Rem      Created
Rem    12-nov-01 (vdevadha)
Rem      Modified AddParameterListMethod to handle null list.  
Rem    16-nov-01 (vdevadha)
Rem      Renamed IfsParameter to IfsQueueMessageParameter.  
Rem    21-nov-01 (vdevadha)
Rem      Chaged parameter value length from 2048 to 2000.  
Rem    08-feb-02 (vdevadha)
Rem      Removed the unnecessary drop object type statements.  
Rem    22-apr-02 (vdevadha)
Rem      Added the drop type statements to make script idempotent.  

whenever sqlerror continue

drop type IfsQueueMessage;
drop type Parameters;
drop type IfsQueueMessageParameter;
 
whenever sqlerror exit sql.sqlcode

Prompt Creating type IfsQueueMessageParameter 
create type IfsQueueMessageParameter as object
(
  Name       varchar2(30),
  Value      varchar2(2000),
  DataType   varchar2(30),

  MEMBER FUNCTION  getName  return varchar2,
  MEMBER FUNCTION  getValue return varchar2,
  MEMBER FUNCTION  getDataType return varchar2,

  MEMBER PROCEDURE setName (pName  in varchar2),
  MEMBER PROCEDURE setValue(pValue in varchar2),
  MEMBER PROCEDURE setDataType(pDataType in varchar2)
)
/
Show errors;

Prompt Creating type body for IfsQueueMessageParameter 
create or replace type body IfsQueueMessageParameter as
  MEMBER FUNCTION getName return varchar2 is
  begin
    return Name;
  end getName;

  MEMBER FUNCTION getValue return varchar2 is
  begin
    return Value;
  end getValue;

  MEMBER FUNCTION getDataType return varchar2 is
  begin
    return DataType;
  end getDatatype;

  MEMBER PROCEDURE setName(pName in varchar2) is
  begin
    Name := pName;
  end setName;

  MEMBER PROCEDURE setValue(pValue in varchar2) is
  begin
    Value := pValue;
  end setValue;

  MEMBER PROCEDURE setDatatype(pDatatype in varchar2) is
  begin
    DataType := pDatatype;
  end setDatatype;
end;
/
Show errors;

Prompt Creating type Parameters (Array of IfsQueueMessageParameter)
create type Parameters is VARRAY(100) OF IfsQueueMessageParameter
/
Prompt Creating type IfsQueueMessage 
create type IfsQueueMessage as object
(
  MessageType       varchar2(30),
  ParameterList     Parameters,

  STATIC PROCEDURE initialize(pMessageType in varchar2, pIfsQueueMessage in out IfsQueueMessage), 

  MEMBER FUNCTION  getParameterList     return Parameters,
  MEMBER FUNCTION  getMessageType       return varchar2,

  MEMBER PROCEDURE setParameterList    (pParameterList in Parameters),
  MEMBER PROCEDURE setMessageType      (pMessageType in varchar2),
  
  MEMBER PROCEDURE AddParameterToList(pName  in varchar2,
                                      pValue in varchar2, 
                                      pDataType in varchar2),

  MEMBER FUNCTION GetValueForParameter(pName in varchar2) return varchar2
)
/
Show errors;

create or replace type body IfsQueueMessage as
  STATIC PROCEDURE initialize(pMessageType in varchar2, pIfsQueueMessage in out IfsQueueMessage) is
  begin
    pIfsQueueMessage := IfsQueueMessage(pMessageType, null);           -- parameter_list
  end initialize;


  MEMBER FUNCTION getParameterList return Parameters is
  begin
    return ParameterList;
  end getParameterList;

  MEMBER FUNCTION getMessageType return varchar2 is
  begin
    return MessageType;
  end getMessageType;

  MEMBER PROCEDURE setParameterList(pParameterList in Parameters) is
  begin
    ParameterList := pParameterList;
  end setParameterList;

  MEMBER PROCEDURE setMessageType(pMessageType in varchar2) is
  begin
    MessageType := pMessageType;
  end setMessageType;

  MEMBER PROCEDURE AddParameterToList(pName  in varchar2,
                                      pValue in varchar2,
                                      pDatatype in varchar2) is
    myList  Parameters;
    j       number;
    found   boolean := FALSE;
  begin

    myList := self.getParameterList();
    if (myList is null) then
        myList := Parameters(null);
    	myList(1) := IfsQueueMessageParameter(pName, pValue, pDatatype);
    else
        myList.EXTEND;
        j := myList.COUNT;
        myList(j) := IfsQueueMessageParameter(pName, pValue, pDatatype);
    end if;

    self.setParameterList(myList);
  end AddParameterToList;

  MEMBER FUNCTION getValueForParameter(pName in varchar2) return varchar2 is
    myList  Parameters;
    pos     number := 1;
  begin
    myList := self.getParameterList();
    if (myList is null) then
      return NULL;
    end if;

    while(pos <= myList.COUNT) loop
      if (myList(pos).getName() = pName) then
        return myList(pos).getValue();
      end if;
      pos := pos + 1;
    end loop;
    return NULL;
  end getValueForParameter;
end;
/
show errors;

exit;


Rem Copyright (c) 2005, 2008, Oracle. All rights reserved.  
Rem
Rem  NAME
Rem    RetainSchemaVersionDuringUpgrade.sql - This script 
Rem    used to save the source schema version for the duration of upgrade.
Rem
Rem  History:
Rem    06-oct-05 (vdevadha)
Rem        Created.

whenever sqlerror exit sql.sqlcode

update tp$z_repositoryparameter set name = 'REALSCHEMAVERSION' where name = 'SCHEMAVERSION';
delete from tp$z_repositoryparameter where name = 'SCHEMAVERSION' ;
insert into tp$z_repositoryparameter select *  from odmz_repositoryparameter where name = 'SCHEMAVERSION';

exit;



Rem Copyright (c) 2015, inxire GmbH and/or its affiliates.
Rem All rights reserved. 
Rem
Rem  NAME
Rem    SystemPostInstall.sql - Perform post installation actions as system user
Rem 
Rem  Usage:
Rem    @SystemPostInstall {IFS_SCHEMA_NAME}
Rem
Rem History:
Rem     21-dec-15 (dscholle)
Rem         Created.

whenever sqlerror exit sql.sqlcode

SET VERIFY OFF

-- @{IFS_ADMIN_SQL}/RevokeIfsCredentialManager.sql &1.$CM
Prompt Revoking connect permissions from &1.$cm
REVOKE ALTER SESSION FROM &1.$cm;
REVOKE CREATE CLUSTER FROM &1.$cm;
REVOKE CREATE DATABASE LINK FROM &1.$cm;
REVOKE CREATE SEQUENCE FROM &1.$cm;
REVOKE CREATE SESSION FROM &1.$cm;
REVOKE CREATE SYNONYM FROM &1.$cm;
REVOKE CREATE TABLE FROM &1.$cm;
REVOKE CREATE VIEW FROM &1.$cm;

-- @{IFS_ADMIN_SQL}/GrantContextToIFS.sql {IFS_SCHEMA_NAME}
Prompt  action: GrantContextToIFS
alter procedure ctxsys.&1._WP compile;

show errors

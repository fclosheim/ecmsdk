#!/bin/bash

/etc/init.d/oracle-xe start
su -m oracle -c "/u01/app/oracle/product/11.2.0/xe/bin/lsnrctl start"
su -m oracle -c "/u01/app/oracle/product/11.2.0/xe/bin/sqlplus -s system/oracle <<EOF
CREATE SMALLFILE TABLESPACE ECMSDK LOGGING DATAFILE '/u01/app/oracle/oradata/XE/ecmsdk.dbf' SIZE 50M
REUSE AUTOEXTEND ON NEXT 51200K MAXSIZE 11264M EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO;
exit;
EOF"

su -m oracle -c "/u01/app/oracle/product/ecmsdk/bin/ecmsdk install"

su -m oracle -c "/u01/app/oracle/product/11.2.0/xe/bin/lsnrctl stop"
/etc/init.d/oracle-xe stop
